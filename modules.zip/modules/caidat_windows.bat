@echo off
chcp 65001 >nul
echo ==========================================
echo    CAI DAT UNIFIED MULTI-BOT (Windows)
echo ==========================================
echo.

:: Kiểm tra Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [LOI] Chua cai Python! Tai tai: https://python.org
    pause
    exit /b 1
)

echo [OK] Tim thay Python
echo [INFO] Dang cai thu vien...

pip install python-telegram-bot==20.7 ^
            requests ^
            cloudscraper ^
            PySocks ^
            websocket-client ^
            certifi ^
            cryptography

echo.
echo ==========================================
echo    CAI DAT XONG!
echo    Chay bot bang lenh: python main.py
echo ==========================================
pause
