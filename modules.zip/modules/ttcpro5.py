"""
Module: TTC PRO 5 - Tương Tác Chéo (Multi-Page Cookie)
tuongtaccheo.com — hỗ trợ captcha 3xcaptcha.com
Prefix callback: pro5_*, captcha_*
"""

import asyncio
import threading
import json
import os
import random
import re
import base64
import uuid
from datetime import datetime
from time import sleep
from copy import deepcopy

import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes


# ── Token (được inject từ main.py) ──
BOT_TOKEN = ""

# ── File lưu dữ liệu (đường dẫn tuyệt đối theo vị trí file) ──
_MODULE_DIR  = os.path.dirname(os.path.abspath(__file__))  # .../modules/
_BASE_DIR    = os.path.dirname(_MODULE_DIR)                # .../Downloads/
DATA_DIR     = os.path.join(_BASE_DIR, "data", "pro5_users")
os.makedirs(DATA_DIR, exist_ok=True)
USER_DATA_FILE = os.path.join(DATA_DIR, "users_data.json")

# ── Running tasks ──
running_tasks: dict = {}   # {uid: asyncio.Task}
stop_flags_pro5: dict = {} # {uid: threading.Event}

# ── States (dùng ctx.user_data["pro5_state"]) ──
ST_MENU = "pro5_menu"
ST_TOKEN = "pro5_token"
ST_COOKIE = "pro5_cookie"
ST_PROXY = "pro5_proxy"
ST_TASKS = "pro5_tasks"
ST_DELAY_MIN = "pro5_dmin"
ST_DELAY_MAX = "pro5_dmax"
ST_JOB_BLOCK = "pro5_jblock"
ST_DELAY_BLOCK = "pro5_dblock"
ST_JOB_BREAK = "pro5_jbreak"
ST_CAPTCHA_KEY  = "pro5_captcha"   # Giữ để không break
ST_JOBS_DONE    = "pro5_jobs_done"  # Số job hoàn thành thì nghỉ
ST_REPEAT       = "pro5_repeat"     # Có lặp lại không


# ─────────────────────────────────────────────
#  QUẢN LÝ DỮ LIỆU USER
# ─────────────────────────────────────────────
def _load_all() -> dict:
    if os.path.exists(USER_DATA_FILE):
        try:
            with open(USER_DATA_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return {}
    return {}

def _save_all(data: dict):
    with open(USER_DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def get_user(uid: int) -> dict:
    all_data = _load_all()
    uid_str = str(uid)
    if uid_str not in all_data:
        all_data[uid_str] = {
            "ttc_token": "", "ttc_username": "",
            "cookies": [], "proxy_list": [],
            "settings": {}, "running": False,
        }
        _save_all(all_data)
    return all_data[uid_str]

def save_user(uid: int, user_data: dict):
    all_data = _load_all()
    all_data[str(uid)] = user_data
    _save_all(all_data)

async def _send_main_menu(uid: int, app):
    """Gửi lại menu TTC PRO5 sau khi cấu hình xong"""
    user = get_user(uid)
    has_token = bool(user.get("ttc_token"))
    has_cookies = bool(user.get("cookies"))
    has_settings = bool(user.get("settings"))
    status_icon = "🟢" if user.get("running") else "🔴"
    kb = _menu_kb()
    text = (f"⚡ <b>TTC PRO5 — Tương Tác Chéo Nâng Cao</b>\n"
            f"📌 <i>Phiên bản nâng cấp TTC, dùng Cookie FB trực tiếp</i>\n"
            f"{status_icon} {'Đang chạy' if user.get('running') else 'Đã dừng'}\n"
            f"{'✅' if has_token else '❌'} Token | "
            f"{'✅' if has_cookies else '❌'} Cookie ({len(user.get('cookies',[]))} page) | "
            f"{'✅' if has_settings else '❌'} Cài đặt")
    try:
        await app.bot.send_message(chat_id=uid, text=text, reply_markup=kb, parse_mode="HTML")
    except:
        pass




# ─────────────────────────────────────────────
#  CÁC CLASS GỐC
# ─────────────────────────────────────────────
def encode_to_base64(_data):
    return base64.b64encode(_data.encode("utf-8")).decode("utf-8")


class Facebook(object):
    def __init__(self, cookie, proxy=None):
        try:
            self.lsd = ""; self.actor_id = ""; self.fb_dtsg = ""; self.jazoest = ""
            self.proxies = None; self.session = requests.Session()
            matches = re.findall("i_user=.*?;", cookie)
            self.cookie = cookie.replace(matches[0], "") if matches else cookie
            self.headers = {
                "authority": "www.facebook.com", "accept": "*/*",
                "cookie": self.cookie, "origin": "https://www.facebook.com",
                "referer": "https://www.facebook.com/",
                "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-origin",
            }
            if proxy:
                try:
                    parts = proxy.strip().split(":")
                    if len(parts) == 4:
                        h, p, u, pw = parts
                        self.proxies = {"http": f"http://{u}:{pw}@{h}:{p}", "https": f"http://{u}:{pw}@{h}:{p}"}
                    elif len(parts) == 2:
                        h, p = parts
                        self.proxies = {"http": f"http://{h}:{p}", "https": f"http://{h}:{p}"}
                except:
                    self.proxies = None
            if self.proxies:
                self.session.proxies.update(self.proxies)
            response = self.session.get("https://www.facebook.com/", headers=self.headers).text
            m = re.findall(r'\["DTSGInitialData",\[\],\{"token":"(.*?)"\}', response)
            if m:
                self.fb_dtsg = m[0]
                self.jazoest = re.findall(r'jazoest=(.*?)"', response)[0]
                self.actor_id = re.findall(r'"ACCOUNT_ID":"(.*?)"', response)[0]
                self.lsd = re.findall(r'\["LSD",\[\],\{"token":"(.*?)"\}', response)[0]
        except:
            pass

    def get_profile(self):
        try:
            response = self.session.post(
                "https://www.facebook.com/api/graphql/",
                headers=self.headers,
                data={
                    "av": self.actor_id, "__user": self.actor_id, "__a": "1",
                    "fb_dtsg": self.fb_dtsg, "jazoest": self.jazoest, "lsd": self.lsd,
                    "variables": '{"showUpdatedLaunchpointRedesign":true,"useAdminedPagesForActingAccount":false,"useNewPagesYouManage":true}',
                    "doc_id": "5300338636681652",
                },
                proxies=self.proxies,
            ).json()["data"]["viewer"]["actor"]["profile_switcher_eligible_profiles"]["nodes"]
            return len(response), response
        except:
            return 0, []

    def reaction(self, id, actor_id, type):
        try:
            headers = self.headers.copy()
            headers.update({"cookie": self.headers["cookie"] + f";i_user={actor_id}"})
            reac = {"LIKE": "1635855486666999", "LOVE": "1678524932434102", "CARE": "613557422527858",
                    "HAHA": "115940658764963", "WOW": "478547315650144", "SAD": "908563459236466", "ANGRY": "444813342392137"}
            self.session.post("https://www.facebook.com/api/graphql/", headers=headers, data={
                "av": actor_id, "fb_dtsg": self.fb_dtsg, "jazoest": self.jazoest, "lsd": self.lsd,
                "variables": f'{{"input":{{"feedback_id":"{encode_to_base64("feedback:"+str(id))}","feedback_reaction_id":"{reac.get(type)}","feedback_source":"NEWS_FEED","is_tracking_encrypted":true,"tracking":[],"session_id":"{uuid.uuid4()}","actor_id":"{actor_id}","client_mutation_id":"3"}},"useDefaultActor":false,"__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider":false}}',
                "doc_id": "7047198228715224",
            }, proxies=self.proxies)
        except:
            pass

    def follow(self, id, actor_id):
        try:
            headers = self.headers.copy()
            headers.update({"cookie": self.headers["cookie"] + f";i_user={actor_id}"})
            response = self.session.post("https://www.facebook.com/api/graphql/", headers=headers, data={
                "fb_dtsg": self.fb_dtsg, "jazoest": self.jazoest, "lsd": self.lsd,
                "variables": f'{{"input":{{"subscribe_location":"PROFILE","subscribee_id":"{id}","actor_id":"{actor_id}","client_mutation_id":"1"}},"scale":1}}',
                "doc_id": "5032256523527306",
            }, proxies=self.proxies)
            return '"subscribe_status":"IS_SUBSCRIBED"' in response.text
        except:
            pass

    def like_page(self, id, actor_id):
        try:
            headers = self.headers.copy()
            headers.update({"cookie": self.headers["cookie"] + f";i_user={actor_id}"})
            response = self.session.post("https://www.facebook.com/api/graphql/", headers=headers, data={
                "fb_dtsg": self.fb_dtsg, "jazoest": self.jazoest, "lsd": self.lsd,
                "variables": f'{{"input":{{"is_tracking_encrypted":true,"page_id":"{id}","source":"unknown","tracking":[],"actor_id":"{actor_id}","client_mutation_id":"2"}},"isAdminView":false}}',
                "doc_id": "5556947024325929",
            }, proxies=self.proxies)
            return '"subscribe_status":"IS_SUBSCRIBED"' in response.text
        except:
            pass

    def reactioncmt(self, id, actor_id, type):
        try:
            headers = self.headers.copy()
            headers.update({"cookie": self.headers["cookie"] + f";i_user={actor_id}"})
            reac = {"LIKE": "1635855486666999", "LOVE": "1678524932434102", "CARE": "613557422527858",
                    "HAHA": "115940658764963", "WOW": "478547315650144", "SAD": "908563459236466", "ANGRY": "444813342392137"}
            self.session.post("https://www.facebook.com/api/graphql/", headers=headers, data={
                "av": actor_id, "fb_dtsg": self.fb_dtsg, "jazoest": self.jazoest, "lsd": self.lsd,
                "variables": f'{{"input":{{"feedback_id":"{encode_to_base64("feedback:"+str(id))}","feedback_reaction_id":"{reac.get(type)}","feedback_source":"TAHOE","is_tracking_encrypted":true,"tracking":[],"session_id":"{uuid.uuid4()}","actor_id":"{actor_id}","client_mutation_id":"1"}},"useDefaultActor":false,"__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider":false}}',
                "doc_id": "7616998081714004",
            }, proxies=self.proxies)
        except:
            pass

    def group(self, id, actor_id):
        try:
            headers = self.headers.copy()
            headers.update({"cookie": self.headers["cookie"] + f";i_user={actor_id}"})
            self.session.post("https://www.facebook.com/api/graphql/", headers=headers, data={
                "av": actor_id, "__user": actor_id, "__a": "1",
                "fb_dtsg": self.fb_dtsg, "jazoest": self.jazoest, "lsd": self.lsd,
                "variables": f'{{"feedType":"DISCUSSION","groupID":"{id}","input":{{"action_source":"GROUP_MALL","group_id":"{id}","actor_id":"{actor_id}","client_mutation_id":"1"}}}}',
                "doc_id": "5853134681430324",
            }, proxies=self.proxies)
        except:
            pass

    def share(self, id, actor_id):
        try:
            headers = self.headers.copy()
            headers.update({"cookie": self.headers["cookie"] + f";i_user={actor_id}"})
            self.session.post("https://www.facebook.com/api/graphql/", headers=headers, data={
                "av": actor_id, "__user": actor_id, "__a": "1",
                "fb_dtsg": self.fb_dtsg, "jazoest": self.jazoest, "lsd": self.lsd,
                "variables": f'{{"input":{{"composer_entry_point":"share_modal","composer_type":"share","idempotence_token":"{uuid.uuid4()}_FEED","source":"WWW","attachments":[{{"link":{{"share_scrape_data":"{{\\"share_type\\":22,\\"share_params\\":[{id}]}}"}}}}],"audience":{{"privacy":{{"allow":[],"base_state":"EVERYONE","deny":[]}}}},"is_tracking_encrypted":true,"tracking":[],"actor_id":"{actor_id}","client_mutation_id":"3"}},"feedLocation":"NEWSFEED","feedbackSource":1,"focusCommentID":null,"scale":1,"useDefaultActor":false}}',
                "doc_id": "8167261726632010",
            }, proxies=self.proxies)
        except:
            pass

    def comment(self, id, actor_id, msg: str):
        try:
            headers = self.headers.copy()
            headers.update({"cookie": self.headers["cookie"] + f";i_user={actor_id}"})
            self.session.post("https://www.facebook.com/api/graphql/", headers=headers, data={
                "av": actor_id, "fb_dtsg": self.fb_dtsg, "jazoest": self.jazoest, "lsd": self.lsd,
                "variables": f'{{"feedLocation":"DEDICATED_COMMENTING_SURFACE","feedbackSource":110,"groupID":null,"input":{{"client_mutation_id":"4","actor_id":"{actor_id}","attachments":null,"feedback_id":"{encode_to_base64(f"feedback:{id}")}","formatting_style":null,"message":{{"ranges":[],"text":"{msg}"}},"is_tracking_encrypted":true,"tracking":[],"feedback_source":"DEDICATED_COMMENTING_SURFACE","idempotence_token":"client:{uuid.uuid4()}","session_id":"{uuid.uuid4()}"}},"scale":1,"useDefaultActor":false,"focusCommentID":null}}',
                "doc_id": "7994085080671282",
            }, proxies=self.proxies)
        except:
            pass

    def info(self, actor_id):
        headers = self.headers.copy()
        headers.update({"cookie": self.headers["cookie"] + f";i_user={actor_id}"})
        get = self.session.get("https://www.facebook.com/me", headers=headers, proxies=self.proxies).text
        try:
            name = get.split("<title>")[1].split("</title>")[0]
            return {"success": 200, "id": actor_id, "name": name}
        except:
            return {"error": 200}


class NextCaptcha:
    def __init__(self, apikey):
        self.apikey = apikey
        self.session = requests.Session()

    def recaptchav2(self, sitekey, siteurl):
        try:
            response = self.session.post("https://api.3xcaptcha.com/createTask", json={
                "clientKey": self.apikey,
                "task": {"type": "RecaptchaV2TaskProxyless", "websiteURL": siteurl, "websiteKey": sitekey},
            }).json()
            if response.get("errorId", 0) != 0:
                return {"error": response.get("errorId"), "message": response.get("errorDescription")}
            return {"status": "success", "task_id": response.get("taskId")}
        except Exception as e:
            return {"error": 200, "message": str(e)}

    def get_result(self, task_id, max_attempts=10):
        data = {"clientKey": self.apikey, "taskId": task_id}
        wait_time = 10
        for _ in range(max_attempts):
            try:
                response = self.session.post("https://api.3xcaptcha.com/getTaskResult", json=data).json()
                if response.get("errorId", 0) != 0:
                    return {"error": response.get("errorId")}
                if response.get("status") == "ready":
                    return {"status": "success", "token": response["solution"]["gRecaptchaResponse"]}
                sleep(wait_time)
                wait_time = min(wait_time + 2, 10)
            except Exception as e:
                return {"error": 200, "message": str(e)}
        return {"error": 408, "message": "Timeout"}


class TuongTacCheo(object):
    def __init__(self, token, proxy=None):
        # Khởi tạo mặc định để tránh AttributeError
        self.ss = requests.Session()
        self.session = {}   # Default empty — info() sẽ trả error
        self.cookie = ""
        self.headers = {}
        self.proxies = None
        try:
            resp = self.ss.post(
                "https://tuongtaccheo.com/logintoken.php",
                data={"access_token": token}, timeout=15)
            self.cookie = resp.headers.get("Set-cookie", "")
            try:
                self.session = resp.json()
            except Exception:
                self.session = {}
            self.headers = {
                "Host": "tuongtaccheo.com", "accept": "*/*",
                "origin": "https://tuongtaccheo.com",
                "x-requested-with": "XMLHttpRequest",
                "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "cookie": self.cookie,
            }
            if proxy:
                try:
                    parts = proxy.strip().split(":")
                    if len(parts) == 4:
                        h, p, u, pw = parts
                        self.proxies = {"http": f"http://{u}:{pw}@{h}:{p}", "https": f"http://{u}:{pw}@{h}:{p}"}
                    elif len(parts) == 2:
                        h, p = parts
                        self.proxies = {"http": f"http://{h}:{p}", "https": f"http://{h}:{p}"}
                except:
                    self.proxies = None
            if self.proxies:
                self.ss.proxies.update(self.proxies)
        except Exception:
            pass  # self.session={} → info() sẽ trả error an toàn

    def info(self):
        if self.session.get("status") == "success":
            return {"status": "success", "user": self.session["data"]["user"], "xu": self.session["data"]["sodu"]}
        return {"error": 200}

    def add_uid(self, id, g_recaptcha_response):
        response = requests.post("https://tuongtaccheo.com/cauhinh/nhapnick.php", headers=self.headers,
                                  data={"link": id, "loainick": "fb", "recaptcha": g_recaptcha_response}).text
        return response == "1"

    def get_g_recaptcha_response(self, apikey):
        try:
            response = self.ss.get("https://tuongtaccheo.com/cauhinh/facebook.php", headers=self.headers, proxies=self.proxies)
            sitekey = response.text.split('data-sitekey="')[1].split('"')[0]
            captcha_solver = NextCaptcha(apikey)
            rcv2 = captcha_solver.recaptchav2(sitekey, response.url)
            if rcv2.get("status") != "success":
                return {"error": 200, "message": "Không thể tạo task CAPTCHA"}
            result = captcha_solver.get_result(rcv2.get("task_id"))
            if result.get("status") == "success":
                return {"status": "success", "token": result["token"]}
            return {"error": 200, "message": "Không thể lấy token CAPTCHA"}
        except Exception as e:
            return {"error": 500, "message": str(e)}

    def cauhinh(self, id):
        """Thêm UID vào TTC dùng nhapnick.php (không cần captcha)"""
        try:
            headers = dict(self.headers)
            headers["referer"] = "https://tuongtaccheo.com/cauhinh/facebook.php"
            resp = self.ss.post(
                "https://tuongtaccheo.com/cauhinh/nhapnick.php",
                headers=headers,
                data={"link": str(id), "loainick": "fb", "recaptcha": "1"},
                proxies=self.proxies, timeout=30).text.strip()
            return True if resp == "1" else resp
        except Exception as e:
            return str(e)

    def getjob(self, nv, nickchay=None):
        """Lấy job — thêm nickchay để chạy đa luồng FB"""
        url    = f"https://tuongtaccheo.com/kiemtien/{nv}/getpost.php"
        params = {"nickchay": str(nickchay)} if nickchay else {}
        try:
            return self.ss.get(url, headers=self.headers, params=params, proxies=self.proxies, timeout=15)
        except:
            return None

    def nhanxu(self, id, nv, nickchay=None):
        """Nhận xu — hỗ trợ nickchay (đa luồng FB)"""
        try:
            xu_truoc = self.ss.get(
                "https://tuongtaccheo.com/home.php",
                headers=self.headers, proxies=self.proxies, timeout=10
            ).text.split('"soduchinh">')[1].split("<")[0]

            body = {"id": id}
            if nickchay:
                body["nickchay"] = str(nickchay)

            response = self.ss.post(
                f"https://tuongtaccheo.com/kiemtien/{nv}/nhantien.php",
                headers=self.headers, data=body, proxies=self.proxies, timeout=15).json()

            xu_sau = self.ss.get(
                "https://tuongtaccheo.com/home.php",
                headers=self.headers, proxies=self.proxies, timeout=10
            ).text.split('"soduchinh">')[1].split("<")[0]

            if "mess" in response:
                try:
                    if int(str(xu_sau).replace(",","")) > int(str(xu_truoc).replace(",","")):
                        parts = response["mess"].split()
                        msg = parts[-2] if len(parts) >= 2 else "0"
                        return {"status":"success","msg":"+"+msg+" Xu","xu":xu_sau}
                except: pass
            if response.get("status") == "success":
                return {"status":"success","msg":response.get("msg","OK"),"xu":xu_sau}
        except: pass
        return {"error": 200}


def check_proxy(proxy):
    session = requests.Session()
    response = session.post("https://kiemtraip.vn/check-proxy", data={
        "option": "checkCountry", "changeTimeout": "5000",
        "changeUrl": "https://traodoisub.com/", "proxies": str(proxy),
    }).text
    if '<span class="text-success copy">' in response:
        ip = response.split('<span class="text-success copy">')[1].split()[0].split("</span>")[0]
        return {"status": "success", "ip": ip}
    return {"status": "error", "ip": None}


# ─────────────────────────────────────────────
#  CHẠY TOOL
# ─────────────────────────────────────────────
async def run_tool_for_user(uid: int, send_msg_fn, stop_ev=None):
    user = get_user(uid)
    def should_stop():
        if stop_ev is not None and stop_ev.is_set(): return True
        return not get_user(uid).get("running", True)
    settings = user["settings"]
    list_nv = list(settings.get("nhiemvu", ""))
    # Chỉ dùng cookie đang bật
    all_cookies = user.get("cookies", [])
    ck_enabled = user.get("cookie_enabled", [True]*len(all_cookies))
    while len(ck_enabled) < len(all_cookies): ck_enabled.append(True)
    listCookie = [ck for i,ck in enumerate(all_cookies) if (ck_enabled[i] if i < len(ck_enabled) else True)]
    if not listCookie and all_cookies:
        await send_msg_fn("⚠️ Tất cả cookie đang tắt! Vào 🍪 Cookie để bật.")
        return
    proxy_list = user["proxy_list"]
    token = user["ttc_token"]
    proxy = proxy_list[0] if proxy_list else None

    ttc = TuongTacCheo(token, proxy)
    checktoken = ttc.info()
    if checktoken.get("status") != "success":
        await send_msg_fn("❌ Token TTC không hợp lệ hoặc đã hết hạn. Dừng lại.")
        return

    stt = 0; totalxu = 0
    _total_done = 0
    _max_done   = int(settings.get("JobsDone", 0))   # 0 = không giới hạn
    _repeat     = bool(settings.get("Repeat", False))
    await send_msg_fn(
        f"▶️ Bắt đầu chạy!\n"
        f"👤 TTC: {checktoken.get('user')}\n"
        f"💰 Xu hiện tại: {format(int(checktoken.get('xu', 0)), ',')}\n"
        f"🍪 Cookie: {len(listCookie)}\n"
        f"📋 Nhiệm vụ: {settings.get('nhiemvu', '')}"
    )

    while not should_stop():
        if not listCookie:
            await send_msg_fn("⚠️ Hết cookie! Vui lòng thêm cookie mới.")
            break
        if not list_nv:
            await send_msg_fn("⚠️ Không có nhiệm vụ nào. Dừng.")
            break

        for index, cookie in enumerate(list(listCookie)):
            proxy = proxy_list[index % len(proxy_list)] if proxy_list else None
            JobError, JobSuccess, JobFail = 0, 0, 0
            id_user = cookie.split("i_user=")[1].split(";")[0]
            fb = Facebook(cookie, proxy)
            info = fb.info(id_user)

            if "success" in info:
                namefb = info["name"]; idfb = str(info["id"])
            else:
                await send_msg_fn(f"❌ Cookie Die (UID: {id_user}), đã xóa.")
                listCookie.remove(cookie)
                u = get_user(uid); u["cookies"] = listCookie; save_user(uid, u)
                break

            datnick = ttc.cauhinh(idfb)
            if datnick != True and datnick != "1":
                apikey = settings.get("apikey", "")
                if apikey:
                    gaicapcha = ttc.get_g_recaptcha_response(apikey)
                    if gaicapcha.get("status") == "success":
                        add_uid = ttc.add_uid(idfb, gaicapcha.get("token"))
                        if add_uid:
                            datnick = ttc.cauhinh(idfb)
                            if datnick != True and datnick != "1":
                                listCookie.remove(cookie); break
                        else:
                            listCookie.remove(cookie); break
                    else:
                        await asyncio.sleep(2); continue
                else:
                    await send_msg_fn(f"⚠️ Chưa cấu hình UID: {idfb} | {namefb}")
                    listCookie.remove(cookie); break

            chuyen = False
            while not should_stop():
                if not list_nv:
                    break
                random_nv = random.choice(list_nv)
                fields_map = {
                    "1": "likepostvipcheo", "2": "likepostcheo", "3": "camxucvipcheo", "4": "camxuccheo",
                    "5": "camxuccheobinhluan", "6": "cmtcheo", "7": "sharecheo", "8": "likepagecheo",
                    "9": "subcheo", "0": "thamgianhomcheo",
                }
                fields = fields_map.get(random_nv, "likepostcheo")
                # nickchay = fb_uid để lấy job riêng cho từng acc FB
                getjob = ttc.getjob(fields, nickchay=idfb)
                if not getjob:
                    await asyncio.sleep(5); continue

                if "id" in getjob.text:
                    try:
                        _gjson = getjob.json()
                        if not isinstance(_gjson, list): _gjson = []
                    except Exception:
                        _gjson = []
                    for x in _gjson:
                        nextDelay = False
                        id_post = x["idpost"]
                        id_ = id_post.split("_")[1] if "_" in id_post else id_post

                        if random_nv == "1":
                            fb.reaction(x["idfb"].split("_")[1] if "_" in x["idfb"] else x["idfb"], idfb, "LIKE")
                            id_ = x["idfb"].split("_")[1] if "_" in x["idfb"] else x["idfb"]; type_ = "LIKE"
                        elif random_nv == "2":
                            fb.reaction(id_, idfb, "LIKE"); type_ = "LIKE"
                        elif random_nv == "3":
                            fb.reaction(x["idfb"].split("_")[1] if "_" in x["idfb"] else x["idfb"], idfb, x["loaicx"])
                            id_ = x["idfb"].split("_")[1] if "_" in x["idfb"] else x["idfb"]; type_ = x["loaicx"]
                        elif random_nv == "4":
                            fb.reaction(id_, idfb, x["loaicx"]); type_ = x["loaicx"]
                        elif random_nv == "5":
                            fb.reactioncmt(id_, idfb, x["loaicx"]); type_ = x["loaicx"]
                        elif random_nv == "6":
                            fb.comment(id_, idfb, json.loads(x["nd"])[0]); type_ = "COMMENT"
                        elif random_nv == "7":
                            fb.share(id_, idfb); type_ = "SHARE"
                        elif random_nv == "8":
                            fb.like_page(id_, idfb); type_ = "LIKEPAGE"
                        elif random_nv == "9":
                            fb.follow(id_, idfb); type_ = "FOLLOW"
                        elif random_nv == "0":
                            fb.group(id_, idfb); type_ = "GROUP"
                        else:
                            type_ = "?"

                        nhanxu = ttc.nhanxu(id_post, fields, nickchay=idfb)
                        if nhanxu.get("status") == "success":
                            nextDelay = True
                            msg = nhanxu["msg"]; xu = nhanxu["xu"]
                            JobFail = 0; xuthem = int(msg.replace("+", "").replace(" Xu", ""))
                            totalxu += xuthem; stt += 1; JobSuccess += 1
                            _total_done += 1
                            # Kiểm tra giới hạn jobs thành công
                            if _max_done > 0 and _total_done >= _max_done:
                                await send_msg_fn(
                                    f"🏁 Đã hoàn thành {_total_done} job thành công!\n"
                                    f"📊 Tổng xu phiên: {format(totalxu, ',')}\n"
                                    + ("🔄 Lặp lại từ đầu..." if _repeat else "⏹ Dừng theo cấu hình."))
                                if _repeat:
                                    _total_done = 0
                                    # Reset để vòng mới
                                else:
                                    user["running"] = False; save_user(uid, user); return
                            timejob = datetime.now().strftime("%H:%M:%S")
                            if stt % 10 == 0:
                                await send_msg_fn(
                                    f"✅ Job #{stt} | {type_} | {timejob}\n"
                                    f"💰 +{xuthem} xu | Tổng phiên: {format(totalxu, ',')}\n"
                                    f"🏦 Số dư: {format(int(xu), ',')}"
                                )
                        else:
                            JobFail += 1

                        if JobFail >= 20:
                            await send_msg_fn(f"⚠️ Tài khoản {namefb} bị block, đã xóa.")
                            if cookie in listCookie: listCookie.remove(cookie)
                            u = get_user(uid); u["cookies"] = listCookie; save_user(uid, u)
                            chuyen = True; break

                        if JobSuccess != 0 and JobSuccess % int(settings.get("JobBreak", 5)) == 0:
                            chuyen = True; break

                        if nextDelay:
                            job_block = int(settings.get("JobbBlock", 10))
                            delay_block = int(settings.get("DelayBlock", 30))
                            delay_min, delay_max = settings.get("delay", [3, 8])
                            if stt % job_block == 0:
                                await asyncio.sleep(float(delay_block))
                            else:
                                await asyncio.sleep(random.uniform(float(delay_min), float(delay_max)))

                    if chuyen:
                        break
                else:
                    if "error" in getjob.text:
                        try:
                            countdown = getjob.json().get("countdown", 3)
                            await asyncio.sleep(float(countdown) if countdown else 3)
                        except:
                            await asyncio.sleep(3)

        u = get_user(uid)
        if not u.get("running", False):
            await send_msg_fn(f"🛑 Đã dừng tool.\n📊 Tổng jobs: {stt} | Xu phiên: {format(totalxu, ',')}")
            return
        # Hết vòng (hết cookie) → kiểm tra repeat
        if _repeat and not should_stop():
            await send_msg_fn(f"🔄 Hết vòng — Lặp lại! (Tổng: {stt} job, {format(totalxu,',')} xu)")
        elif not _repeat:
            await send_msg_fn(f"✅ Hết vòng — Dừng! (Tổng: {stt} job, {format(totalxu,',')} xu)")
            user["running"] = False; save_user(uid, user); return
        await asyncio.sleep(1)


# ─────────────────────────────────────────────
#  KEYBOARD
# ─────────────────────────────────────────────
def _menu_kb():
    # Menu TTC PRO5 - phiên bản nâng cấp của TTC
    # Khác TTC thường: dùng cookie FB trực tiếp (không cần token|cookie)
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔑 Cấu hình Token TTC", callback_data="pro5_cfg_token"),
         InlineKeyboardButton("🍪 Cấu hình Cookie FB", callback_data="pro5_cfg_cookie")],
        [InlineKeyboardButton("🌐 Cấu hình Proxy", callback_data="pro5_cfg_proxy"),
         InlineKeyboardButton("⚙️ Cấu hình chạy", callback_data="pro5_cfg_settings")],
        [InlineKeyboardButton("▶️ Bắt đầu chạy", callback_data="pro5_start"),
         InlineKeyboardButton("🛑 Dừng", callback_data="pro5_stop")],
        [InlineKeyboardButton("📊 Xem cấu hình", callback_data="pro5_view_config"),
         InlineKeyboardButton("💰 Kiểm tra số dư", callback_data="pro5_check_balance")],
        [InlineKeyboardButton("🔙 Menu chính", callback_data="back_home")],
    ])


# ─────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────
async def cmd_entry(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    user = get_user(uid)
    ctx.user_data["module_state"] = ST_MENU
    has_token = bool(user.get("ttc_token"))
    has_cookies = bool(user.get("cookies"))
    has_settings = bool(user.get("settings"))
    status_icon = "🟢" if user.get("running") else "🔴"
    text = (f"⚡ <b>TTC PRO5 — Tương Tác Chéo Nâng Cao</b>\n"
            f"📌 <i>Phiên bản nâng cấp TTC, dùng Cookie FB trực tiếp</i>\n"
            f"{status_icon} {'Đang chạy' if user.get('running') else 'Đã dừng'}\n"
            f"{'✅' if has_token else '❌'} Token | "
            f"{'✅' if has_cookies else '❌'} Cookie ({len(user.get('cookies',[]))} page) | "
            f"{'✅' if has_settings else '❌'} Cài đặt")
    if update.callback_query:
        await update.callback_query.message.reply_text(text, reply_markup=_menu_kb(), parse_mode="HTML")
    else:
        await update.message.reply_text(text, reply_markup=_menu_kb(), parse_mode="HTML")


def show_main_menu(update, ctx):
    """Hiển thị menu TTC PRO 5 (gọi từ main)"""
    pass  # handled by cmd_entry & callback back_home


# ─────────────────────────────────────────────
#  CALLBACK HANDLER
# ─────────────────────────────────────────────
async def handle_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    query = update.callback_query
    data = query.data
    uid = query.from_user.id
    chat_id = query.message.chat_id

    if not (data.startswith("pro5_") or data.startswith("captcha_")):
        return False

    await query.answer()

    if data == "pro5_cfg_token":
        ctx.user_data["module_state"] = ST_TOKEN
        await query.edit_message_text(
            "🔑 *Nhập Access Token TuongTacCheo.com:*\n\nLấy token tại: https://tuongtaccheo.com",
            parse_mode="Markdown",
        )

    elif data == "pro5_cfg_cookie":
        user = get_user(uid); cookies = user.get("cookies", [])
        # Build per-cookie management rows
        rows = []
        for i, ck in enumerate(cookies):
            # Try to extract i_user from cookie
            try: fb_uid = ck.split("i_user=")[1].split(";")[0]
            except:
                try: fb_uid = ck.split("c_user=")[1].split(";")[0]
                except: fb_uid = f"cookie{i+1}"
            enabled = True  # Pro5 cookies are always strings; track enabled separately
            # Store enabled state in user["cookie_enabled"] list
            ck_enabled = user.get("cookie_enabled", [True]*len(cookies))
            while len(ck_enabled) < len(cookies): ck_enabled.append(True)
            enabled = ck_enabled[i] if i < len(ck_enabled) else True
            icon = "🟢" if enabled else "🔴"
            rows.append([
                InlineKeyboardButton(f"{icon} UID:{fb_uid[:15]}", callback_data=f"pro5_ck_toggle_{i}"),
                InlineKeyboardButton("🗑", callback_data=f"pro5_ck_del_{i}"),
            ])
        rows.append([InlineKeyboardButton("➕ Thêm cookie mới", callback_data="pro5_cookie_add")])
        rows.append([InlineKeyboardButton("🗑️ Xóa tất cả", callback_data="pro5_cookie_clear"),
                     InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")])
        ck_enabled = user.get("cookie_enabled", [True]*len(cookies))
        while len(ck_enabled) < len(cookies): ck_enabled.append(True)
        en_count = sum(1 for e in ck_enabled[:len(cookies)] if e)
        await query.edit_message_text(
            f"🍪 <b>Quản lý Cookie FB - PRO5</b>\n"
            f"Tổng: <b>{len(cookies)}</b> | 🟢 Bật: <b>{en_count}</b> | 🔴 Tắt: <b>{len(cookies)-en_count}</b>\n\n"
            f"🟢 = đang chọn | 🔴 = tạm dừng | 🗑 = xóa",
            reply_markup=InlineKeyboardMarkup(rows), parse_mode="HTML")

    elif data.startswith("pro5_ck_toggle_"):
        idx = int(data.split("_")[-1])
        user = get_user(uid); cookies = user.get("cookies", [])
        ck_enabled = user.get("cookie_enabled", [True]*len(cookies))
        while len(ck_enabled) < len(cookies): ck_enabled.append(True)
        if 0 <= idx < len(cookies):
            ck_enabled[idx] = not ck_enabled[idx]
        user["cookie_enabled"] = ck_enabled; save_user(uid, user)
        # Refresh view
        rows = []
        for i, ck in enumerate(cookies):
            try: fb_uid = ck.split("i_user=")[1].split(";")[0]
            except:
                try: fb_uid = ck.split("c_user=")[1].split(";")[0]
                except: fb_uid = f"cookie{i+1}"
            enabled = ck_enabled[i] if i < len(ck_enabled) else True
            icon = "🟢" if enabled else "🔴"
            rows.append([InlineKeyboardButton(f"{icon} UID:{fb_uid[:15]}", callback_data=f"pro5_ck_toggle_{i}"),
                         InlineKeyboardButton("🗑", callback_data=f"pro5_ck_del_{i}")])
        rows.append([InlineKeyboardButton("➕ Thêm cookie mới", callback_data="pro5_cookie_add")])
        rows.append([InlineKeyboardButton("🗑️ Xóa tất cả", callback_data="pro5_cookie_clear"),
                     InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")])
        en_count = sum(1 for e in ck_enabled[:len(cookies)] if e)
        await query.edit_message_text(
            f"🍪 <b>Quản lý Cookie FB</b>\nTổng: <b>{len(cookies)}</b> | 🟢 {en_count} | 🔴 {len(cookies)-en_count}",
            reply_markup=InlineKeyboardMarkup(rows), parse_mode="HTML")

    elif data.startswith("pro5_ck_del_"):
        idx = int(data.split("_")[-1])
        user = get_user(uid); cookies = user.get("cookies", [])
        ck_enabled = user.get("cookie_enabled", [True]*len(cookies))
        if 0 <= idx < len(cookies):
            cookies.pop(idx)
            if idx < len(ck_enabled): ck_enabled.pop(idx)
        user["cookies"] = cookies; user["cookie_enabled"] = ck_enabled; save_user(uid, user)
        rows = []
        for i, ck in enumerate(cookies):
            try: fb_uid = ck.split("i_user=")[1].split(";")[0]
            except:
                try: fb_uid = ck.split("c_user=")[1].split(";")[0]
                except: fb_uid = f"cookie{i+1}"
            enabled = ck_enabled[i] if i < len(ck_enabled) else True
            icon = "🟢" if enabled else "🔴"
            rows.append([InlineKeyboardButton(f"{icon} UID:{fb_uid[:15]}", callback_data=f"pro5_ck_toggle_{i}"),
                         InlineKeyboardButton("🗑", callback_data=f"pro5_ck_del_{i}")])
        rows.append([InlineKeyboardButton("➕ Thêm cookie mới", callback_data="pro5_cookie_add")])
        rows.append([InlineKeyboardButton("🗑️ Xóa tất cả", callback_data="pro5_cookie_clear"),
                     InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")])
        en_count = sum(1 for e in (ck_enabled[:len(cookies)] or []))
        await query.edit_message_text(
            f"🍪 <b>Quản lý Cookie FB</b>\nTổng: <b>{len(cookies)}</b> | 🟢 {en_count} | 🔴 {len(cookies)-en_count}",
            reply_markup=InlineKeyboardMarkup(rows), parse_mode="HTML")

    elif data == "pro5_cookie_add":
        ctx.user_data["module_state"] = ST_COOKIE
        await query.edit_message_text("🍪 <b>Nhập Cookie Facebook (chứa Page):</b>\n\nBot sẽ tự extract tất cả Page.", parse_mode="HTML")

    elif data == "pro5_cookie_clear":
        user = get_user(uid); user["cookies"] = []; user["cookie_enabled"] = []; save_user(uid, user)
        await query.edit_message_text("✅ Đã xóa tất cả cookie!",
                                       reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")]]))

    elif data == "pro5_cfg_proxy":
        user = get_user(uid); count = len(user["proxy_list"])
        await query.edit_message_text(
            f"🌐 *Proxy*\n\nHiện có: {count} proxy\n\nFormat: `IP:Port` hoặc `IP:Port:User:Pass`",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("➕ Thêm proxy", callback_data="pro5_proxy_add")],
                [InlineKeyboardButton("🗑️ Xóa tất cả proxy", callback_data="pro5_proxy_clear")],
                [InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")],
            ]), parse_mode="Markdown",
        )

    elif data == "pro5_proxy_add":
        ctx.user_data["module_state"] = ST_PROXY
        await query.edit_message_text("🌐 *Nhập proxy* (mỗi dòng 1 proxy):\n\nFormat: `IP:Port` hoặc `IP:Port:User:Pass`", parse_mode="Markdown")

    elif data == "pro5_proxy_clear":
        user = get_user(uid); user["proxy_list"] = []; save_user(uid, user)
        await query.edit_message_text("✅ Đã xóa tất cả proxy! (Sẽ chạy không proxy)",
                                       reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")]]))

    elif data == "pro5_cfg_settings":
        ctx.user_data["module_state"] = ST_TASKS
        await query.edit_message_text(
            "⚙️ *Cấu hình chạy*\n\nNhập nhiệm vụ:\n\n"
            "1️⃣ Like VIP\n2️⃣ Like Thường\n3️⃣ Cảm xúc VIP\n4️⃣ Cảm xúc Thường\n"
            "5️⃣ Cảm xúc Comment\n6️⃣ Comment\n7️⃣ Share\n8️⃣ Like Page\n"
            "9️⃣ Follow\n0️⃣ Group\n\nVD: `123` để chọn Like VIP + Like Thường + Cảm xúc VIP",
            parse_mode="Markdown",
        )

    elif data == "pro5_view_config":
        user = get_user(uid); s = user["settings"]
        delay = s.get("delay", [3, 8])
        text = (
            f"📊 *Cấu hình của bạn:*\n\n"
            f"👤 TTC User: {user.get('ttc_username', 'Chưa đăng nhập')}\n"
            f"🍪 Cookie: {len(user['cookies'])}\n"
            f"🌐 Proxy: {len(user['proxy_list'])}\n\n"
            f"📋 Nhiệm vụ: `{s.get('nhiemvu', 'Chưa cấu hình')}`\n"
            f"⏱ Delay: {delay[0]}s - {delay[1]}s\n"
            f"🛡 Jobs/Block: {s.get('JobbBlock', '?')}\n"
            f"⏸ Delay Block: {s.get('DelayBlock', '?')}s\n"
            f"🔄 Jobs/Page: {s.get('JobBreak', '?')}\n"
            f"🔑 Captcha Key: {'✅' if s.get('apikey') else '❌'}\n"
        )
        await query.edit_message_text(text, parse_mode="Markdown",
                                       reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")]]))

    elif data == "pro5_check_balance":
        user = get_user(uid); token = user.get("ttc_token", "")
        if not token:
            await query.edit_message_text("❌ Chưa có token TTC!",
                                           reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")]])); return True
        await query.edit_message_text("⏳ Đang kiểm tra...")
        proxy = user["proxy_list"][0] if user["proxy_list"] else None
        ttc = TuongTacCheo(token, proxy); info = ttc.info()
        if info.get("status") == "success":
            await query.message.reply_text(
                f"💰 *Số dư TTC:*\n\n👤 User: {info['user']}\n💵 Xu: {format(int(info['xu']), ',')}",
                parse_mode="Markdown", reply_markup=_menu_kb(),
            )
        else:
            await query.message.reply_text("❌ Không thể lấy thông tin. Token có thể đã hết hạn.", reply_markup=_menu_kb())

    elif data == "pro5_start":
        user = get_user(uid); s = user["settings"]
        if not user.get("ttc_token"):
            await query.edit_message_text("❌ Chưa cấu hình Token TTC!",
                                           reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")]])); return True
        if not user["cookies"]:
            await query.edit_message_text("❌ Chưa có Cookie Facebook!",
                                           reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")]])); return True
        if not s.get("nhiemvu"):
            await query.edit_message_text("❌ Chưa chọn nhiệm vụ!",
                                           reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")]])); return True
        if uid in running_tasks and not running_tasks[uid].done():
            await query.edit_message_text("⚠️ Tool đang chạy rồi!",
                                           reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")]])); return True

        # Tạo stop_event MỚI mỗi lần chạy
        stop_ev = threading.Event()
        stop_flags_pro5[uid] = stop_ev
        user["running"] = True; save_user(uid, user)

        async def send_msg(text: str):
            try: await ctx.bot.send_message(chat_id=chat_id, text=text)
            except: pass

        task = asyncio.create_task(run_tool_for_user(uid, send_msg, stop_ev))
        running_tasks[uid] = task

        def on_done(t):
            u = get_user(uid); u["running"] = False; save_user(uid, u)
            stop_flags_pro5.pop(uid, None)
        task.add_done_callback(on_done)

        await query.edit_message_text("▶️ <b>Đã bắt đầu chạy!</b>\nDùng 🛑 Dừng để dừng lại.", parse_mode="HTML")

    elif data == "pro5_stop":
        stopped = False
        # 1. Set stop event NGAY
        ev = stop_flags_pro5.get(uid)
        if ev: ev.set(); stopped = True
        # 2. Cancel task ngay lập tức
        t = running_tasks.get(uid)
        if t and not t.done():
            t.cancel(); stopped = True
        user = get_user(uid); user["running"] = False; save_user(uid, user)
        running_tasks.pop(uid, None)
        stop_flags_pro5.pop(uid, None)
        await query.message.reply_text(
            "⏹ <b>Đã dừng PRO5 ngay lập tức!</b>" if stopped else "ℹ️ PRO5 chưa chạy.",
            parse_mode="HTML")
        await _send_main_menu(uid, ctx.application)
        return True

    elif data in ("captcha_yes", "captcha_no"):
        # Legacy - redirect về pro5_repeat_no
        data = "pro5_repeat_no"

    if data == "pro5_repeat_yes":
        uid = query.from_user.id; user = get_user(uid)
        s = user["settings"]
        s["apikey"]     = ""
        s["delay"]      = [ctx.user_data.get("pro5_dmin", 3), ctx.user_data.get("pro5_dmax", 8)]
        s["JobbBlock"]  = ctx.user_data.get("pro5_jblock", 10)
        s["DelayBlock"] = ctx.user_data.get("pro5_dblock", 30)
        s["JobBreak"]   = ctx.user_data.get("pro5_jbreak", 5)
        s["JobsDone"]   = ctx.user_data.get("pro5_jobs_done", 0)
        s["Repeat"]     = True
        save_user(uid, user)
        ctx.user_data["module_state"] = ST_MENU
        jobs_txt = "Không giới hạn" if s["JobsDone"] == 0 else f"{s['JobsDone']} job"
        await query.edit_message_text(
            f"✅ <b>Đã lưu cấu hình PRO5!</b>\n"
            f"├ Delay: {s['delay'][0]}-{s['delay'][1]}s\n"
            f"├ Chống block: {s['JobbBlock']} job → nghỉ {s['DelayBlock']}s\n"
            f"├ Jobs/Page: {s['JobBreak']}\n"
            f"├ Dừng sau: {jobs_txt}\n"
            f"└ Lặp lại: ✅ Có\n\nSẵn sàng chạy 🚀",
            reply_markup=_menu_kb(), parse_mode="HTML")

    elif data == "pro5_repeat_no":
        uid = query.from_user.id; user = get_user(uid)
        s = user["settings"]
        s["apikey"]     = ""
        s["delay"]      = [ctx.user_data.get("pro5_dmin", 3), ctx.user_data.get("pro5_dmax", 8)]
        s["JobbBlock"]  = ctx.user_data.get("pro5_jblock", 10)
        s["DelayBlock"] = ctx.user_data.get("pro5_dblock", 30)
        s["JobBreak"]   = ctx.user_data.get("pro5_jbreak", 5)
        s["JobsDone"]   = ctx.user_data.get("pro5_jobs_done", 0)
        s["Repeat"]     = False
        save_user(uid, user)
        ctx.user_data["module_state"] = ST_MENU
        jobs_txt = "Không giới hạn" if s["JobsDone"] == 0 else f"{s['JobsDone']} job"
        await query.edit_message_text(
            f"✅ <b>Đã lưu cấu hình PRO5!</b>\n"
            f"├ Delay: {s['delay'][0]}-{s['delay'][1]}s\n"
            f"├ Chống block: {s['JobbBlock']} job → nghỉ {s['DelayBlock']}s\n"
            f"├ Jobs/Page: {s['JobBreak']}\n"
            f"├ Dừng sau: {jobs_txt}\n"
            f"└ Lặp lại: ❌ Không\n\nSẵn sàng chạy 🚀",
            reply_markup=_menu_kb(), parse_mode="HTML")

    elif data == "pro5_back_menu":
        ctx.user_data["module_state"] = ST_MENU
        await query.edit_message_text("📋 *TTC PRO 5 - Menu chính:*", reply_markup=_menu_kb(), parse_mode="Markdown")

    return True


# ─────────────────────────────────────────────
#  MESSAGE HANDLER
# ─────────────────────────────────────────────
async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    state = ctx.user_data.get("module_state", "")
    if not state.startswith("pro5_"):
        return False

    uid = update.effective_user.id
    text = update.message.text.strip()

    if state == ST_TOKEN:
        await update.message.reply_text("⏳ Đang xác thực token...")
        user = get_user(uid)
        proxy = user["proxy_list"][0] if user["proxy_list"] else None
        ttc = TuongTacCheo(text, proxy); info = ttc.info()
        if info.get("status") == "success":
            user["ttc_token"] = text; user["ttc_username"] = info["user"]
            save_user(uid, user); ctx.user_data["module_state"] = ST_MENU
            await _send_main_menu(uid, ctx.application)
            await update.message.reply_text(
                f"✅ Đăng nhập thành công!\n👤 User: {info['user']}\n💰 Xu: {format(int(info['xu']), ',')}",
                reply_markup=_menu_kb(),
            )
        else:
            await update.message.reply_text("❌ Token không hợp lệ! Thử lại.",
                                             reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")]]))
            ctx.user_data["module_state"] = ST_MENU

    elif state == ST_COOKIE:
        await update.message.reply_text("⏳ Đang xử lý cookie...")
        user = get_user(uid)
        proxy = user["proxy_list"][0] if user["proxy_list"] else None
        try:
            fb = Facebook(text, proxy); count, profiles = fb.get_profile()
            if count == 0:
                await update.message.reply_text("❌ Cookie không hợp lệ hoặc không tìm thấy Page!",
                                                 reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")]]))
                ctx.user_data["module_state"] = ST_MENU; return True

            sopage = text.split(";"); cookies_values = {}
            for item in sopage:
                kv = item.split("=")
                if len(kv) >= 2:
                    cookies_values[kv[0].strip()] = "=".join(kv[1:]).strip()

            new_cookies = []
            for profile in profiles:
                sb = f"sb={cookies_values.get('sb', '')}"; datr = f"datr={cookies_values.get('datr', '')}"
                c_user = f"c_user={cookies_values.get('c_user', '')}"; wd = f"wd={cookies_values.get('wd', '')}"
                xs = f"xs={cookies_values.get('xs', '')}"; fr = f"fr={cookies_values.get('fr', '')}"
                cookie_built = f"{sb};{datr};{c_user};{wd};{xs};{fr};i_user={profile['profile']['id']};"
                new_cookies.append(cookie_built)

            user["cookies"].extend(new_cookies)
            user["cookies"] = list(dict.fromkeys(user["cookies"]))
            save_user(uid, user)
            page_list = "\n".join([f"  • {p['profile']['name']} (UID: {p['profile']['id']})" for p in profiles])
            await update.message.reply_text(
                f"✅ Đã thêm {len(new_cookies)} cookie!\n\n📋 Pages tìm thấy:\n{page_list}\n\nTổng cookie: {len(user['cookies'])}",
                reply_markup=_menu_kb(),
            )
        except Exception as e:
            await update.message.reply_text(f"❌ Lỗi xử lý cookie: {str(e)}",
                                             reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="pro5_back_menu")]]))
        ctx.user_data["module_state"] = ST_MENU

    elif state == ST_PROXY:
        lines = [l.strip() for l in text.splitlines() if l.strip()]
        user = get_user(uid); ok, fail = [], []
        await update.message.reply_text(f"⏳ Đang kiểm tra {len(lines)} proxy...")
        for proxy in lines:
            try:
                check = check_proxy(proxy)
                (ok if check["status"] == "success" else fail).append(proxy)
            except:
                fail.append(proxy)
        user["proxy_list"].extend(ok); user["proxy_list"] = list(dict.fromkeys(user["proxy_list"]))
        save_user(uid, user); ctx.user_data["module_state"] = ST_MENU
        await _send_main_menu(uid, ctx.application)
        await update.message.reply_text(
            f"✅ Proxy hợp lệ: {len(ok)}\n❌ Proxy lỗi: {len(fail)}\n\nTổng proxy: {len(user['proxy_list'])}",
            reply_markup=_menu_kb(),
        )

    elif state == ST_TASKS:
        valid = set("0123456789"); tasks = "".join(c for c in text if c in valid)
        if not tasks:
            await update.message.reply_text("❌ Không hợp lệ! Nhập lại (VD: 123):"); return True
        user = get_user(uid); user["settings"]["nhiemvu"] = tasks; save_user(uid, user)
        ctx.user_data["module_state"] = ST_DELAY_MIN
        await update.message.reply_text(f"✅ Nhiệm vụ: `{tasks}`\n\n⏱ *Nhập Delay MIN (giây):*", parse_mode="Markdown")

    elif state == ST_DELAY_MIN:
        try:
            val = int(text); ctx.user_data["pro5_dmin"] = val; ctx.user_data["module_state"] = ST_DELAY_MAX
            await update.message.reply_text(f"✅ Delay Min: {val}s\n\n*Nhập Delay MAX (giây):*", parse_mode="Markdown")
        except:
            await update.message.reply_text("❌ Nhập số nguyên!")

    elif state == ST_DELAY_MAX:
        try:
            val = int(text); dmin = ctx.user_data.get("pro5_dmin", 3)
            if val < dmin: await update.message.reply_text(f"❌ Delay Max phải >= {dmin}!"); return True
            ctx.user_data["pro5_dmax"] = val; ctx.user_data["module_state"] = ST_JOB_BLOCK
            await update.message.reply_text(f"✅ Delay: {dmin}s - {val}s\n\n*Nhập số Jobs trước khi chống block:*", parse_mode="Markdown")
        except:
            await update.message.reply_text("❌ Nhập số nguyên!")

    elif state == ST_JOB_BLOCK:
        try:
            val = int(text)
            if val <= 1: await update.message.reply_text("❌ Phải > 1!"); return True
            ctx.user_data["pro5_jblock"] = val; ctx.user_data["module_state"] = ST_DELAY_BLOCK
            await update.message.reply_text(f"✅ Jobs/Block: {val}\n\n*Nhập thời gian nghỉ chống block (giây):*", parse_mode="Markdown")
        except:
            await update.message.reply_text("❌ Nhập số nguyên!")

    elif state == ST_DELAY_BLOCK:
        try:
            val = int(text); ctx.user_data["pro5_dblock"] = val; ctx.user_data["module_state"] = ST_JOB_BREAK
            await update.message.reply_text(f"✅ Delay Block: {val}s\n\n*Nhập số Jobs trước khi chuyển Page:*", parse_mode="Markdown")
        except:
            await update.message.reply_text("❌ Nhập số nguyên!")

    elif state == ST_JOB_BREAK:
        try:
            val = int(text)
            if val <= 1: await update.message.reply_text("❌ Phải > 1!"); return True
            ctx.user_data["pro5_jbreak"] = val
            ctx.user_data["module_state"] = ST_JOBS_DONE
            await update.message.reply_text(
                f"✅ Jobs/Page: {val}\n\n"
                f"🏁 <b>Dừng sau bao nhiêu job thành công?</b>\n"
                f"(VD: <code>50</code> — dừng khi đủ 50 job thành công)\n"
                f"Nhập <code>0</code> = chạy không giới hạn:",
                parse_mode="HTML")
        except:
            await update.message.reply_text("❌ Nhập số nguyên!")

    elif state == ST_JOBS_DONE:
        try:
            val = int(text); assert val >= 0
            ctx.user_data["pro5_jobs_done"] = val
            ctx.user_data["module_state"] = ST_REPEAT
            await update.message.reply_text(
                f"✅ Dừng sau: <b>{'Không giới hạn' if val == 0 else str(val) + ' job'}</b>\n\n"
                f"🔄 <b>Lặp lại khi hết vòng?</b>\n"
                f"(Khi chạy hết tất cả page, có bắt đầu lại từ đầu không?)",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("✅ Có, lặp lại", callback_data="pro5_repeat_yes")],
                    [InlineKeyboardButton("❌ Không, dừng hẳn", callback_data="pro5_repeat_no")],
                ]))
        except:
            await update.message.reply_text("❌ Nhập số >= 0!")

    elif state == ST_CAPTCHA_KEY:
        user = get_user(uid); s = user["settings"]
        s["apikey"] = text
        s["delay"] = [ctx.user_data.get("pro5_dmin", 3), ctx.user_data.get("pro5_dmax", 8)]
        s["JobbBlock"] = ctx.user_data.get("pro5_jblock", 10)
        s["DelayBlock"] = ctx.user_data.get("pro5_dblock", 30)
        s["JobBreak"] = ctx.user_data.get("pro5_jbreak", 5)
        save_user(uid, user); ctx.user_data["module_state"] = ST_MENU
        await update.message.reply_text("✅ Đã lưu toàn bộ cấu hình!\n\nSẵn sàng chạy 🚀", parse_mode="HTML")
        await _send_main_menu(uid, ctx.application)

    return True
