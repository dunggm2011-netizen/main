"""
system_db.py — Database trung tâm cho toàn bộ hệ thống
Quản lý: users, keys, nạp tiền, bảng xếp hạng, admin, bank
"""
import json, os, time, uuid, hashlib
from datetime import datetime, timedelta
from .crypto_utils import save_encrypted, load_encrypted

_MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
_BASE_DIR   = os.path.dirname(_MODULE_DIR)
DB_DIR      = os.path.join(_BASE_DIR, "data", "system")
os.makedirs(DB_DIR, exist_ok=True)

# ── File paths ────────────────────────────────────────
F_USERS    = f"{DB_DIR}/users.json"
F_KEYS     = f"{DB_DIR}/keys.json"
F_DEPOSIT  = f"{DB_DIR}/deposits.json"
F_RANK     = f"{DB_DIR}/ranking.json"
F_BANK     = f"{DB_DIR}/bank.json"
F_NOTIF    = f"{DB_DIR}/notifications.json"
F_REFERRAL = f"{DB_DIR}/referrals.json"

# ── Helpers ───────────────────────────────────────────
def _load(path, default=None):
    return load_encrypted(path, default if default is not None else {})

def _save(path, data):
    save_encrypted(path, data)

def now_ts():
    return int(time.time())

def ts_to_str(ts):
    try:
        if not ts or ts <= 0: return "Không có"
        # Giới hạn timestamp hợp lệ (tránh OverflowError)
        if ts > 32503680000: ts = 32503680000  # Max: 3000-01-01
        return datetime.fromtimestamp(ts).strftime("%d/%m/%Y %H:%M")
    except (OSError, OverflowError, ValueError):
        return "Không xác định"

# ════════════════════════════════════════════════════
#  USERS
# ════════════════════════════════════════════════════
def get_user(uid: int) -> dict:
    users = _load(F_USERS, {})
    k = str(uid)
    if k not in users:
        users[k] = {
            "uid": uid,
            "balance": 0.0,        # số dư (VND/1000 = k)
            "api_key": _gen_apikey(uid),
            "vip_key": None,
            "vip_expire": 0,       # timestamp hết hạn VIP
            "vip_type": None,      # "day","month","year","free"
            "free_expire": 0,      # key free tính bằng giờ
            "ref_code": _gen_ref(uid),
            "ref_by": None,
            "created_at": now_ts(),
            "total_earned_bumx": 0,   # VND
            "total_earned_tds": 0,    # xu
            "total_earned_ttc": 0,    # xu
            "total_earned_xworld": {"USDT":0,"BUILD":0,"WORLD":0},
            "pending_deposit": None,
        }
        _save(F_USERS, users)
    return users[k]

def save_user(uid: int, data: dict):
    users = _load(F_USERS, {})
    users[str(uid)] = data
    _save(F_USERS, users)


# ══════════════════════════════════════════════════════
#  CONFIG: Giá key VIP & Mốc thưởng bảng xếp hạng
# ══════════════════════════════════════════════════════
F_CONFIG = f"{DB_DIR}/bot_config.json"

_DEFAULT_CONFIG = {
    "key_price": {
        "day":   1,    "month": 25,   "year":  250,
    },
    "rank_reward": {
        "top1_pct": 5, "top2_pct": 3, "top3_pct": 2,
    },
    "rank_top_n": 50,
}

def get_bot_config() -> dict:
    cfg = _read(F_CONFIG, {})
    for k, v in _DEFAULT_CONFIG.items():
        if k not in cfg: cfg[k] = v
    return cfg

def save_bot_config(cfg: dict): _write(F_CONFIG, cfg)
def get_key_prices() -> dict:   return get_bot_config().get("key_price", _DEFAULT_CONFIG["key_price"])
def get_rank_rewards() -> dict: return get_bot_config().get("rank_reward", _DEFAULT_CONFIG["rank_reward"])

def get_all_users() -> dict:
    return _load(F_USERS, {})

def _gen_apikey(uid: int) -> str:
    raw = f"APIKEY-{uid}-{uuid.uuid4().hex[:8].upper()}"
    return raw

def _gen_ref(uid: int) -> str:
    return f"REF{uid}"

# ── Kiểm tra quyền truy cập ──────────────────────────
def check_access(uid: int, admin_ids: list) -> dict:
    """
    Trả về dict:
      ok: True/False
      reason: "admin"|"vip"|"api_key"|"free"|"no_key"
      expire_str: thời gian hết hạn nếu có
    """
    if uid in admin_ids:
        return {"ok": True, "reason": "admin"}
    u = get_user(uid)
    t = now_ts()
    # VIP key còn hạn
    if u.get("vip_expire", 0) > t:
        return {"ok": True, "reason": "vip",
                "expire_str": ts_to_str(u["vip_expire"])}
    # Free key còn giờ
    if u.get("free_expire", 0) > t:
        remaining = u["free_expire"] - t
        h_left    = int(remaining // 3600)
        m_left    = int((remaining % 3600) // 60)
        return {"ok": True, "reason": "free",
                "expire_str": ts_to_str(u["free_expire"]),
                "hours_left": h_left, "minutes_left": m_left}
    # API key còn tiền (balance > 0)
    if u.get("balance", 0) > 0:
        return {"ok": True, "reason": "api_key",
                "balance": u["balance"]}
    return {"ok": False, "reason": "no_key"}

# ── Trừ phí API key ──────────────────────────────────
def charge_api_key(uid: int, tool: str, amount_earned, coin="VND") -> float:
    """
    Trừ 10% thu nhập từ số dư API key.
    tool: "bumx"|"tds"|"ttc"|"xworld"
    amount_earned: số tiền/xu kiếm được
    coin: "VND"|"xu"|"USDT"|"BUILD"|"WORLD"
    Trả về số tiền đã trừ (k đồng)
    """
    u = get_user(uid)
    now = now_ts()
    # VIP không trừ phí
    if u.get("vip_expire", 0) > now:
        return 0
    # Free key không trừ phí
    if u.get("free_expire", 0) > now:
        return 0
    # Chỉ trừ khi dùng API key (balance > 0)
    if u.get("balance", 0) <= 0:
        return 0

    charge_vnd = 0.0
    if tool == "bumx" and coin == "VND":
        # 10đ kiếm → trừ 0.001k; 10000đ → trừ 1k
        charge_vnd = amount_earned * 0.1 / 1000
    elif tool in ("tds", "ttc") and coin == "xu":
        # 1,000,000 xu → trừ 1k (10%)
        # 100,000 xu → trừ 0.1k
        charge_vnd = amount_earned / 1_000_000 * 1.0
    elif tool == "xworld":
        if coin == "USDT":
            charge_vnd = amount_earned * 0.1 * 23  # ~23k/usdt
        elif coin == "BUILD":
            charge_vnd = amount_earned * 0.1 * 0.1
        elif coin == "WORLD":
            charge_vnd = amount_earned * 0.1 * 1
        else:
            charge_vnd = 0.01  # mỗi lượt đặt ~10đ = 0.01k

    if charge_vnd <= 0:
        return 0

    charge_vnd = round(charge_vnd, 4)
    u["balance"] = max(0, round(u.get("balance", 0) - charge_vnd, 4))
    save_user(uid, u)
    return charge_vnd

def add_balance(uid: int, amount_k: float, note=""):
    u = get_user(uid)
    u["balance"] = round(u.get("balance", 0) + amount_k, 2)
    save_user(uid, u)

# ── Cập nhật thu nhập ─────────────────────────────────
def update_earnings(uid: int, tool: str, amount, coin="VND"):
    u = get_user(uid)
    if tool == "bumx":
        u["total_earned_bumx"] = u.get("total_earned_bumx", 0) + amount
    elif tool == "tds":
        u["total_earned_tds"] = u.get("total_earned_tds", 0) + amount
    elif tool == "ttc":
        u["total_earned_ttc"] = u.get("total_earned_ttc", 0) + amount
    elif tool == "xworld":
        earned = u.get("total_earned_xworld", {"USDT":0,"BUILD":0,"WORLD":0})
        earned[coin] = earned.get(coin, 0) + amount
        u["total_earned_xworld"] = earned
    save_user(uid, u)

# ════════════════════════════════════════════════════
#  VIP KEYS
# ════════════════════════════════════════════════════
VIP_PRICES = {
    "day":   1,    # 1k/ngày
    "month": 25,   # 25k/tháng
    "year":  250,  # 250k/năm
}
VIP_DAYS = {"day":1, "month":30, "year":365}

def create_vip_key(key_name: str, uid: int, days: int,
                   created_by: int, reason: str = "") -> dict:
    keys = _load(F_KEYS, {})
    expire_ts = now_ts() + days * 86400
    keys[key_name] = {
        "name": key_name,
        "uid": uid,
        "days": days,
        "expire": expire_ts,
        "created_by": created_by,
        "reason": reason,
        "created_at": now_ts(),
        "active": True,
    }
    _save(F_KEYS, keys)
    # Gán key cho user
    u = get_user(uid)
    u["vip_key"] = key_name
    u["vip_expire"] = expire_ts
    u["vip_type"] = "vip"
    save_user(uid, u)
    return keys[key_name]

def delete_vip_key(key_name: str, reason: str = ""):
    keys = _load(F_KEYS, {})
    if key_name in keys:
        # Xóa khỏi user
        uid = keys[key_name].get("uid")
        if uid:
            u = get_user(uid)
            if u.get("vip_key") == key_name:
                u["vip_key"] = None
                u["vip_expire"] = 0
                save_user(uid, u)
        del keys[key_name]
        _save(F_KEYS, keys)
        return True
    return False

def get_key_info(key_name: str) -> dict:
    keys = _load(F_KEYS, {})
    return keys.get(key_name)

def activate_free_key(uid: int, hours: int = 24):
    """
    Kích hoạt key free theo giờ.
    hours=24 → key 24h (vượt 2 link)
    hours=12 → key 12h (vượt 1 link)
    Nếu còn key cũ chưa hết, cộng thêm.
    """
    u   = get_user(uid)
    now = now_ts()
    cur = u.get("free_expire", 0)
    # Nếu còn hạn → cộng thêm, không bị mất
    if cur > now:
        u["free_expire"] = cur + hours * 3600
    else:
        u["free_expire"] = now + hours * 3600
    u["free_expire_hours"] = hours   # Lưu loại key để hiển thị
    u["vip_type"] = "free"
    save_user(uid, u)

def use_vip_key(uid: int, key_name: str) -> dict:
    """Người dùng nhập key VIP"""
    keys = _load(F_KEYS, {})
    if key_name not in keys:
        return {"ok": False, "msg": "❌ Key không tồn tại!"}
    k = keys[key_name]
    if not k.get("active"):
        return {"ok": False, "msg": "❌ Key đã bị vô hiệu hóa!"}
    if k.get("uid") and k["uid"] != uid:
        return {"ok": False, "msg": "❌ Key này không dành cho bạn!"}
    if k.get("expire", 0) < now_ts():
        return {"ok": False, "msg": "❌ Key đã hết hạn!"}
    # Gán cho user
    u = get_user(uid)
    u["vip_key"] = key_name
    u["vip_expire"] = k["expire"]
    u["vip_type"] = "vip"
    save_user(uid, u)
    return {"ok": True, "msg": f"✅ Kích hoạt Key thành công!\n⏰ Hết hạn: {ts_to_str(k['expire'])}"}

# ════════════════════════════════════════════════════
#  DEPOSIT — NẠP TIỀN
# ════════════════════════════════════════════════════
def create_deposit(uid: int, amount_k: float) -> dict:
    deps = _load(F_DEPOSIT, {})
    dep_id = f"NAP{uid}{int(time.time())}"
    content = f"chucmaymansongdai {uid}"
    deps[dep_id] = {
        "dep_id": dep_id,
        "uid": uid,
        "amount_k": amount_k,
        "content": content,
        "status": "pending",   # pending|approved|rejected|cancelled
        "created_at": now_ts(),
        "approved_at": None,
        "approved_by": None,
        "reject_reason": None,
        "img_proof": None,
    }
    _save(F_DEPOSIT, deps)
    # Lưu vào user
    u = get_user(uid)
    u["pending_deposit"] = dep_id
    save_user(uid, u)
    return deps[dep_id]

def approve_deposit(dep_id: str, admin_id: int) -> dict:
    deps = _load(F_DEPOSIT, {})
    if dep_id not in deps:
        return {"ok": False, "msg": "❌ Không tìm thấy yêu cầu!"}
    d = deps[dep_id]
    if d["status"] != "pending":
        return {"ok": False, "msg": f"❌ Trạng thái: {d['status']}"}
    d["status"] = "approved"
    d["approved_at"] = now_ts()
    d["approved_by"] = admin_id
    _save(F_DEPOSIT, deps)
    # Cộng tiền + referral
    uid = d["uid"]
    amount = d["amount_k"]
    add_balance(uid, amount, note=f"Nạp #{dep_id}")
    # Hoa hồng giới thiệu 10%
    u = get_user(uid)
    ref_by = u.get("ref_by")
    if ref_by:
        add_balance(ref_by, round(amount * 0.1, 2), note=f"Hoa hồng từ {uid}")
    u["pending_deposit"] = None
    save_user(uid, u)
    return {"ok": True, "msg": f"✅ Duyệt {amount}k cho user {uid}"}

def reject_deposit(dep_id: str, admin_id: int, reason: str) -> dict:
    deps = _load(F_DEPOSIT, {})
    if dep_id not in deps:
        return {"ok": False, "msg": "❌ Không tìm thấy!"}
    d = deps[dep_id]
    d["status"] = "rejected"
    d["reject_reason"] = reason
    d["approved_by"] = admin_id
    _save(F_DEPOSIT, deps)
    uid = d["uid"]
    u = get_user(uid)
    u["pending_deposit"] = None
    save_user(uid, u)
    return {"ok": True}

def get_pending_deposits() -> list:
    deps = _load(F_DEPOSIT, {})
    return [d for d in deps.values() if d["status"] == "pending"]

def get_deposit(dep_id: str) -> dict:
    return _load(F_DEPOSIT, {}).get(dep_id)

# ════════════════════════════════════════════════════
#  BANK — Thông tin ngân hàng admin
# ════════════════════════════════════════════════════
def get_bank() -> dict:
    return _load(F_BANK, {
        "bank_name": "Vietcombank",
        "account_no": "1234567890",
        "account_name": "NGUYEN VAN A",
        "branch": "Chi nhánh HCM",
    })

def set_bank(bank_name: str, account_no: str, account_name: str,
             bin_code: str = "", branch: str = ""):
    """Lưu thông tin ngân hàng — CHỈ admin chính gọi hàm này"""
    _save(F_BANK, {
        "bank_name":    bank_name,
        "account_no":   account_no,
        "account_name": account_name,
        "bin":          bin_code,
        "branch":       branch,
    })

def get_qr_url(amount_k: float, content: str) -> str:
    """Tạo URL QR VietQR dùng BIN code để chính xác nhất"""
    bank = get_bank()
    import urllib.parse
    amount_vnd = int(amount_k * 1000)
    enc_content = urllib.parse.quote(content)
    enc_name    = urllib.parse.quote(bank["account_name"])
    # Ưu tiên dùng BIN (chính xác), fallback về tên ngân hàng
    bin_code = bank.get("bin", "")
    if bin_code:
        # API VietQR dùng BIN: https://api.vietqr.io/image/{BIN}-{STK}-compact2.jpg
        url = (f"https://api.vietqr.io/image/{bin_code}-{bank['account_no']}-compact2.jpg"
               f"?amount={amount_vnd}&addInfo={enc_content}&accountName={enc_name}")
    else:
        # Fallback tên ngân hàng
        bank_map = {
            "Vietcombank":"VCB","Techcombank":"TCB","MBBank":"MB",
            "Agribank":"AGR","BIDV":"BIDV","VPBank":"VPB","TPBank":"TPB",
            "ACB":"ACB","Sacombank":"STB","VietinBank":"CTG",
        }
        bank_id = bank_map.get(bank["bank_name"], bank["bank_name"])
        url = (f"https://img.vietqr.io/image/{bank_id}-{bank['account_no']}-compact2.png"
               f"?amount={amount_vnd}&addInfo={enc_content}&accountName={enc_name}")
    return url

# ════════════════════════════════════════════════════
#  RANKING — Bảng xếp hạng
# ════════════════════════════════════════════════════
def get_ranking(tool: str, coin: str = "xu", top_n: int = 50) -> list:
    """
    Trả về top N người dùng không cần đạt mốc.
    Tất cả user có thu nhập > 0 đều có tên trong bảng.
    top_n mặc định = 50
    """
    users = get_all_users()
    rows  = []
    for uid_str, u in users.items():
        try:
            uid  = int(uid_str)
            name = u.get("name") or u.get("username") or f"User#{uid_str[-4:]}"
            val  = 0.0
            if tool == "bumx":
                val = float(u.get("total_earned_bumx", 0))
            elif tool == "tds":
                val = float(u.get("total_earned_tds", 0))
            elif tool == "ttc":
                val = float(u.get("total_earned_ttc", 0))
            elif tool == "xworld":
                xw = u.get("total_earned_xworld", {})
                if isinstance(xw, dict):
                    val = float(xw.get(coin, 0))
                else:
                    val = float(u.get(f"total_earned_xworld_{coin.lower()}", 0))
            if val > 0:
                rows.append({"uid": uid, "name": name, "val": val})
        except: pass
    rows.sort(key=lambda x: x["val"], reverse=True)
    return rows[:top_n]


def apply_rank_bonus(tool: str, coin: str = "xu"):
    """Trả thưởng top 3 hàng tuần"""
    ranking = get_ranking(tool, coin, top_n=3)
    for i, row in enumerate(ranking, 1):
        uid = row["uid"]
        val = row["val"]
        pct = RANK_BONUS.get(i, 0)
        bonus_k = 0
        if tool == "bumx":
            bonus_k = val * pct / 1000
        elif tool in ("tds", "ttc"):
            bonus_k = val / 1_000_000 * pct * 10
        elif tool == "xworld":
            if coin == "USDT": bonus_k = val * pct * 23
            elif coin == "BUILD": bonus_k = val * pct * 0.1
            elif coin == "WORLD": bonus_k = val * pct
        if bonus_k > 0:
            add_balance(uid, round(bonus_k, 2), note=f"Thưởng top {i} {tool}")

# ════════════════════════════════════════════════════
#  ADMIN
# ════════════════════════════════════════════════════
F_ADMINS = f"{DB_DIR}/admins.json"

def get_admins() -> dict:
    return _load(F_ADMINS, {"main": [], "sub": []})

def is_main_admin(uid: int, main_admins: list) -> bool:
    return uid in main_admins

def is_sub_admin(uid: int) -> bool:
    admins = get_admins()
    return uid in admins.get("sub", [])

def add_sub_admin(uid: int) -> bool:
    admins = get_admins()
    if uid not in admins.get("sub", []):
        admins.setdefault("sub", []).append(uid)
        _save(F_ADMINS, admins)
        return True
    return False

def remove_sub_admin(uid: int) -> bool:
    admins = get_admins()
    if uid in admins.get("sub", []):
        admins["sub"].remove(uid)
        _save(F_ADMINS, admins)
        return True
    return False


# ════════════════════════════════════════════════════
#  PHÂN QUYỀN ADMIN PHỤ
# ════════════════════════════════════════════════════

# Toàn bộ quyền admin chính có thể bật/tắt cho admin phụ
ALL_SUB_PERMISSIONS = {
    "create_key":     "🗝 Tạo Key VIP",
    "delete_key":     "🗑 Xóa Key",
    "check_key":      "🔍 Kiểm tra Key",
    "check_api":      "🔑 Kiểm tra API Key",
    "approve_deposit":"💰 Duyệt nạp tiền",
    "reject_deposit": "❌ Từ chối nạp tiền",
    "view_users":     "👥 Xem danh sách user",
    "view_stats":     "📊 Xem thống kê",
    "send_notif":     "📣 Gửi thông báo (cần main duyệt)",
}

# Quyền mặc định khi thêm admin phụ (tất cả bật)
DEFAULT_SUB_PERMS = list(ALL_SUB_PERMISSIONS.keys())

def get_sub_admin_perms(sub_uid: int) -> list:
    """Lấy danh sách quyền của 1 admin phụ"""
    admins = get_admins()
    perms_map = admins.get("sub_perms", {})
    return perms_map.get(str(sub_uid), DEFAULT_SUB_PERMS.copy())

def set_sub_admin_perms(sub_uid: int, perms: list):
    """Đặt quyền cho 1 admin phụ"""
    admins = get_admins()
    if "sub_perms" not in admins:
        admins["sub_perms"] = {}
    admins["sub_perms"][str(sub_uid)] = perms
    _save(F_ADMINS, admins)

def toggle_sub_perm(sub_uid: int, perm: str) -> bool:
    """Bật/tắt 1 quyền của admin phụ. Trả về trạng thái mới (True=bật)"""
    perms = get_sub_admin_perms(sub_uid)
    if perm in perms:
        perms.remove(perm)
        new_state = False
    else:
        perms.append(perm)
        new_state = True
    set_sub_admin_perms(sub_uid, perms)
    return new_state

def sub_has_perm(sub_uid: int, perm: str) -> bool:
    """Kiểm tra admin phụ có quyền không"""
    return perm in get_sub_admin_perms(sub_uid)

def get_all_sub_admins_with_perms() -> list:
    """Trả về danh sách {uid, perms} của tất cả admin phụ"""
    admins = get_admins()
    result = []
    for uid in admins.get("sub", []):
        result.append({
            "uid": uid,
            "perms": get_sub_admin_perms(uid)
        })
    return result

# ════════════════════════════════════════════════════
#  NOTIFICATIONS — Thông báo admin → users
# ════════════════════════════════════════════════════
def create_notification(content: str, by_uid: int,
                         img_url: str = None) -> str:
    notifs = _load(F_NOTIF, [])
    notif_id = f"NTF{int(time.time())}"
    notifs.append({
        "id": notif_id,
        "content": content,
        "by": by_uid,
        "img_url": img_url,
        "status": "pending",  # pending|approved|sent
        "created_at": now_ts(),
    })
    _save(F_NOTIF, notifs)
    return notif_id

def approve_notification(notif_id: str) -> dict:
    notifs = _load(F_NOTIF, [])
    for n in notifs:
        if n["id"] == notif_id:
            n["status"] = "approved"
            _save(F_NOTIF, notifs)
            return n
    return None

def get_pending_notifications() -> list:
    notifs = _load(F_NOTIF, [])
    return [n for n in notifs if n["status"] == "pending"]

# ════════════════════════════════════════════════════
#  REFERRAL
# ════════════════════════════════════════════════════
def register_referral(new_uid: int, ref_code: str) -> bool:
    users = get_all_users()
    # Tìm người có ref_code này
    ref_uid = None
    for uid_str, u in users.items():
        if u.get("ref_code") == ref_code:
            ref_uid = int(uid_str)
            break
    if not ref_uid or ref_uid == new_uid:
        return False
    u = get_user(new_uid)
    if u.get("ref_by"):
        return False  # Đã có người giới thiệu
    u["ref_by"] = ref_uid
    save_user(new_uid, u)
    return True

# ════════════════════════════════════════════════════
#  PENDING KEY REQUESTS (admin phụ tạo cần duyệt)
# ════════════════════════════════════════════════════
F_KEY_REQS = f"{DB_DIR}/key_requests.json"

def create_key_request(key_name: str, uid: int, days: int,
                        by_admin: int, reason: str) -> str:
    reqs = _load(F_KEY_REQS, {})
    req_id = f"KREQ{int(time.time())}"
    reqs[req_id] = {
        "req_id": req_id,
        "key_name": key_name,
        "uid": uid,
        "days": days,
        "by_admin": by_admin,
        "reason": reason,
        "status": "pending",
        "created_at": now_ts(),
        "action": "create",
    }
    _save(F_KEY_REQS, reqs)
    return req_id

def create_key_delete_request(key_name: str, by_admin: int, reason: str) -> str:
    reqs = _load(F_KEY_REQS, {})
    req_id = f"KDEL{int(time.time())}"
    reqs[req_id] = {
        "req_id": req_id,
        "key_name": key_name,
        "by_admin": by_admin,
        "reason": reason,
        "status": "pending",
        "created_at": now_ts(),
        "action": "delete",
    }
    _save(F_KEY_REQS, reqs)
    return req_id

def approve_key_request(req_id: str, main_admin: int) -> dict:
    reqs = _load(F_KEY_REQS, {})
    if req_id not in reqs:
        return {"ok": False, "msg": "Không tìm thấy yêu cầu"}
    r = reqs[req_id]
    r["status"] = "approved"
    _save(F_KEY_REQS, reqs)
    if r["action"] == "create":
        create_vip_key(r["key_name"], r["uid"], r["days"], main_admin, r["reason"])
        return {"ok": True, "msg": f"✅ Đã tạo key {r['key_name']}"}
    elif r["action"] == "delete":
        delete_vip_key(r["key_name"], r["reason"])
        return {"ok": True, "msg": f"✅ Đã xóa key {r['key_name']}"}
    return {"ok": False, "msg": "Action không hợp lệ"}

def get_pending_key_requests() -> list:
    reqs = _load(F_KEY_REQS, {})
    return [r for r in reqs.values() if r["status"] == "pending"]
