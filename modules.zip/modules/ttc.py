# modules/ttc.py
"""Module TTC Tương Tác Chéo — tuongtaccheo.com | Quản lý luồng chọn/xóa acc"""
import requests, re, os, json, base64, uuid, random, threading, asyncio, time
from time import sleep
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from .crypto_utils import save_encrypted, load_encrypted
try:
    from .key_system import update_earnings, deduct_api_fee
except: update_earnings=None; deduct_api_fee=None

BOT_TOKEN = ""

_MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
_BASE_DIR   = os.path.dirname(_MODULE_DIR)
DATA_DIR    = os.path.join(_BASE_DIR, "data", "ttc_users")
os.makedirs(DATA_DIR, exist_ok=True)

ST_CHON_NV="ttc_chon_nv"; ST_DELAY="ttc_delay"; ST_JOBBBLOCK="ttc_jobbblock"
ST_DELAYBLOCK="ttc_delayblock"; ST_JOBTHANHCONG="ttc_jobthanhcong"
ST_MAXFAIL="ttc_maxfail"; ST_ACCOUNTS="ttc_accounts"; ST_PROXY="ttc_proxy"
ST_ADD_TOKEN="ttc_add_token"; ST_ADD_COOKIE="ttc_add_cookie"  # Tách token/cookie

user_states: dict = {}

NV_MAP={"1":"likepostvipcheo","2":"likepostvipre","3":"camxucvipcheo","4":"camxuccheo",
        "5":"camxuccheobinhluan","6":"cmtcheo","7":"sharecheo","8":"likepagecheo",
        "9":"subcheo","0":"thamgianhomcheo","q":"danhgiapage","s":"sharecheokemnoidung"}

def user_file(uid,name): return os.path.join(DATA_DIR,f"{uid}_{name}.json")
def save_config(uid,s): save_encrypted(user_file(uid,"config"),s)
def load_config(uid): return load_encrypted(user_file(uid,"config"))
def save_accounts(uid,a): save_encrypted(user_file(uid,"accounts"),{"accounts":a})
def save_tokens(uid,t):   save_encrypted(user_file(uid,"tokens"),{"tokens":t})
def load_tokens(uid):
    d = load_encrypted(user_file(uid,"tokens"),{"tokens":[]})
    return d.get("tokens",[]) if isinstance(d,dict) else []
def save_cookies_fb(uid,fb_list): save_encrypted(user_file(uid,"cookies_fb"),{"cookies":fb_list})
def load_cookies_fb(uid):
    d = load_encrypted(user_file(uid,"cookies_fb"),{"cookies":[]})
    return d.get("cookies",[]) if isinstance(d,dict) else []
def load_accounts(uid):
    d=load_encrypted(user_file(uid,"accounts"),{"accounts":[]})
    # Support old plain list format
    if isinstance(d,list): return d
    accs=d.get("accounts",[])
    # Convert old [token,cookie] list to dict format
    result=[]
    for item in accs:
        if isinstance(item,(list,tuple)) and len(item)==2:
            result.append({"token":item[0],"cookie":item[1],"enabled":True,"label":f"acc{len(result)+1}"})
        elif isinstance(item,dict):
            result.append(item)
    return result
def save_proxies(uid,p): save_encrypted(user_file(uid,"proxies"),{"proxies":p})
def load_proxies(uid):
    d=load_encrypted(user_file(uid,"proxies"),{"proxies":[]})
    if isinstance(d,list): return d
    return d.get("proxies",[])
def get_active_accounts(uid):
    return [a for a in load_accounts(uid) if a.get("enabled",True)]

def parse_proxy(s):
    s=s.strip()
    if not s: return None
    if not s.startswith(("http://","https://","socks5://","socks4://")): s="http://"+s
    return {"http":s,"https":s}
def get_random_proxy(proxy_list):
    if not proxy_list: return None
    return parse_proxy(random.choice(proxy_list))
def get_state(uid):
    if uid not in user_states: user_states[uid]={"running":False,"stop_flag":False,"thread":None}
    return user_states[uid]

def encode_to_base64(_data): return base64.b64encode(_data.encode("utf-8")).decode("utf-8")

class Facebook:
    def __init__(self,cookie,proxies=None):
        try:
            self.fb_dtsg=""; self.jazoest=""; self.cookie=cookie; self.session=requests.Session()
            if proxies: self.session.proxies.update(proxies)
            self.id=self.cookie.split("c_user=")[1].split(";")[0]
            self.headers={"authority":"www.facebook.com","accept":"text/html","accept-language":"vi","user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36","Cookie":self.cookie}
            url=self.session.get(f"https://www.facebook.com/{self.id}",headers=self.headers).url
            response=self.session.get(url,headers=self.headers).text
            matches=re.findall(r'\["DTSGInitialData",\[\],\{"token":"(.*?)"\}',response)
            if matches: self.fb_dtsg+=matches[0]; self.jazoest+=re.findall(r'jazoest=(.*?)\"',response)[0]
        except: pass
    def info(self):
        try:
            get=self.session.get("https://www.facebook.com/me",headers=self.headers).url
            url="https://www.facebook.com/"+get.split("%2F")[-2]+"/" if "next=" in get else get
            resp=self.session.get(url,headers=self.headers,params={"locale":"vi_VN"})
            parsed=json.loads("{"+resp.text.split('"CurrentUserInitialData",[],{')[1].split("},")[0]+"}")
            id_=parsed.get("USER_ID","0"); name=parsed.get("NAME","")
            if id_=="0" and name=="": return "cookieout"
            elif "828281030927956" in resp.text: return "956"
            elif "1501092823525282" in resp.text: return "282"
            elif "601051028565049" in resp.text: return "spam"
            return {"status":"success","id":self.id,"name":name}
        except: pass
    def camxuc(self,id,type):
        try:
            reac={"LIKE":"1635855486666999","LOVE":"1678524932434102","CARE":"613557422527858","HAHA":"115940658764963","WOW":"478547315650144","SAD":"908563459236466","ANGRY":"444813342392137"}
            data={"av":self.id,"fb_dtsg":self.fb_dtsg,"jazoest":self.jazoest,"fb_api_caller_class":"RelayModern","fb_api_req_friendly_name":"CometUFIFeedbackReactMutation","variables":f'{{"input":{{"attribution_id_v2":"CometHomeRoot.react,comet.home,tap_tabbar,1719027162723,322693,4748854339,,","feedback_id":"{encode_to_base64("feedback:"+str(id))}","feedback_reaction_id":"{reac.get(type)}","feedback_source":"NEWS_FEED","is_tracking_encrypted":true,"tracking":[],"session_id":"{uuid.uuid4()}","actor_id":"{self.id}","client_mutation_id":"3"}},"useDefaultActor":false,"__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider":false}}','server_timestamps':'true','doc_id':'7047198228715224'}
            self.session.post("https://www.facebook.com/api/graphql/",headers=self.headers,data=data)
        except: pass
    def camxuccmt(self,id,type):
        try:
            reac={"LIKE":"1635855486666999","LOVE":"1678524932434102","CARE":"613557422527858","HAHA":"115940658764963","WOW":"478547315650144","SAD":"908563459236466","ANGRY":"444813342392137"}
            data={"av":self.id,"fb_dtsg":self.fb_dtsg,"jazoest":self.jazoest,"fb_api_caller_class":"RelayModern","fb_api_req_friendly_name":"CometUFIFeedbackReactMutation","variables":'{"input":{"feedback_id":"'+encode_to_base64("feedback:"+str(id))+'","feedback_reaction_id":"'+reac.get(type)+'","feedback_source":"TAHOE","is_tracking_encrypted":true,"tracking":[],"session_id":"'+str(uuid.uuid4())+'","actor_id":"'+self.id+'","client_mutation_id":"1"},"useDefaultActor":false,"__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider":false}','server_timestamps':'true','doc_id':'7616998081714004'}
            self.session.post("https://www.facebook.com/api/graphql/",headers=self.headers,data=data)
        except: pass
    def share(self,id):
        try:
            data={"av":self.id,"fb_dtsg":self.fb_dtsg,"jazoest":self.jazoest,"fb_api_caller_class":"RelayModern","fb_api_req_friendly_name":"ComposerStoryCreateMutation","variables":'{"input":{"idempotence_token":"'+str(uuid.uuid4())+'_FEED","source":"WWW","attachments":[{"link":{"share_scrape_data":"{\\"share_type\\":22,\\"share_params\\":['+id+']}"}}],"audience":{"privacy":{"allow":[],"base_state":"EVERYONE"}},"actor_id":"'+self.id+'","client_mutation_id":"3"},"feedLocation":"NEWSFEED","scale":1,"useDefaultActor":false,"isFeed":true}','server_timestamps':'true','doc_id':'8167261726632010'}
            self.session.post("https://www.facebook.com/api/graphql/",headers=self.headers,data=data)
        except: pass
    def likepage(self,id):
        try:
            data={"av":self.id,"fb_dtsg":self.fb_dtsg,"jazoest":self.jazoest,"fb_api_caller_class":"RelayModern","fb_api_req_friendly_name":"CometProfilePlusLikeMutation","variables":'{"input":{"is_tracking_encrypted":false,"page_id":"'+str(id)+'","source":null,"actor_id":"'+str(self.id)+'","client_mutation_id":"1"},"scale":1}','server_timestamps':'true','doc_id':'6716077648448761'}
            self.session.post("https://www.facebook.com/api/graphql/",data=data,headers=self.headers)
        except: pass
    def follow(self,id):
        try:
            data={"av":self.id,"fb_dtsg":self.fb_dtsg,"jazoest":self.jazoest,"fb_api_caller_class":"RelayModern","fb_api_req_friendly_name":"CometUserFollowMutation","variables":'{"input":{"subscribe_location":"PROFILE","subscribee_id":"'+str(id)+'","actor_id":"'+str(self.id)+'","client_mutation_id":"5"},"scale":1}','server_timestamps':'true','doc_id':'25581663504782089'}
            self.session.post("https://www.facebook.com/api/graphql/",data=data,headers=self.headers)
        except: pass
    def group(self,id):
        try:
            data={"av":self.id,"fb_dtsg":self.fb_dtsg,"jazoest":self.jazoest,"fb_api_caller_class":"RelayModern","fb_api_req_friendly_name":"GroupCometJoinForumMutation","variables":'{"feedType":"DISCUSSION","groupID":"'+id+'","input":{"action_source":"GROUP_MALL","group_id":"'+id+'","actor_id":"'+self.id+'","client_mutation_id":"1"}}','server_timestamps':'true','doc_id':'5853134681430324'}
            self.session.post("https://www.facebook.com/api/graphql/",headers=self.headers,data=data)
        except: pass
    def comment(self,id,msg):
        try:
            data={"av":self.id,"fb_dtsg":self.fb_dtsg,"jazoest":self.jazoest,"fb_api_caller_class":"RelayModern","fb_api_req_friendly_name":"useCometUFICreateCommentMutation","variables":f'{{"feedLocation":"DEDICATED_COMMENTING_SURFACE","feedbackSource":110,"input":{{"client_mutation_id":"4","actor_id":"{self.id}","feedback_id":"{encode_to_base64(f"feedback:{id}")}","message":{{"ranges":[],"text":"{msg}"}},"idempotence_token":"client:{uuid.uuid4()}","session_id":"{uuid.uuid4()}"}},"scale":1,"useDefaultActor":false}}','server_timestamps':'true','doc_id':'7994085080671282'}
            self.session.post("https://www.facebook.com/api/graphql/",headers=self.headers,data=data)
        except: pass
    def page_review(self,id,msg):
        try:
            data={"av":self.id,"fb_dtsg":self.fb_dtsg,"jazoest":self.jazoest,"variables":'{"input":{"composer_source_surface":"page_recommendation_tab","source":"WWW","audience":{"privacy":{"allow":[],"base_state":"EVERYONE"}},"message":{"ranges":[],"text":"'+msg+'"},"page_recommendation":{"page_id":"'+id+'","rec_type":"POSITIVE"},"actor_id":"'+self.id+'","client_mutation_id":"1"}}','doc_id':'5737011653023776'}
            self.session.post("https://www.facebook.com/api/graphql/",headers=self.headers,data=data)
        except: pass
    def sharend(self,id,msg):
        try:
            data={"av":self.id,"fb_dtsg":self.fb_dtsg,"jazoest":self.jazoest,"variables":'{"input":{"idempotence_token":"'+str(uuid.uuid4())+'_FEED","source":"WWW","attachments":[{"link":{"share_scrape_data":"{\\"share_type\\":22,\\"share_params\\":['+id+']}"}}],"audience":{"privacy":{"allow":[],"base_state":"EVERYONE"}},"message":{"ranges":[],"text":"'+msg+'"},"actor_id":"'+self.id+'","client_mutation_id":"1"},"feedLocation":"NEWSFEED","feedbackSource":1,"scale":1,"useDefaultActor":false,"isFeed":true}','doc_id':'29449903277934341'}
            self.session.post("https://www.facebook.com/api/graphql/",headers=self.headers,data=data)
        except: pass


class FacebookTTC:
    """Facebook class cho TTC — từ tool gốc ttcfb.py"""
    def __init__(self, cookie):
        import re as _re
        self.fb_dtsg = ''; self.jazoest = ''; self.cookie = cookie
        self.id = cookie.split('c_user=')[1].split(';')[0] if 'c_user=' in cookie else ''
        self.headers = {
            'accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
            'accept-language': 'vi',
            'sec-ch-ua': '"Chromium";v="106","Google Chrome";v="106","Not;A=Brand";v="99"',
            'sec-ch-ua-mobile': '?0', 'sec-ch-ua-platform': '"Windows"',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/106.0.0.0 Safari/537.36',
            'Cookie': cookie
        }
        import requests as _rq
        self.session = _rq.Session()
        try:
            resp = self.session.get('https://www.facebook.com/' + self.id, headers=self.headers, timeout=15).text
            m = _re.findall(r'\["DTSGInitialData",\[\],\{"token":"(.*?)"\}', resp)
            if m:
                self.fb_dtsg = m[0]
                j = _re.findall(r'jazoest=(.*?)"', resp)
                if j: self.jazoest = j[0]
        except: pass

    def info(self):
        import re as _re, json as _json
        try:
            get = self.session.get('https://www.facebook.com/me', headers=self.headers, timeout=15).url
            url = 'https://www.facebook.com/' + get.split('%2F')[-2] + '/' if 'next=' in get else get
            resp = self.session.get(url, headers=self.headers, timeout=15)
            parts = resp.text.split('"CurrentUserInitialData",[],{')
            if len(parts) < 2: return 'cookieout'
            parsed = _json.loads('{' + parts[1].split('},')[0] + '}')
            uid = parsed.get('USER_ID','0'); name = parsed.get('NAME','')
            if uid=='0' and not name: return 'cookieout'
            if '828281030927956' in resp.text: return '956'
            if '1501092823525282' in resp.text: return '282'
            if '601051028565049' in resp.text: return 'spam'
            return {'success':200,'id':uid,'name':name}
        except: return None

    def _post(self, data):
        try: self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data, timeout=15)
        except: pass

    def reaction(self, id, type='LIKE'):
        reac = {"LIKE":"1635855486666999","LOVE":"1678524932434102","CARE":"613557422527858",
                "HAHA":"115940658764963","WOW":"478547315650144","SAD":"908563459236466","ANGRY":"444813342392137"}
        fid = encode_to_base64('feedback:' + str(id))
        rid = reac.get(str(type).upper(), reac['LIKE'])
        sid = str(uuid.uuid4())
        v = ('{"input":{"attribution_id_v2":"CometHomeRoot.react,comet.home,tap_tabbar,1,,,",'
             '"feedback_id":"' + fid + '",'
             '"feedback_reaction_id":"' + rid + '",'
             '"feedback_source":"NEWS_FEED","is_tracking_encrypted":true,"tracking":[],'
             '"session_id":"' + sid + '",'
             '"actor_id":"' + str(self.id) + '",'
             '"client_mutation_id":"3"},'
             '"useDefaultActor":false,'
             '"__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider":false}')
        self._post({'av':self.id,'fb_dtsg':self.fb_dtsg,'jazoest':self.jazoest,
                    'fb_api_caller_class':'RelayModern',
                    'fb_api_req_friendly_name':'CometUFIFeedbackReactMutation',
                    'variables':v,'server_timestamps':'true','doc_id':'7047198228715224'})

    def reactioncmt(self, id, type='LIKE'):
        reac = {"LIKE":"1635855486666999","LOVE":"1678524932434102","CARE":"613557422527858",
                "HAHA":"115940658764963","WOW":"478547315650144","SAD":"908563459236466","ANGRY":"444813342392137"}
        fid = encode_to_base64('feedback:' + str(id))
        rid = reac.get(str(type).upper(), reac['LIKE'])
        v = ('{"input":{"feedback_id":"' + fid + '",'
             '"feedback_reaction_id":"' + rid + '",'
             '"feedback_source":"TAHOE","is_tracking_encrypted":true,"tracking":[],'
             '"session_id":"' + str(uuid.uuid4()) + '",'
             '"actor_id":"' + str(self.id) + '","client_mutation_id":"1"},'
             '"useDefaultActor":false,'
             '"__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider":false}')
        self._post({'av':self.id,'fb_dtsg':self.fb_dtsg,'jazoest':self.jazoest,
                    'fb_api_caller_class':'RelayModern',
                    'fb_api_req_friendly_name':'CometUFIFeedbackReactMutation',
                    'variables':v,'server_timestamps':'true','doc_id':'7616998081714004'})

    def comment(self, id, msg):
        fid = encode_to_base64('feedback:' + str(id))
        msg = str(msg).replace('"',' ').replace("'","'")
        v = ('{"feedLocation":"DEDICATED_COMMENTING_SURFACE","feedbackSource":110,"groupID":null,'
             '"input":{"client_mutation_id":"4","actor_id":"' + str(self.id) + '",'
             '"attachments":null,"feedback_id":"' + fid + '",'
             '"message":{"ranges":[],"text":"' + msg + '"},'
             '"is_tracking_encrypted":true,"tracking":[],'
             '"session_id":"' + str(uuid.uuid4()) + '"},'
             '"scale":1,"useDefaultActor":false}')
        self._post({'av':self.id,'fb_dtsg':self.fb_dtsg,'jazoest':self.jazoest,
                    'fb_api_caller_class':'RelayModern',
                    'fb_api_req_friendly_name':'useCometUFICreateCommentMutation',
                    'variables':v,'server_timestamps':'true','doc_id':'7994085080671282'})

    def share(self, id):
        v = ('{"input":{"composer_entry_point":"share_modal","composer_type":"share",'
             '"idempotence_token":"' + str(uuid.uuid4()) + '_FEED","source":"WWW",'
             '"attachments":[{"link":{"share_scrape_data":"{\\"share_type\\":22,\\"share_params\\":[' + str(id) + ']}"}}],'
             '"reshare_original_post":"RESHARE_ORIGINAL_POST",'
             '"audience":{"privacy":{"allow":[],"base_state":"EVERYONE","deny":[],"tag_expansion_state":"UNSPECIFIED"}},'
             '"actor_id":"' + str(self.id) + '","client_mutation_id":"3"},"feedLocation":"NEWSFEED"}')
        self._post({'av':self.id,'fb_dtsg':self.fb_dtsg,'jazoest':self.jazoest,
                    'fb_api_caller_class':'RelayModern',
                    'fb_api_req_friendly_name':'ComposerStoryCreateMutation',
                    'variables':v,'server_timestamps':'true','doc_id':'8167261726632010'})

    def likepage(self, id):
        v = '{"input":{"page_id":"'+str(id)+'","actor_id":"'+str(self.id)+'","client_mutation_id":"1"},"scale":1}'
        self._post({'av':self.id,'fb_dtsg':self.fb_dtsg,'jazoest':self.jazoest,
                    'fb_api_caller_class':'RelayModern',
                    'fb_api_req_friendly_name':'CometProfilePlusLikeMutation',
                    'variables':v,'server_timestamps':'true','doc_id':'6716077648448761'})

    def follow(self, id):
        v = '{"input":{"subscribee_id":"'+str(id)+'","actor_id":"'+str(self.id)+'","client_mutation_id":"5"},"scale":1}'
        self._post({'av':self.id,'fb_dtsg':self.fb_dtsg,'jazoest':self.jazoest,
                    'fb_api_caller_class':'RelayModern',
                    'fb_api_req_friendly_name':'CometUserFollowMutation',
                    'variables':v,'server_timestamps':'true','doc_id':'25581663504782089'})

    def group(self, id):
        v = '{"feedType":"DISCUSSION","groupID":"'+str(id)+'","input":{"group_id":"'+str(id)+'","actor_id":"'+str(self.id)+'","client_mutation_id":"1"}}'
        self._post({'av':self.id,'fb_dtsg':self.fb_dtsg,'jazoest':self.jazoest,
                    'fb_api_caller_class':'RelayModern',
                    'fb_api_req_friendly_name':'GroupCometJoinForumMutation',
                    'variables':v,'server_timestamps':'true','doc_id':'5853134681430324'})

    def page_review(self, id, msg):
        msg = str(msg).replace('"',' ')
        v = ('{"input":{"message":{"ranges":[],"text":"'+msg+'"},'
             '"page_recommendation":{"page_id":"'+str(id)+'","rec_type":"POSITIVE"},'
             '"actor_id":"'+str(self.id)+'","client_mutation_id":"1"},'
             '"feedLocation":"PAGE_SURFACE_RECOMMENDATIONS"}')
        self._post({'av':self.id,'fb_dtsg':self.fb_dtsg,'jazoest':self.jazoest,'variables':v,'doc_id':'5737011653023776'})

    def sharend(self, id, msg):
        msg = str(msg).replace('"',' ')
        v = ('{"input":{"composer_type":"share","idempotence_token":"'+str(uuid.uuid4())+'_FEED","source":"WWW",'
             '"attachments":[{"link":{"share_scrape_data":"{\\"share_type\\":22,\\"share_params\\":['+str(id)+']}"}}],'
             '"message":{"ranges":[],"text":"'+msg+'"},'
             '"actor_id":"'+str(self.id)+'","client_mutation_id":"1"},"feedLocation":"NEWSFEED"}')
        self._post({'av':self.id,'fb_dtsg':self.fb_dtsg,'jazoest':self.jazoest,
                    'variables':v,'server_timestamps':'true','doc_id':'29449903277934341'})


class TTC_Facebook:
    """
    TTC API client — hỗ trợ nickchay (đa luồng FB trên 1 token TTC).
    Theo tài liệu TTC:
      getjob: thêm ?nickchay=<fb_uid>
      nhanxu: thêm &nickchay=<fb_uid> vào body
    """
    def __init__(self, token, proxies=None):
        self.session   = requests.Session()
        self.thongtin  = {}
        self.cookie    = ""
        self.headers   = {}
        try:
            if proxies: self.session.proxies.update(proxies)
            resp = self.session.post(
                "https://tuongtaccheo.com/logintoken.php",
                headers={"Content-type": "application/x-www-form-urlencoded"},
                data={"access_token": token}, timeout=15)
            self.cookie   = resp.headers.get("Set-cookie", "")
            self.thongtin = resp.json()
            self.headers  = {
                "Host": "tuongtaccheo.com", "accept": "*/*",
                "origin": "https://tuongtaccheo.com",
                "x-requested-with": "XMLHttpRequest",
                "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "cookie": self.cookie,
            }
        except Exception as e:
            self.thongtin = {"status": "error", "mess": str(e)}

    def info(self):
        if self.thongtin.get("status") == "success":
            return self.thongtin
        return {"status": "error", "mess": self.thongtin.get("mess", "Token lỗi")}

    def add_uid(self, fb_uid):
        """
        Thêm UID Facebook vào TTC dùng nhapnick.php
        (endpoint chính xác theo tool gốc)
        """
        try:
            headers = {
                "Host": "tuongtaccheo.com",
                "accept": "*/*",
                "accept-language": "vi-VN,vi;q=0.9,en-US;q=0.6,en;q=0.5",
                "origin": "https://tuongtaccheo.com",
                "x-requested-with": "XMLHttpRequest",
                "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "referer": "https://tuongtaccheo.com/cauhinh/facebook.php",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/148.0.0.0 Safari/537.36",
                "cookie": self.cookie,
            }
            data = {"link": str(fb_uid), "loainick": "fb", "recaptcha": "1"}
            resp = self.session.post(
                "https://tuongtaccheo.com/cauhinh/nhapnick.php",
                headers=headers, data=data, timeout=30)
            text = resp.text.strip()
            if text == "1":
                return {"status": "success", "id": fb_uid}
            return {"status": "success", "id": fb_uid, "_note": text[:40]}
        except Exception as e:
            return {"status": "error", "msg": str(e)}

    def cauhinh(self, fb_uid):
        """Wrapper gọi add_uid (tương thích code cũ)"""
        return self.add_uid(fb_uid)

    def getjob(self, nv, nickchay=None):
        """
        Lấy job. Nếu nickchay được truyền vào → chạy đa luồng FB.
        URL: /kiemtien/{nv}/getpost.php?nickchay={fb_uid}
        """
        url = f"https://tuongtaccheo.com/kiemtien/{nv}/getpost.php"
        params = {}
        if nickchay:
            params["nickchay"] = str(nickchay)
        try:
            return self.session.get(url, headers=self.headers, params=params, timeout=15)
        except Exception as e:
            return None

    def nhanxu(self, id_, nv, nickchay=None):
        """
        Nhận xu. Nếu nickchay → gửi kèm nickchay trong body.
        Body: id=<job_id>&nickchay=<fb_uid>
        """
        try:
            xu_truoc = self.session.get(
                "https://tuongtaccheo.com/home.php",
                headers=self.headers, timeout=10).text.split('"soduchinh">')[1].split("<")[0]

            body = {"id": id_}
            if nickchay:
                body["nickchay"] = str(nickchay)

            resp = self.session.post(
                f"https://tuongtaccheo.com/kiemtien/{nv}/nhantien.php",
                headers=self.headers, data=body, timeout=15).json()

            xu_sau = self.session.get(
                "https://tuongtaccheo.com/home.php",
                headers=self.headers, timeout=10).text.split('"soduchinh">')[1].split("<")[0]

            if "mess" in resp:
                try:
                    if int(str(xu_sau).replace(",","")) > int(str(xu_truoc).replace(",","")):
                        parts = resp["mess"].split()
                        msg   = parts[-2] if len(parts) >= 2 else "0"
                        return {"status": "success", "msg": "+" + msg + " Xu", "xu": xu_sau}
                except: pass
            if resp.get("status") == "success":
                return {"status": "success", "msg": resp.get("msg", "OK"), "xu": xu_sau}
        except: pass
        return {"status": "error"}

def worker(uid, send_fn):
    # Lấy state từ user_states (nơi stop handler thao tác)
    # Đảm bảo user_states[uid] tồn tại
    if uid not in user_states:
        user_states[uid] = {"running": True, "stop_flag": False, "thread": None}
    _us = user_states[uid]
    _cfg        = load_config(uid) or {}
    settings    = _cfg.get("settings", _cfg) or {}
    # Dùng stop_flag từ user_states để dừng đúng
    def _should_stop():
        return user_states.get(uid, {}).get("stop_flag", False)
    # Load nhiemvu - nếu rỗng dùng tất cả loại job mặc định
    list_nv = settings.get("nhiemvu", []) or settings.get("list_nv", [])
    if not list_nv:
        list_nv = ["1","2","3","4","5","6"]

    def notify(msg):
        try: send_fn(uid, msg)
        except: pass

    def isleep(sec):
        end = __import__("time").time() + sec
        while __import__("time").time() < end:
            if _should_stop(): return
            __import__("time").sleep(min(0.5, end - __import__("time").time()))

    # ── Build pairs từ file lưu trữ ──
    tokens = [t for t in (load_tokens(uid) or []) if t.get("enabled", True)]
    fbs    = [f for f in (load_cookies_fb(uid) or []) if f.get("enabled", True)]

    list_ck = []
    for fb in fbs:
        cookie_str = fb.get("cookie","")
        name_fb    = fb.get("name","") or fb.get("name_fb","?")
        # Fix unicode tên
        try:
            name_fb = name_fb.encode('utf-8').decode('utf-8')
        except: pass
        binds = fb.get("token_binds", [])
        if not binds and tokens:
            binds = [0]   # Mặc định dùng token đầu
        for bi in binds:
            if bi < len(tokens):
                tok = tokens[bi]
                list_ck.append({
                    "token":   tok["token"],
                    "cookie":  cookie_str,
                    "name_fb": name_fb,
                    "name_ttc":tok.get("name","?"),
                })

    # Fallback: accounts cũ
    if not list_ck:
        for a in (load_accounts(uid) or []):
            if isinstance(a, dict) and a.get("enabled", True):
                list_ck.append({
                    "token":   a.get("token",""),
                    "cookie":  a.get("cookie",""),
                    "name_fb": a.get("name_fb","?"),
                    "name_ttc":a.get("label","?"),
                })

    if not list_ck:
        notify(f"❌ Chưa có tài khoản!\n"
               f"Token bật: {len(tokens)} | Cookie bật: {len(fbs)}\n"
               f"Vào 📂 Tài khoản → Cookie FB → chọn token cho từng cookie.")
        state["running"] = False
    try: save_config(uid, state)
    except: pass; return

    fields_map = {
        "1":"likepostcheo","2":"likepostcheo2","3":"reactcommentcheo",
        "4":"sharecheo","5":"subcheo","6":"likesubpagecheo",
        "7":"reactionpostcheo","8":"commentcheo","9":"subcheo","0":"thamgianhomcheo",
    }

    luong_idx = 0
    while not _should_stop():
        if not list_ck: notify("[TTC] Hết tài khoản!"); break
        if luong_idx >= len(list_ck): luong_idx = 0
        if luong_idx >= len(list_ck): break

        pair    = list_ck[luong_idx]
        token   = pair["token"]; cookie = pair["cookie"]
        luong   = luong_idx + 1

        ttc     = TTC_Facebook(token)
        info    = ttc.info()
        if info.get("status") != "success":
            notify(f"[TTC] L{luong} Token lỗi, bỏ qua!")
            list_ck.pop(luong_idx); continue

        name_ttc = info.get("data",{}).get("user","") or info.get("name","?")
        xu_ttc   = info.get("data",{}).get("sodu","?") or info.get("xu","?")
        try: xu_fmt = "{:,}".format(int(str(xu_ttc).replace(",","")))
        except: xu_fmt = str(xu_ttc)
        notify(f"[TTC] 🏃 L{luong} | TTC: {name_ttc} | Xu: {xu_fmt}")

        # Login FB
        try:
            fb_obj  = FacebookTTC(cookie)
            info_fb = fb_obj.info()
            id_fb   = info_fb.get("id","") if isinstance(info_fb,dict) else ""
            name_fb = info_fb.get("name","?") if isinstance(info_fb,dict) else "?"
            # Kiểm tra block/checkpoint
            if isinstance(info_fb, str) or (isinstance(info_fb,dict) and info_fb.get("status")!="success"):
                err_s = str(info_fb)
                if any(k in err_s for k in ["checkpoint","block","spam","cookieout","956","282"]):
                    notify(f"[TTC] 🚫 L{luong} Cookie bị block — đã xóa khỏi cấu hình!")
                    try:
                        _all_cks = load_cookies_fb(uid)
                        _all_cks = [x for x in _all_cks if x.get("cookie","") != cookie]
                        save_cookies_fb(uid, _all_cks)
                    except: pass
                    if pair in list_ck: list_ck.remove(pair)
                    luong_idx += 1; continue
        except:
            id_fb = ""; name_fb = "?"
        notify(f"[TTC] 👤 L{luong} | FB: {name_fb}")
        # Thêm UID vào TTC qua nhapnick.php
        _add_result = ttc.add_uid(id_fb or pair.get("name_fb",""))
        if _add_result.get("status") == "success":
            notify(f"[TTC] ✅ L{luong} Đã thêm UID {id_fb} vào TTC")
        else:
            notify(f"[TTC] ⚠️ L{luong} Thêm UID lỗi: {_add_result.get('msg','?')}, vẫn thử chạy...")

        stt = totalxu = JobFail = job_success_count = 0

        # Đúng fields map từ tool gốc
        fields_map = {
            "1": "likepostvipcheo",   # Like Vip
            "2": "likepostvipre",     # Like Thường
            "3": "camxucvipcheo",     # Cảm xúc Vip
            "4": "camxuccheo",        # Cảm xúc Thường
            "5": "camxuccheobinhluan",# Cảm xúc Comment
            "6": "cmtcheo",           # Comment
            "7": "sharecheo",         # Share
            "8": "likepagecheo",      # Like Page
            "9": "subcheo",           # Follow/Sub
            "0": "thamgianhomcheo",   # Tham gia nhóm
            "q": "danhgiapage",       # Review page
            "s": "sharecheokemnoidung", # Share nội dung
        }

        while not _should_stop():
            _nv  = list_nv if list_nv else list(fields_map.keys())[:6]
            random_nv = random.choice(_nv)
            fields    = fields_map.get(str(random_nv), "likepostvipcheo")

            try:
                getjob = ttc.getjob(fields, nickchay=id_fb)
                if not getjob: isleep(5); continue
            except Exception as _e:
                notify(f"[TTC] L{luong} Mạng lỗi: {str(_e)[:40]}, thử lại...")
                isleep(10); continue

            if "idpost" not in getjob.text and "idfb" not in getjob.text:
                try:
                    cd = getjob.json().get("countdown", 20) or 20
                    isleep(round(cd))
                except: isleep(20)
                continue

            try: gjson = getjob.json()
            except: isleep(5); continue
            if not isinstance(gjson, list): gjson = []

            for x in gjson:
                if _should_stop(): break

                # Lấy id đúng từ tool gốc
                idpost = x.get("idpost","") or x.get("idfb","") or ""
                if not idpost: continue
                id_  = idpost.split("_")[1] if "_" in idpost else idpost
                id   = idpost  # dùng để nhanxu

                # ── Thực hiện hành động FB TRƯỚC (giống tool gốc) ──
                try:
                    from .tds import Facebook as _FB
                    if random_nv in ("1","2"):
                        idfb_run = x.get("idfb","")
                        id_ = idfb_run.split("_")[1] if "_" in idfb_run else idfb_run
                        fb_obj.reaction(id_, "LIKE")
                        id = x.get("idpost", idpost)
                    elif random_nv == "3":
                        idfb_run = x.get("idfb","")
                        id_ = idfb_run.split("_")[1] if "_" in idfb_run else idfb_run
                        fb_obj.reaction(id_, x.get("loaicx","LIKE"))
                        id = x.get("idpost", idpost)
                    elif random_nv == "4":
                        id_ = idpost.split("_")[1] if "_" in idpost else idpost
                        fb_obj.reaction(id_, x.get("loaicx","LIKE"))
                    elif random_nv == "5":
                        id_ = idpost.split("_")[1] if "_" in idpost else idpost
                        fb_obj.reactioncmt(id_, x.get("loaicx","LIKE"))
                    elif random_nv == "6":
                        id_ = idpost.split("_")[1] if "_" in idpost else idpost
                        import json as _json
                        msg_cmt = _json.loads(x.get("nd","[\"Hay quá\"]"))[0]
                        fb_obj.comment(id_, msg_cmt)
                    elif random_nv == "7":
                        id_ = idpost.split("_")[1] if "_" in idpost else idpost
                        fb_obj.share(id_)
                    elif random_nv == "8":
                        id_ = idpost.split("_")[1] if "_" in idpost else idpost
                        fb_obj.likepage(id_)
                    elif random_nv == "9":
                        id_ = idpost.split("_")[1] if "_" in idpost else idpost
                        fb_obj.follow(id_)
                    elif random_nv == "0":
                        id_ = idpost.split("_")[1] if "_" in idpost else idpost
                        fb_obj.group(id_)
                    elif random_nv == "q":
                        uid_run = x.get("UID","")
                        id_ = uid_run.split("_")[1] if "_" in uid_run else uid_run
                        id  = uid_run
                        import json as _json
                        msg_rv = _json.loads(x.get("nd","[\"Tốt\"]"))[0]
                        fb_obj.page_review(id_, msg_rv)
                    elif random_nv == "s":
                        id_ = idpost.split("_")[1] if "_" in idpost else idpost
                        import json as _json
                        msg_sh = _json.loads(x.get("nd", '[""]')).pop() or ""
                        fb_obj.sharend(id_, msg_sh)
                except Exception: pass  # Hành động FB lỗi nhưng vẫn thử nhanxu

                # ── Nhận xu ──
                nhanxu = ttc.nhanxu(id, fields, nickchay=id_fb)
                if nhanxu.get("status") == "success":
                    msg_xu = nhanxu.get("msg",""); xu = nhanxu.get("xu","?")
                    try: totalxu += int(msg_xu.replace(" Xu","").replace("+","").strip())
                    except: pass
                    stt += 1; job_success_count += 1; JobFail = 0
                    notify(f"[TTC] L{luong} [{stt}] ✅ {fields.upper()} | {msg_xu} | Tổng: {format(totalxu,',')}")
                    if stt % 10 == 0:
                        notify(f"[TTC] L{luong} 📊 {stt} job | Xu: {format(int(str(xu).replace(',','')),',')} | Tổng phiên: {format(totalxu,',')}")
                    _max_done = int(settings.get("JobThanhCong", 99999))
                    if _max_done > 0 and job_success_count >= _max_done:
                        notify(f"[TTC] L{luong} Đủ {_max_done} job thành công!")
                        if pair in list_ck: list_ck.remove(pair)
                        break
                else:
                    JobFail += 1
                    notify(f"[TTC] L{luong} [{JobFail}] ❌ Lỗi nhận xu")

                _max_fail = int(settings.get("MaxFail", 99999))
                if _max_fail > 0 and JobFail >= _max_fail:
                    notify(f"[TTC] L{luong} Lỗi {JobFail} lần → bỏ qua!")
                    if pair in list_ck: list_ck.remove(pair)
                    break

                # Delay giữa job
                _delay = settings.get("delay", 5)
                if isinstance(_delay, list): _delay = _delay[0] if _delay else 5
                isleep(int(_delay))

                # Chống block
                if stt > 0 and stt % max(1, int(settings.get("JobbBlock",10))) == 0:
                    isleep(int(settings.get("DelayBlock", 30)))

        luong_idx += 1

    state["running"] = False
    save_config(uid, state)
    notify("[TTC] Bot đã dừng.")


