"""admin_handlers.py — Xử lý tất cả lệnh admin"""
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from . import system_db as db
from .system_db import now_ts, ts_to_str

# States
ST_ADD_SUB   = "adm_add_sub"
ST_CREATE_KEY_NAME = "adm_ck_name"
ST_CREATE_KEY_UID  = "adm_ck_uid"
ST_CREATE_KEY_DAYS = "adm_ck_days"
ST_CREATE_KEY_RSN  = "adm_ck_rsn"
ST_DEL_KEY_NAME    = "adm_dk_name"
ST_DEL_KEY_RSN     = "adm_dk_rsn"
ST_CHECK_KEY       = "adm_chk_key"
ST_BANK_NAME       = "adm_bank_name"
ST_BANK_NO         = "adm_bank_no"
ST_BANK_OWNER      = "adm_bank_owner"
ST_NOTIF_TEXT      = "adm_notif_txt"
ST_APPROVE_DEP     = "adm_approve_dep"
ST_REJECT_DEP      = "adm_reject_dep"

MAIN_ADMINS = []  # Inject từ main.py

def _is_main(uid): return uid in MAIN_ADMINS
def _is_sub(uid): return db.is_sub_admin(uid)
def _is_any_admin(uid): return _is_main(uid) or _is_sub(uid)

def _main_admin_kb(uid):
    rows = []
    if _is_main(uid):
        rows.append([
            InlineKeyboardButton("➕ Thêm admin phụ", callback_data="adm_add_sub"),
            InlineKeyboardButton("➖ Xóa admin phụ", callback_data="adm_del_sub"),
        ])
        rows.append([
            InlineKeyboardButton("🏦 Đổi ngân hàng",  callback_data="adm_set_bank"),
            InlineKeyboardButton("📣 Thông báo",       callback_data="adm_notif"),
        ])
        rows.append([
            InlineKeyboardButton("✅ Duyệt yêu cầu key",  callback_data="adm_approve_key_reqs"),
            InlineKeyboardButton("💰 Duyệt nạp tiền",     callback_data="adm_approve_deps"),
        ])
        rows.append([
            InlineKeyboardButton("🔐 Phân quyền admin phụ", callback_data="adm_manage_perms"),
        ])
        rows.append([
            InlineKeyboardButton("💰 Giá Key VIP",      callback_data="adm_price_edit"),
            InlineKeyboardButton("🏆 % thưởng BXH",     callback_data="adm_reward_edit"),
        ])
    # Admin phụ + chính đều có (admin phụ chỉ hiện quyền được bật)
    is_sub = not _is_main(uid) and _is_sub(uid)
    def _has(perm):
        if _is_main(uid): return True
        return db.sub_has_perm(uid, perm)

    if _has("create_key") or _has("delete_key"):
        row = []
        if _has("create_key"):
            row.append(InlineKeyboardButton("🗝 Tạo Key VIP", callback_data="adm_create_key"))
        if _has("delete_key"):
            row.append(InlineKeyboardButton("🗑 Xóa Key",     callback_data="adm_del_key"))
        if row: rows.append(row)

    if _has("check_key") or _has("check_api"):
        row = []
        if _has("check_key"):
            row.append(InlineKeyboardButton("🔍 Kiểm tra Key", callback_data="adm_check_key"))
        if _has("check_api"):
            row.append(InlineKeyboardButton("🔑 Kiểm tra API", callback_data="adm_check_api"))
        if row: rows.append(row)

    if _has("approve_deposit") or _has("reject_deposit"):
        rows.append([InlineKeyboardButton("💰 Duyệt nạp tiền", callback_data="adm_approve_deps")])

    if _has("view_stats"):
        rows.append([InlineKeyboardButton("📊 Thống kê user", callback_data="adm_stats")])

    if _has("send_notif") and is_sub:
        rows.append([InlineKeyboardButton("📣 Gửi thông báo (cần duyệt)", callback_data="adm_notif")])

    rows.append([InlineKeyboardButton("🔙 Quay lại", callback_data="back_home")])
    return InlineKeyboardMarkup(rows)

# ── Bank helper ──────────────────────────────────────
BANK_BIN_MAP = {
    "Vietcombank": "970436",  "Techcombank": "970407",  "MBBank":   "970422",
    "Agribank":    "970405",  "BIDV":        "970418",  "VPBank":   "970432",
    "TPBank":      "970423",  "ACB":         "970416",  "Sacombank":"970403",
    "VietinBank":  "970415",  "HDBank":      "970437",  "VIB":      "970441",
    "OCB":         "970448",  "SHB":         "970443",  "Eximbank": "970431",
}

def bank_map_display():
    return list(BANK_BIN_MAP.keys())


async def _show_perm_edit(query, sub_id: int):
    """Hiển thị màn hình chỉnh quyền của 1 admin phụ"""
    perms = db.get_sub_admin_perms(sub_id)
    all_perms = db.ALL_SUB_PERMISSIONS
    lines = [
        f"🔐 <b>QUYỀN ADMIN PHỤ</b>",
        f"👤 Admin phụ: <code>{sub_id}</code>",
        f"📊 {len(perms)}/{len(all_perms)} quyền đang bật",
        "",
        "Nhấn để bật/tắt từng quyền:"
    ]
    rows = []
    for perm_key, perm_name in all_perms.items():
        is_on = perm_key in perms
        icon = "🟢" if is_on else "🔴"
        rows.append([InlineKeyboardButton(
            f"{icon} {perm_name}",
            callback_data=f"adm_perm_toggle_{sub_id}_{perm_key}"
        )])
    rows.append([
        InlineKeyboardButton("✅ Cấp TẤT CẢ",  callback_data=f"adm_perm_grant_all_{sub_id}"),
        InlineKeyboardButton("❌ Thu HẾT",      callback_data=f"adm_perm_revoke_all_{sub_id}"),
    ])
    rows.append([InlineKeyboardButton("🔙 Quay lại", callback_data="adm_manage_perms")])
    try:
        await query.edit_message_text(
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(rows), parse_mode="HTML")
    except Exception:
        await query.message.reply_text(
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(rows), parse_mode="HTML")


async def show_admin_panel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not _is_any_admin(uid):
        msg = update.message or (update.callback_query.message if update.callback_query else None)
        if msg: await msg.reply_text("❌ Bạn không có quyền admin!")
        return
    role = "👑 Admin Chính" if _is_main(uid) else "🔰 Admin Phụ"
    bank = db.get_bank()
    pending_dep = len(db.get_pending_deposits())
    pending_key = len(db.get_pending_key_requests())

    if _is_main(uid):
        # Hiển thị đầy đủ cho admin chính
        text = (
            f"🛠 <b>BẢNG ĐIỀU KHIỂN ADMIN CHÍNH</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"⏳ Chờ duyệt nạp: <b>{pending_dep}</b>\n"
            f"⏳ Chờ duyệt key: <b>{pending_key}</b>\n"
            f"🏦 NH: <b>{bank['bank_name']}</b> - <code>{bank['account_no']}</code>\n\n"
            f"Chọn chức năng:"
        )
    else:
        # Admin phụ: hiển thị quyền đang có
        perms = db.get_sub_admin_perms(uid)
        all_p  = db.ALL_SUB_PERMISSIONS
        perm_lines = "\n".join(
            f"  {'✅' if k in perms else '❌'} {v}"
            for k,v in all_p.items()
        )
        text = (
            f"🔰 <b>BẢNG ĐIỀU KHIỂN ADMIN PHỤ</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"⏳ Chờ duyệt nạp: <b>{pending_dep}</b>\n"
            f"⏳ Chờ duyệt key: <b>{pending_key}</b>\n\n"
            f"📋 <b>Quyền của bạn:</b>\n{perm_lines}\n\n"
            f"Chọn chức năng bên dưới:"
        )

    if update.callback_query:
        await update.callback_query.message.reply_text(text, reply_markup=_main_admin_kb(uid), parse_mode="HTML")
    else:
        await update.message.reply_text(text, reply_markup=_main_admin_kb(uid), parse_mode="HTML")

async def handle_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    query = update.callback_query
    data = query.data
    if not data.startswith("adm_"): return False
    await query.answer()
    uid = query.from_user.id
    if not _is_any_admin(uid):
        await query.message.reply_text("❌ Không có quyền!"); return True

    if data == "adm_add_sub":
        if not _is_main(uid):
            await query.message.reply_text("❌ Chỉ admin chính được thêm admin phụ!"); return True
        ctx.user_data["adm_state"] = ST_ADD_SUB
        await query.edit_message_text("➕ Nhập <b>Telegram ID</b> của admin phụ muốn thêm:\n(Gõ /huy để huỷ)", parse_mode="HTML")
        return True

    if data == "adm_del_sub":
        if not _is_main(uid):
            await query.message.reply_text("❌ Chỉ admin chính!"); return True
        ctx.user_data["adm_state"] = "adm_del_sub_id"
        await query.edit_message_text("➖ Nhập ID admin phụ muốn xóa:")
        return True

    if data == "adm_create_key":
        ctx.user_data["adm_state"] = ST_CREATE_KEY_NAME
        await query.edit_message_text("🗝 <b>Tạo Key VIP</b>\n[1/4] Nhập <b>tên key</b> (VD: VIPKEY001):\n(Gõ /huy để huỷ)", parse_mode="HTML")
        return True

    if data == "adm_del_key":
        ctx.user_data["adm_state"] = ST_DEL_KEY_NAME
        await query.edit_message_text("🗑 Nhập <b>tên key</b> muốn xóa:")
        return True

    if data == "adm_check_key":
        ctx.user_data["adm_state"] = ST_CHECK_KEY
        await query.edit_message_text("🔍 Nhập tên key cần kiểm tra:")
        return True

    if data == "adm_check_api":
        ctx.user_data["adm_state"] = "adm_check_api_id"
        await query.edit_message_text("🔑 Nhập <b>Telegram ID</b> user cần kiểm tra API key:")
        return True

    if data == "adm_set_bank":
        # ⛔ KHÓA TUYỆT ĐỐI — chỉ admin chính mới được đổi ngân hàng
        if not _is_main(uid):
            await query.answer("⛔ Quyền này chỉ dành riêng cho Admin Chính!", show_alert=True)
            return True
        bank = db.get_bank()
        bin_map = {
            "Vietcombank":"970436","Techcombank":"970407","MBBank":"970422",
            "Agribank":"970405","BIDV":"970418","VPBank":"970432","TPBank":"970423",
            "ACB":"970416","Sacombank":"970403","VietinBank":"970415","HDBank":"970437",
            "VIB":"970441","OCB":"970448","SHB":"970443","Eximbank":"970431",
        }
        bank_list = "\n".join([f"• {n}" for n in bank_map_display()])
        ctx.user_data["adm_state"] = ST_BANK_NAME
        await query.edit_message_text(
            f"🏦 <b>ĐỔI NGÂN HÀNG NHẬN TIỀN</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"⚠️ <b>Chỉ Admin Chính mới có quyền này!</b>\n\n"
            f"📌 Thông tin hiện tại:\n"
            f"🏦 NH: <b>{bank['bank_name']}</b>\n"
            f"💳 STK: <code>{bank['account_no']}</code>\n"
            f"👤 Tên: <b>{bank['account_name']}</b>\n\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"[1/3] Nhập <b>tên ngân hàng</b>:\n"
            f"VD: Vietcombank, MBBank, Techcombank, BIDV, VPBank, TPBank, ACB, Sacombank...\n\n"
            f"(Gõ /huy để huỷ)",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 Huỷ", callback_data="adm_back")
            ]]))
        return True

    if data == "adm_notif":
        ctx.user_data["adm_state"] = ST_NOTIF_TEXT
        is_main = _is_main(uid)
        note = "" if is_main else "\n⚠️ Admin phụ: thông báo cần admin chính duyệt trước khi gửi."
        await query.edit_message_text(f"📣 Nhập nội dung thông báo gửi tất cả người dùng:{note}\n(Gõ /huy để huỷ)")
        return True

    if data == "adm_approve_deps":
        if not _is_main(uid):
            await query.message.reply_text("❌ Chỉ admin chính!"); return True
        deps = db.get_pending_deposits()
        if not deps:
            await query.edit_message_text("✅ Không có yêu cầu nạp nào đang chờ!"); return True
        rows = []
        lines = ["💰 <b>Yêu cầu nạp tiền đang chờ duyệt:</b>\n"]
        for d in deps[:10]:
            lines.append(f"🔹 #{d['dep_id'][-8:]} | User: <code>{d['uid']}</code> | <b>{d['amount_k']}k</b>")
            rows.append([
                InlineKeyboardButton(f"✅ Duyệt {d['dep_id'][-6:]}", callback_data=f"adm_appdep_{d['dep_id']}"),
                InlineKeyboardButton(f"❌ Từ chối", callback_data=f"adm_rejdep_{d['dep_id']}"),
            ])
        rows.append([InlineKeyboardButton("🔙 Quay lại", callback_data="adm_back")])
        await query.edit_message_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(rows), parse_mode="HTML")
        return True

    if data.startswith("adm_appdep_"):
        dep_id = data.replace("adm_appdep_", "")
        result = db.approve_deposit(dep_id, uid)
        await query.edit_message_text(result["msg"]); return True

    if data.startswith("adm_rejdep_"):
        dep_id = data.replace("adm_rejdep_", "")
        ctx.user_data["adm_state"] = ST_REJECT_DEP
        ctx.user_data["adm_dep_id"] = dep_id
        await query.edit_message_text(f"❌ Nhập lý do từ chối yêu cầu <code>{dep_id[-8:]}</code>:", parse_mode="HTML")
        return True

    if data == "adm_approve_key_reqs":
        if not _is_main(uid): return True
        reqs = db.get_pending_key_requests()
        if not reqs:
            await query.edit_message_text("✅ Không có yêu cầu key nào!"); return True
        rows = []
        lines = ["🗝 <b>Yêu cầu key đang chờ duyệt:</b>\n"]
        for r in reqs[:10]:
            act = "Tạo" if r["action"] == "create" else "Xóa"
            lines.append(f"🔹 {act} key <b>{r['key_name']}</b> | Admin: <code>{r['by_admin']}</code>\n   Lý do: {r['reason']}")
            rows.append([InlineKeyboardButton(f"✅ Duyệt {r['key_name']}", callback_data=f"adm_appkey_{r['req_id']}")])
        rows.append([InlineKeyboardButton("🔙 Quay lại", callback_data="adm_back")])
        await query.edit_message_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(rows), parse_mode="HTML")
        return True

    if data.startswith("adm_appkey_"):
        req_id = data.replace("adm_appkey_", "")
        if not _is_main(uid): return True
        result = db.approve_key_request(req_id, uid)
        await query.edit_message_text(result["msg"]); return True

    # ── Quản lý quyền admin phụ ──────────────────────────
    if data == "adm_manage_perms":
        if not _is_main(uid):
            await query.message.reply_text("❌ Chỉ admin chính!"); return True
        sub_list = db.get_all_sub_admins_with_perms()
        if not sub_list:
            await query.edit_message_text(
                "ℹ️ Chưa có admin phụ nào.\nThêm admin phụ trước.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","adm_back")]]))
            return True
        rows = []
        lines = ["🔐 <b>PHÂN QUYỀN ADMIN PHỤ</b>\n\nChọn admin phụ để chỉnh quyền:\n"]
        for item in sub_list:
            sub_id = item["uid"]
            perms = item["perms"]
            perm_count = len(perms)
            total_perms = len(db.ALL_SUB_PERMISSIONS)
            lines.append(f"🔰 <code>{sub_id}</code> — {perm_count}/{total_perms} quyền")
            rows.append([InlineKeyboardButton(
                f"⚙️ Chỉnh quyền {sub_id}",
                callback_data=f"adm_perm_edit_{sub_id}"
            )])
        rows.append([InlineKeyboardButton("🔙 Quay lại", callback_data="adm_back")])
        await query.edit_message_text(
            "\n".join(lines),
            reply_markup=InlineKeyboardMarkup(rows), parse_mode="HTML")
        return True

    if data.startswith("adm_perm_edit_"):
        if not _is_main(uid): return True
        sub_id = int(data.replace("adm_perm_edit_", ""))
        await _show_perm_edit(query, sub_id)
        return True

    if data.startswith("adm_perm_toggle_"):
        if not _is_main(uid): return True
        # Format: adm_perm_toggle_{sub_id}_{perm_key}
        parts = data.replace("adm_perm_toggle_", "").split("_", 1)
        sub_id = int(parts[0]); perm_key = parts[1]
        new_state = db.toggle_sub_perm(sub_id, perm_key)
        icon = "🟢" if new_state else "🔴"
        perm_name = db.ALL_SUB_PERMISSIONS.get(perm_key, perm_key)
        # Refresh màn hình
        await _show_perm_edit(query, sub_id)
        return True

    if data.startswith("adm_perm_grant_all_"):
        if not _is_main(uid): return True
        sub_id = int(data.replace("adm_perm_grant_all_", ""))
        db.set_sub_admin_perms(sub_id, list(db.ALL_SUB_PERMISSIONS.keys()))
        await _show_perm_edit(query, sub_id)
        return True

    if data.startswith("adm_perm_revoke_all_"):
        if not _is_main(uid): return True
        sub_id = int(data.replace("adm_perm_revoke_all_", ""))
        db.set_sub_admin_perms(sub_id, [])
        await _show_perm_edit(query, sub_id)
        return True

    # ── Cập nhật giá key VIP ────────────────────────────
    if data == "adm_price_edit":
        if not _is_main(uid): await query.answer("❌ Chỉ admin chính!", show_alert=True); return True
        cfg = db.get_bot_config(); p = cfg.get("key_price", {})
        await query.message.reply_text(
            f"💰 <b>Giá Key VIP hiện tại:</b>\n"
            f"├ 1 ngày:  <b>{p.get('day',1)}k</b>\n"
            f"├ 1 tháng: <b>{p.get('month',25)}k</b>\n"
            f"└ 1 năm:   <b>{p.get('year',250)}k</b>\n\n"
            f"Nhập giá mới theo dạng:\n<code>ngay=1 thang=25 nam=250</code>\n(Đơn vị: nghìn đồng)",
            parse_mode="HTML")
        ctx.user_data["adm_state"] = "adm_set_price"; return True

    # ── Cập nhật % thưởng BXH ───────────────────────────
    if data == "adm_reward_edit":
        if not _is_main(uid): await query.answer("❌ Chỉ admin chính!", show_alert=True); return True
        cfg = db.get_bot_config(); r = cfg.get("rank_reward", {})
        await query.message.reply_text(
            f"🏆 <b>% thưởng BXH hiện tại:</b>\n"
            f"├ Top 1: <b>{r.get('top1_pct',5)}%</b>\n"
            f"├ Top 2: <b>{r.get('top2_pct',3)}%</b>\n"
            f"└ Top 3: <b>{r.get('top3_pct',2)}%</b>\n\n"
            f"Nhập % mới:\n<code>top1=5 top2=3 top3=2</code>",
            parse_mode="HTML")
        ctx.user_data["adm_state"] = "adm_set_reward"; return True

    if data == "adm_stats":
        users = db.get_all_users()
        total = len(users)
        vip_count = sum(1 for u in users.values() if u.get("vip_expire", 0) > now_ts())
        api_count = sum(1 for u in users.values() if u.get("balance", 0) > 0)
        await query.edit_message_text(
            f"📊 <b>Thống kê hệ thống</b>\n"
            f"👥 Tổng user: <b>{total}</b>\n"
            f"👑 Đang dùng VIP: <b>{vip_count}</b>\n"
            f"🔑 Có API balance: <b>{api_count}</b>",
            parse_mode="HTML"); return True

    if data == "adm_back":
        await show_admin_panel(update, ctx); return True

    return False

async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    uid = update.effective_user.id
    if not _is_any_admin(uid): return False
    state = ctx.user_data.get("adm_state")
    if not state: return False
    text = update.message.text.strip() if update.message.text else ""

    async def reply(msg): await update.message.reply_text(msg, parse_mode="HTML")

    if state == ST_ADD_SUB:
        try:
            sub_id = int(text)
            if db.add_sub_admin(sub_id):
                await reply(f"✅ Đã thêm admin phụ: <code>{sub_id}</code>")
            else:
                await reply(f"⚠️ ID {sub_id} đã là admin phụ rồi!")
        except ValueError:
            await reply("❌ Nhập số ID hợp lệ!")
        ctx.user_data.pop("adm_state", None); return True

    if state == "adm_del_sub_id":
        try:
            sub_id = int(text)
            if db.remove_sub_admin(sub_id):
                await reply(f"✅ Đã xóa admin phụ: <code>{sub_id}</code>")
            else:
                await reply("⚠️ Không tìm thấy!")
        except ValueError:
            await reply("❌ Nhập số ID!")
        ctx.user_data.pop("adm_state", None); return True

    if state == ST_CREATE_KEY_NAME:
        ctx.user_data["adm_key_name"] = text.upper()
        ctx.user_data["adm_state"] = ST_CREATE_KEY_UID
        await reply(f"✅ Tên key: <b>{text.upper()}</b>\n[2/4] Nhập <b>Telegram ID</b> người dùng (0 = dùng chung):")
        return True

    if state == ST_CREATE_KEY_UID:
        try:
            target_uid = int(text)
            ctx.user_data["adm_key_uid"] = target_uid
            ctx.user_data["adm_state"] = ST_CREATE_KEY_DAYS
            await reply(f"✅ UID: <code>{target_uid}</code>\n[3/4] Hạn sử dụng bao nhiêu <b>ngày</b>? (VD: 30):")
        except ValueError:
            await reply("❌ Nhập số ID!")
        return True

    if state == ST_CREATE_KEY_DAYS:
        try:
            days = int(text); assert days > 0
            ctx.user_data["adm_key_days"] = days
            ctx.user_data["adm_state"] = ST_CREATE_KEY_RSN
            await reply(f"✅ Hạn: <b>{days} ngày</b>\n[4/4] Nhập <b>lý do</b> tạo key:")
        except:
            await reply("❌ Nhập số nguyên dương!")
        return True

    if state == ST_CREATE_KEY_RSN:
        key_name = ctx.user_data.get("adm_key_name")
        target_uid = ctx.user_data.get("adm_key_uid", 0)
        days = ctx.user_data.get("adm_key_days", 1)
        reason = text
        ctx.user_data.pop("adm_state", None)
        if _is_main(uid):
            db.create_vip_key(key_name, target_uid, days, uid, reason)
            await reply(f"✅ <b>Đã tạo Key VIP!</b>\n🗝 Key: <code>{key_name}</code>\n👤 UID: <code>{target_uid}</code>\n⏰ Hạn: <b>{days} ngày</b>")
        else:
            req_id = db.create_key_request(key_name, target_uid, days, uid, reason)
            await reply(f"📋 Đã gửi yêu cầu tạo key cho admin chính duyệt!\nID yêu cầu: <code>{req_id}</code>")
        return True

    if state == ST_DEL_KEY_NAME:
        ctx.user_data["adm_del_key_name"] = text.upper()
        ctx.user_data["adm_state"] = ST_DEL_KEY_RSN
        await reply(f"🗑 Key: <b>{text.upper()}</b>\nNhập <b>lý do</b> xóa key:")
        return True

    if state == ST_DEL_KEY_RSN:
        key_name = ctx.user_data.get("adm_del_key_name", "")
        ctx.user_data.pop("adm_state", None)
        if _is_main(uid):
            if db.delete_vip_key(key_name, text):
                await reply(f"✅ Đã xóa key: <code>{key_name}</code>")
            else:
                await reply(f"❌ Không tìm thấy key: <code>{key_name}</code>")
        else:
            req_id = db.create_key_delete_request(key_name, uid, text)
            await reply(f"📋 Gửi yêu cầu xóa key cho admin chính!\nID: <code>{req_id}</code>")
        return True

    if state == ST_CHECK_KEY:
        info = db.get_key_info(text.upper())
        ctx.user_data.pop("adm_state", None)
        if not info:
            await reply(f"❌ Không tìm thấy key: <code>{text.upper()}</code>"); return True
        exp = ts_to_str(info["expire"])
        alive = "✅ Còn hạn" if info["expire"] > now_ts() else "❌ Hết hạn"
        await reply(
            f"🔍 <b>Thông tin Key VIP</b>\n"
            f"🗝 Key: <code>{info['name']}</code>\n"
            f"👤 UID: <code>{info.get('uid', 'N/A')}</code>\n"
            f"⏰ Hết hạn: <b>{exp}</b> — {alive}\n"
            f"📝 Lý do: {info.get('reason','N/A')}\n"
            f"👑 Tạo bởi: <code>{info.get('created_by','N/A')}</code>")
        return True

    if state == "adm_check_api_id":
        try:
            target = int(text)
            u = db.get_user(target)
            ctx.user_data.pop("adm_state", None)
            await reply(
                f"🔑 <b>API Key Info</b>\n"
                f"👤 UID: <code>{target}</code>\n"
                f"🔑 API Key: <code>{u['api_key']}</code>\n"
                f"💰 Số dư: <b>{u.get('balance',0)}k</b>")
        except:
            await reply("❌ Nhập ID hợp lệ!")
        return True

    if state == ST_BANK_NAME:
        # ⛔ Guard kép — chặn admin phụ dù có state
        if not _is_main(uid):
            ctx.user_data.pop("adm_state", None)
            await reply("⛔ <b>Quyền này chỉ dành riêng cho Admin Chính!</b>")
            return True
        bank_name = text.strip()
        # Tra BIN từ tên ngân hàng
        bin_code = BANK_BIN_MAP.get(bank_name, "")
        ctx.user_data["adm_bank_name"] = bank_name
        ctx.user_data["adm_bank_bin"]  = bin_code
        ctx.user_data["adm_state"]     = ST_BANK_NO
        bin_note = f"\n🔢 Mã BIN tự động: <code>{bin_code}</code>" if bin_code else "\n⚠️ Ngân hàng không có trong danh sách sẵn, QR có thể không chính xác."
        await reply(
            f"✅ NH: <b>{bank_name}</b>{bin_note}\n\n"
            f"[2/3] Nhập <b>số tài khoản</b>:")
        return True

    if state == ST_BANK_NO:
        if not _is_main(uid):
            ctx.user_data.pop("adm_state", None)
            await reply("⛔ <b>Quyền này chỉ dành riêng cho Admin Chính!</b>")
            return True
        ctx.user_data["adm_bank_no"] = text.strip()
        ctx.user_data["adm_state"]   = ST_BANK_OWNER
        await reply(f"✅ STK: <code>{text.strip()}</code>\n\n[3/3] Nhập <b>tên chủ TK</b> (IN HOA, không dấu):")
        return True

    if state == ST_BANK_OWNER:
        if not _is_main(uid):
            ctx.user_data.pop("adm_state", None)
            await reply("⛔ <b>Quyền này chỉ dành riêng cho Admin Chính!</b>")
            return True
        bank_name  = ctx.user_data.pop("adm_bank_name", "")
        bank_no    = ctx.user_data.pop("adm_bank_no",   "")
        bin_code   = ctx.user_data.pop("adm_bank_bin",  "")
        owner_name = text.upper().strip()
        ctx.user_data.pop("adm_state", None)
        # Lưu vào DB
        db.set_bank(bank_name, bank_no, owner_name, bin_code)
        bank = db.get_bank()
        # Tạo QR xem trước
        qr_url = db.get_qr_url(10, f"TEST {uid}")
        await reply(
            f"✅ <b>ĐÃ CẬP NHẬT NGÂN HÀNG NHẬN TIỀN!</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🏦 Ngân hàng: <b>{bank['bank_name']}</b>\n"
            f"💳 Số TK: <code>{bank['account_no']}</code>\n"
            f"👤 Chủ TK: <b>{bank['account_name']}</b>\n"
            f"🔢 BIN: <code>{bank.get('bin','N/A')}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"Từ nay bot sẽ tạo QR chuyển khoản theo thông tin này.")
        # Gửi QR xem trước
        try:
            import urllib.request as ur
            req = ur.Request(qr_url, headers={"User-Agent":"Mozilla/5.0"})
            img = ur.urlopen(req, timeout=10).read()
            from io import BytesIO
            await update.message.reply_photo(
                photo=BytesIO(img),
                caption=f"📱 QR xem trước (10k - TEST)\n✅ Ngân hàng đã được cập nhật!")
        except Exception as e:
            await reply(f"⚠️ Không tải được QR xem trước: {e}")
        return True

    if state == ST_NOTIF_TEXT:
        ctx.user_data.pop("adm_state", None)
        if _is_main(uid):
            notif_id = db.create_notification(text, uid)
            db.approve_notification(notif_id)
            await reply(f"📣 Thông báo đã được gửi!")
            return True, text  # signal to main to broadcast
        else:
            notif_id = db.create_notification(text, uid)
            await reply(f"📋 Thông báo đã gửi cho admin chính duyệt!\nID: <code>{notif_id}</code>")
        return True

    if state == ST_REJECT_DEP:
        dep_id = ctx.user_data.pop("adm_dep_id", "")
        reason = text
        ctx.user_data.pop("adm_state", None)
        result = db.reject_deposit(dep_id, uid, reason)
        await reply(f"❌ Đã từ chối yêu cầu <code>{dep_id[-8:]}</code>")
        return True

    return False
