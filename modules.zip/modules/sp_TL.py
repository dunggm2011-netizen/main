#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TLTOOL - Telegram Bot gộp 3 tool
- Tool 1: Đào & kiểm tra Proxy
- Tool 2: Nuôi Facebook (cấu hình bằng nút bấm, chọn nhiều nhiệm vụ)
- Tool 3: Reg Page Pro5 (nhập cookie trực tiếp, dùng /done để kết thúc)

Cơ chế key: mỗi người dùng tự tạo key bằng cách vượt link do bot cung cấp.
Bot tự động kiểm tra key hết hạn khi đang chạy task và yêu cầu nhập key mới.
"""

import asyncio
import logging
import json
import os
import re
import random
import uuid
import base64
import time
import hashlib
from datetime import datetime
from typing import Dict, Tuple, Optional, List

import requests
from bs4 import BeautifulSoup
import aiohttp
try:
    from aiohttp_proxy import ProxyConnector
    HAS_PROXY = True
except ImportError:
    HAS_PROXY = False
import psutil
import ipaddress

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import (
    ApplicationBuilder, CommandHandler, CallbackQueryHandler,
    MessageHandler, ContextTypes, filters, ConversationHandler
)

# ===================== CẤU HÌNH =====================
BOT_TOKEN = "8716000424:AAFBWxHpPiUPTyzEsNUGD-xa6Y2bd0n0Alw"   # ← Thay token của bạn

# API rút gọn link (dùng link4m)
LINK4M_API_TOKEN = "690c33d798704a2b646191c1"

# File lưu key của người dùng
USER_KEYS_FILE = "user_keys.json"

# Các state cho ConversationHandler của Nuôi FB
SELECT_TASKS, INPUT_DELAY, INPUT_JOB_BLOCK, INPUT_DELAY_BLOCK, INPUT_JOB_BREAK = range(5)

# Các state cho Reg Page
REG_INPUT_COOKIES, REG_INPUT_DELAY_MIN, REG_INPUT_DELAY_MAX, REG_INPUT_MODE, REG_INPUT_PAGES_PER_ACC = range(5, 10)

# ===================== LOGGING =====================
logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ===================== QUẢN LÝ KEY NGƯỜI DÙNG =====================
def load_user_keys() -> dict:
    if not os.path.exists(USER_KEYS_FILE):
        return {}
    try:
        with open(USER_KEYS_FILE, 'r') as f:
            return json.load(f)
    except:
        return {}

def save_user_keys(keys: dict):
    with open(USER_KEYS_FILE, 'w') as f:
        json.dump(keys, f, indent=2)

def get_user_key_info(user_id: int) -> Optional[Tuple[str, float, float]]:
    keys = load_user_keys()
    uid = str(user_id)
    if uid not in keys:
        return None
    info = keys[uid]
    key = info['key']
    created = info['created']
    expiry_hours = info['expiry_hours']
    if time.time() - created <= expiry_hours * 3600:
        return key, created, expiry_hours
    else:
        del keys[uid]
        save_user_keys(keys)
        return None

def is_user_key_valid(user_id: int) -> bool:
    return get_user_key_info(user_id) is not None

def activate_user_key(user_id: int, key: str, expiry_hours: int):
    keys = load_user_keys()
    uid = str(user_id)
    keys[uid] = {
        'key': key,
        'created': time.time(),
        'expiry_hours': expiry_hours
    }
    save_user_keys(keys)

# ===================== TẠO KEY VÀ LINK =====================
def generate_random_segment(length=4) -> str:
    chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    return ''.join(random.choices(chars, k=length))

def create_key(expiry_hours: int) -> str:
    prefix = "24" if expiry_hours == 24 else "12"
    parts = [generate_random_segment(4) for _ in range(3)]
    return f"TL-{prefix}-{parts[0]}-{parts[1]}-{parts[2]}"

def make_key_link(key_value: str) -> str:
    return f"https://tl-key.neocities.org/api_key/?key={key_value}"

def shorten_link(long_url: str) -> Optional[str]:
    try:
        api = f"https://link4m.co/api-shorten/v2?api={LINK4M_API_TOKEN}&url={long_url}"
        resp = requests.get(api, timeout=10)
        resp.raise_for_status()
        return resp.json().get("shortenedUrl")
    except Exception as e:
        logger.error(f"shorten_link error: {e}")
        return None

def build_double_shortened_link(key_value: str) -> Optional[str]:
    link1 = make_key_link(key_value)
    short1 = shorten_link(link1)
    if not short1:
        return None
    link2 = make_key_link(short1)
    short2 = shorten_link(link2)
    return short2 or short1

def build_single_shortened_link(key_value: str) -> Optional[str]:
    link = make_key_link(key_value)
    return shorten_link(link)

# ===================== DATA LƯU PER-USER =====================
user_data = {}

def get_user(uid):
    if uid not in user_data:
        user_data[uid] = {
            "cookies_fb": [],
            "cookie_reg": [],
            "running": False,
            "task": None,
            "proxy_list": [],
        }
    return user_data[uid]

# ==================== PROXY TOOL ====================
JUDGE_URL = "http://httpbin.org/anything"
MAX_CONCURRENT_CHECK = 50
MAX_CONCURRENT_SCRAPE = 10

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Version/17.2 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
]

PROXY_SOURCES = [
    ("TheSpeedX - HTTP",   "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt"),
    ("TheSpeedX - SOCKS4", "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks4.txt"),
    ("TheSpeedX - SOCKS5", "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt"),
    ("monosans - HTTP",    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt"),
    ("monosans - SOCKS4",  "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt"),
    ("monosans - SOCKS5",  "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt"),
    ("ProxyScrape HTTP",   "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all"),
    ("ProxyScrape SOCKS5", "https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5&timeout=10000&country=all"),
    ("proxifly - HTTP",    "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/http/data.txt"),
    ("proxifly - SOCKS5",  "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/protocols/socks5/data.txt"),
    ("ShiftyTR - HTTP",    "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt"),
    ("ShiftyTR - SOCKS5",  "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks5.txt"),
    ("roosterkid - HTTP",  "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTP.txt"),
    ("roosterkid - SOCKS5","https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5.txt"),
    ("hookzof - SOCKS5",   "https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt"),
]

def parse_proxy_string(proxy_str):
    proxy_str = proxy_str.strip()
    if "://" in proxy_str:
        return proxy_str
    if "@" in proxy_str:
        creds, hostport = proxy_str.split("@", 1)
        if ":" in creds:
            user, passwd = creds.split(":", 1)
            return f"http://{user}:{passwd}@{hostport}"
    parts = proxy_str.split(":")
    if len(parts) == 4:
        ip, port, user, passwd = parts
        return f"http://{user}:{passwd}@{ip}:{port}"
    elif len(parts) == 2:
        return f"http://{parts[0]}:{parts[1]}"
    return proxy_str

async def check_proxy_debug(proxy_url, timeout=10):
    if not HAS_PROXY:
        return {"alive": False, "latency": None, "anonymity": "Unknown", "message": "aiohttp-proxy not installed"}
    try:
        connector = ProxyConnector.from_url(proxy_url)
        _timeout = aiohttp.ClientTimeout(total=timeout)
        async with aiohttp.ClientSession(connector=connector, timeout=_timeout) as session:
            loop = asyncio.get_running_loop()
            start = loop.time()
            async with session.get(JUDGE_URL) as resp:
                latency = int((loop.time() - start) * 1000)
                if resp.status == 200:
                    data = await resp.json(content_type=None)
                    headers = data.get('headers', {})
                    origin = data.get('origin', 'unknown')
                    if 'X-Forwarded-For' in headers or 'X-Real-IP' in headers:
                        anon = "Transparent"
                    elif 'Via' in headers or 'Proxy-Connection' in headers:
                        anon = "Anonymous"
                    else:
                        anon = "Elite"
                    return {"alive": True, "latency": latency, "anonymity": anon,
                            "message": f"✅ {proxy_url} → IP: {origin} ({latency}ms) [{anon}]"}
                return {"alive": False, "latency": None, "anonymity": "Unknown",
                        "message": f"❌ {proxy_url} → HTTP {resp.status}"}
    except (asyncio.TimeoutError, aiohttp.ServerTimeoutError):
        return {"alive": False, "latency": None, "anonymity": "Unknown",
                "message": f"⏱ {proxy_url} → Timeout"}
    except Exception as e:
        return {"alive": False, "latency": None, "anonymity": "Unknown",
                "message": f"💀 {proxy_url} → {type(e).__name__}"}

async def fetch_source_async(session, name, url):
    proxies = []
    try:
        headers = {'User-Agent': random.choice(USER_AGENTS)}
        _timeout = aiohttp.ClientTimeout(total=15)
        async with session.get(url, headers=headers, timeout=_timeout) as resp:
            resp.raise_for_status()
            text = await resp.text(errors='ignore')
        found = re.findall(r'\b(?:\d{1,3}\.){3}\d{1,3}:\d{2,5}\b', text)
        proxies.extend(found)
    except Exception:
        pass
    return name, proxies

async def dao_proxy_async(source_indices=None):
    sources = PROXY_SOURCES
    if source_indices:
        sources = [PROXY_SOURCES[i] for i in source_indices if 0 <= i < len(PROXY_SOURCES)]
    connector = aiohttp.TCPConnector(limit=MAX_CONCURRENT_SCRAPE, ssl=False)
    all_proxies = []
    try:
        async with aiohttp.ClientSession(connector=connector) as session:
            tasks = [fetch_source_async(session, n, u) for n, u in sources]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for result in results:
                if isinstance(result, Exception):
                    continue
                name, proxies = result
                all_proxies.extend(proxies)
    except Exception as e:
        logger.error(f"dao_proxy_async error: {e}")
    return list(set(filter(None, all_proxies)))

async def check_proxies_async(proxy_list, progress_cb=None):
    semaphore = asyncio.Semaphore(MAX_CONCURRENT_CHECK)
    alive, dead = [], []
    checked = [0]
    total = len(proxy_list)

    async def bounded_test(proxy):
        async with semaphore:
            url = parse_proxy_string(proxy)
            result = await check_proxy_debug(url)
            checked[0] += 1
            if progress_cb and checked[0] % 50 == 0:
                await progress_cb(checked[0], total)
            if result["alive"]:
                alive.append({"proxy": proxy, "latency": result["latency"],
                               "anonymity": result["anonymity"]})
            else:
                dead.append(proxy)

    await asyncio.gather(*[bounded_test(p) for p in proxy_list])
    alive.sort(key=lambda x: x["latency"])
    return alive, dead

# ==================== FACEBOOK CLASS ====================
def encode_to_base64(_data):
    return base64.b64encode(_data.encode('utf-8')).decode('utf-8')

class Facebook:
    def __init__(self, cookie: str):
        try:
            self.fb_dtsg = ''
            self.jazoest = ''
            self.cookie = cookie
            self.session = requests.Session()
            self.session.request = lambda method, url, **kw: requests.Session.request(self.session, method, url, timeout=kw.pop('timeout', 20), **kw)
            self.commented_posts = set()
            self.id = self.cookie.split('c_user=')[1].split(';')[0]
            self.headers = {
                'authority': 'www.facebook.com',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                'accept-language': 'vi',
                'sec-ch-ua': '"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'none',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
                'Cookie': self.cookie
            }
            url = self.session.get(f'https://www.facebook.com/{self.id}', headers=self.headers, timeout=20).url
            response = self.session.get(url, headers=self.headers, timeout=20).text
            matches = re.findall(r'\["DTSGInitialData",\[\],\{"token":"(.*?)"\}', response)
            if matches:
                self.fb_dtsg = matches[0]
                jazoest_m = re.findall(r'jazoest=(.*?)\"', response)
                if jazoest_m:
                    self.jazoest = jazoest_m[0]
        except Exception as e:
            logger.error(f"Facebook init error: {e}")

    def info(self):
        try:
            get = self.session.get('https://www.facebook.com/me', headers=self.headers, timeout=20).url
            url = 'https://www.facebook.com/' + get.split('%2F')[-2] + '/' if 'next=' in get else get
            response = self.session.get(url, headers=self.headers, params={"locale": "vi_VN"}, timeout=20)
            data_split = response.text.split('"CurrentUserInitialData",[],{')
            if len(data_split) < 2:
                return 'cookieout'
            json_data = '{' + data_split[1].split('},')[0] + '}'
            parsed_data = json.loads(json_data)
            id_ = parsed_data.get('USER_ID', '0')
            name = parsed_data.get('NAME', '')
            if id_ == '0' and name == '':
                return 'cookieout'
            elif '828281030927956' in response.text:
                return '956'
            elif '1501092823525282' in response.text:
                return '282'
            elif '601051028565049' in response.text:
                return 'spam'
            else:
                return {'success': 200, 'id': parsed_data.get('USER_ID'), 'name': parsed_data.get('NAME')}
        except Exception as e:
            logger.error(f"info error: {e}")
            return 'cookieout'

    def timban(self, text):
        try:
            data = {
                'av': self.id, 'fb_dtsg': self.fb_dtsg, 'jazoest': self.jazoest,
                'fb_api_caller_class': 'RelayModern',
                'fb_api_req_friendly_name': 'SearchCometResultsInitialResultsQuery',
                'variables': '{"count":5,"allow_streaming":false,"args":{"callsite":"COMET_GLOBAL_SEARCH","config":{"exact_match":false,"high_confidence_config":null,"intercept_config":null,"sts_disambiguation":null,"watch_config":null},"context":{"bsid":"23bd9138-cec6-4e71-aaeb-225fc8964e5b","tsid":"0.10477759801522946"},"experience":{"client_defined_experiences":["ADS_PARALLEL_FETCH"],"encoded_server_defined_params":null,"fbid":null,"type":"GLOBAL_SEARCH"},"filters":[],"text":"'+text+'"},"cursor":null,"feedbackSource":23,"fetch_filters":true,"renderLocation":"search_results_page","scale":1,"stream_initial_count":0,"useDefaultActor":false,"__relay_internal__pv__GHLShouldChangeAdIdFieldNamerelayprovider":true,"__relay_internal__pv__GHLShouldChangeSponsoredDataFieldNamerelayprovider":true,"__relay_internal__pv__IsWorkUserrelayprovider":false,"__relay_internal__pv__FBReels_deprecate_short_form_video_context_gkrelayprovider":true,"__relay_internal__pv__CometFeedStoryDynamicResolutionPhotoAttachmentRenderer_experimentWidthrelayprovider":500,"__relay_internal__pv__CometImmersivePhotoCanUserDisable3DMotionrelayprovider":false,"__relay_internal__pv__WorkCometIsEmployeeGKProviderrelayprovider":false,"__relay_internal__pv__IsMergQAPollsrelayprovider":false,"__relay_internal__pv__FBReelsMediaFooter_comet_enable_reels_ads_gkrelayprovider":true,"__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider":false,"__relay_internal__pv__CometUFIShareActionMigrationrelayprovider":true,"__relay_internal__pv__CometUFI_dedicated_comment_routable_dialog_gkrelayprovider":false,"__relay_internal__pv__StoriesArmadilloReplyEnabledrelayprovider":true,"__relay_internal__pv__FBReelsIFUTileContent_reelsIFUPlayOnHoverrelayprovider":false}',
                'server_timestamps': 'true', 'doc_id': '9545374252239656'
            }
            response = self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data).json()
            profile = response["data"]["serpResponse"]["results"]["edges"][0]['rendering_strategy']['result_rendering_strategies'][0]['view_model']['profile']
            return {'status': 'success', 'id': profile.get('id'), 'name': profile.get('name')}
        except Exception:
            return {'status': 'error', 'trangthai': 'thatbai'}

    def ketban(self, idkb):
        try:
            data = {
                'av': self.id, 'fb_dtsg': self.fb_dtsg, 'jazoest': self.jazoest,
                'fb_api_caller_class': 'RelayModern',
                'fb_api_req_friendly_name': 'FriendingCometFriendRequestSendMutation',
                'variables': '{"input":{"attribution_id_v2":"ProfileCometTimelineListViewRoot.react,comet.profile.timeline.list,unexpected,1748257667487,475021,190055527696468,,;SearchCometGlobalSearchDefaultTabRoot.react,comet.search_results.default_tab,tap_search_bar,1748257603766,498383,391724414624676,,","click_proof_validation_result":null,"friend_requestee_ids":["'+idkb+'"],"friending_channel":"PROFILE_BUTTON","warn_ack_for_ids":[],"actor_id":"'+self.id+'","client_mutation_id":"6"},"scale":1}',
                'server_timestamps': 'true', 'doc_id': '8805328442902902'
            }
            response = self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data).json()
            trangthai = response["data"]["friend_request_send"]["friend_requestees"]
            if trangthai and trangthai[0].get('friendship_status') == 'OUTGOING_REQUEST':
                return {'status': 'success', 'trangthai': 'thanhcong'}
            return {'status': 'error', 'trangthai': 'thatbai'}
        except Exception:
            return {'status': 'error', 'trangthai': 'thatbai'}

    def getidpost(self):
        try:
            variables = {
                "RELAY_INCREMENTAL_DELIVERY": True,
                "clientQueryId": "b7876288-8582-4b5a-9420-76f62adfe671",
                "count": 5, "cursor": None, "feedLocation": "NEWSFEED",
                "feedStyle": "DEFAULT", "orderby": ["TOP_STORIES"],
                "renderLocation": "homepage_stream", "scale": 1, "useDefaultActor": False
            }
            data = {
                'av': self.id, 'fb_dtsg': self.fb_dtsg, 'jazoest': self.jazoest,
                'fb_api_caller_class': 'RelayModern',
                'fb_api_req_friendly_name': 'CometNewsFeedPaginationQuery',
                'variables': json.dumps(variables),
                'server_timestamps': 'true', 'doc_id': '29492828377027602'
            }
            response = self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data).text
            if '"post_id":"' in response:
                id_ = response.split('"post_id":"')[1].split('",')[0]
                return {'status': 'success', 'idpost': id_}
            return {'status': 'error', 'trangthai': 'thatbai'}
        except Exception:
            return {'status': 'error', 'trangthai': 'thatbai'}

    def getidgr(self, noidung):
        try:
            data = {
                'av': self.id, 'fb_dtsg': self.fb_dtsg, 'jazoest': self.jazoest,
                'fb_api_caller_class': 'RelayModern',
                'fb_api_req_friendly_name': 'SearchCometResultsInitialResultsQuery',
                'variables': '{"allow_streaming":false,"args":{"callsite":"COMET_GLOBAL_SEARCH","config":{"exact_match":false,"high_confidence_config":null,"intercept_config":null,"sts_disambiguation":null,"watch_config":null},"context":{"bsid":"435c49d4-a957-431e-834f-d1da37a5f10b","tsid":"0.37005625332226133"},"experience":{"client_defined_experiences":["ADS_PARALLEL_FETCH"],"encoded_server_defined_params":null,"fbid":null,"type":"GROUPS_TAB"},"filters":[],"text":"'+noidung+'"},"count":5,"cursor":null,"feedLocation":"SEARCH","feedbackSource":23,"fetch_filters":true,"focusCommentID":null,"locale":null,"privacySelectorRenderLocation":"COMET_STREAM","renderLocation":"search_results_page","scale":1,"stream_initial_count":0,"useDefaultActor":false}',
                'server_timestamps': 'true', 'doc_id': '24016506881293628'
            }
            response = self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data).json()
            thongtin = response['data']['serpResponse']['results']['edges'][0]['rendering_strategy']['view_model']['profile']
            return {'status': 'success', 'id': thongtin.get('id'), 'name': thongtin.get('name')}
        except Exception:
            return {'status': 'error', 'trangthai': 'thatbai'}

    def reaction(self, id_, type_):
        try:
            reac = {"LIKE": "1635855486666999", "LOVE": "1678524932434102", "CARE": "613557422527858",
                    "HAHA": "115940658764963", "WOW": "478547315650144", "SAD": "908563459236466", "ANGRY": "444813342392137"}
            idreac = reac.get(type_)
            feedback_id = encode_to_base64("feedback:" + str(id_))
            data = {
                'av': self.id, 'fb_dtsg': self.fb_dtsg, 'jazoest': self.jazoest,
                'fb_api_caller_class': 'RelayModern',
                'fb_api_req_friendly_name': 'CometUFIFeedbackReactMutation',
                'variables': f'{{"input":{{"feedback_id":"{feedback_id}","feedback_reaction_id":"{idreac}","feedback_source":"NEWS_FEED","is_tracking_encrypted":true,"tracking":[],"session_id":"{uuid.uuid4()}","actor_id":"{self.id}","client_mutation_id":"3"}},"useDefaultActor":false,"__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider":false}}',
                'server_timestamps': 'true', 'doc_id': '7047198228715224',
            }
            res = self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data)
            if '{"data":{"feedback_react":{"feedback":{"id":' in res.text:
                return {'status': 'success', 'trangthai': 'thanhcong'}
            return {'status': 'error', 'trangthai': 'thatbai'}
        except Exception:
            return {'status': 'error', 'trangthai': 'thatbai'}

    def follow(self, id_):
        try:
            data = {
                'av': self.id, 'fb_dtsg': self.fb_dtsg, 'jazoest': self.jazoest,
                'fb_api_caller_class': 'RelayModern', 'fb_api_req_friendly_name': 'CometUserFollowMutation',
                'variables': '{"input":{"attribution_id_v2":"","is_tracking_encrypted":false,"subscribe_location":"PROFILE","subscribee_id":"'+str(id_)+'","tracking":null,"actor_id":"'+str(self.id)+'","client_mutation_id":"5"},"scale":1}',
                'server_timestamps': 'true', 'doc_id': '25581663504782089',
            }
            res = self.session.post('https://www.facebook.com/api/graphql/', data=data, headers=self.headers)
            if '"subscribe_status":"IS_SUBSCRIBED"' in res.text:
                return {'status': 'success', 'trangthai': 'thanhcong'}
            return {'status': 'error', 'trangthai': 'thatbai'}
        except Exception:
            return {'status': 'error', 'trangthai': 'thatbai'}

    def group(self, id_):
        try:
            data = {
                'av': self.id, 'fb_dtsg': self.fb_dtsg, 'jazoest': self.jazoest,
                'fb_api_caller_class': 'RelayModern', 'fb_api_req_friendly_name': 'GroupCometJoinForumMutation',
                'variables': '{"feedType":"DISCUSSION","groupID":"'+id_+'","input":{"action_source":"GROUP_MALL","group_id":"'+id_+'","group_share_tracking_params":{"is_from_share":false},"actor_id":"'+self.id+'","client_mutation_id":"1"},"scale":2,"source":"GROUP_MALL","renderLocation":"group_mall"}',
                'server_timestamps': 'true', 'doc_id': '5853134681430324',
            }
            res = self.session.post('https://www.facebook.com/api/graphql/', headers=self.headers, data=data)
            if id_ in res.text:
                return {'status': 'success', 'trangthai': 'thanhcong'}
            return {'status': 'error', 'trangthai': 'thatbai'}
        except Exception:
            return {'status': 'error', 'trangthai': 'thatbai'}

# ==================== REG PAGE PRO5 ====================
class RegPro5:
    def __init__(self, cookies, name):
        self.cookies = cookies
        self.id_acc = self.cookies.split('c_user=')[1].split(';')[0]
        self.name = name
        headers = {'cookie': self.cookies, 'user-agent': 'Mozilla/5.0'}
        url_profile = requests.get('https://www.facebook.com/me', headers=headers).url
        profile = requests.get(url_profile, headers=headers).text
        try:
            self.fb_dtsg = profile.split('{"name":"fb_dtsg","value":"')[1].split('"},')[0]
        except Exception:
            try:
                self.fb_dtsg = profile.split(',"f":"')[1].split('","l":null}')[0]
            except Exception:
                self.fb_dtsg = ''

    def Reg(self):
        headers = {
            'cookie': self.cookies,
            'user-agent': 'Mozilla/5.0',
            'x-fb-friendly-name': 'AdditionalProfilePlusCreationMutation',
        }
        data = {
            'av': self.id_acc, '__user': self.id_acc,
            'fb_dtsg': self.fb_dtsg,
            'fb_api_req_friendly_name': 'AdditionalProfilePlusCreationMutation',
            'variables': '{"input":{"bio":"","categories":["181475575221097"],"creation_source":"comet","name":"' + self.name + '","page_referrer":"launch_point","actor_id":"' + self.id_acc + '","client_mutation_id":"1"}}',
            'server_timestamps': 'true',
            'doc_id': '5903223909690825',
        }
        try:
            response = requests.post('https://www.facebook.com/api/graphql/', headers=headers, data=data)
            return response.json()
        except Exception:
            return {}

def is_reg_success(result: dict) -> bool:
    try:
        if 'data' in result and 'additional_profile_plus_create' in result['data']:
            data = result['data']['additional_profile_plus_create']
            if data.get('page') and data['page'].get('id'):
                return True
            if data.get('additional_profile') and data['additional_profile'].get('id'):
                return True
            if data.get('error_message'):
                return False
            if data.get('name_error'):
                return False
        return False
    except:
        return False

def get_page_id_from_result(result: dict) -> str:
    try:
        if 'data' in result and 'additional_profile_plus_create' in result['data']:
            data = result['data']['additional_profile_plus_create']
            if data.get('page') and data['page'].get('id'):
                return data['page']['id']
            if data.get('additional_profile') and data['additional_profile'].get('id'):
                return data['additional_profile']['id']
        return 'Unknown'
    except:
        return 'Unknown'

# ===================== TÊN RANDOM =====================
NAM = ["Nguyễn Văn An", "Trần Văn Bình", "Lê Văn Cường", "Phạm Văn Dũng", "Hoàng Văn Em",
       "Huỳnh Văn Giang", "Phan Văn Hùng", "Vũ Văn Khánh", "Đỗ Văn Long", "Ngô Văn Minh"]
NU  = ["Nguyễn Thị Lan", "Trần Thị Mai", "Lê Thị Hoa", "Phạm Thị Hạnh", "Hoàng Thị Hằng",
       "Huỳnh Thị Huệ", "Phan Thị Khánh", "Vũ Thị Lam", "Đỗ Thị My", "Ngô Thị Nga"]

def get_random_name():
    return random.choice(NAM + NU)

def random_page_name():
    ho = random.choice(["Nguyễn", "Trần", "Lê", "Phạm"])
    lot = random.choice(["Công", "Đức", "Duy", "Gia"])
    ten = random.choice(["Hưng", "Anh", "Văn", "Tuấn"])
    return f"{ho} {lot} {ten}"

# ===================== BÀN PHÍM =====================
def reply_keyboard_main():
    return ReplyKeyboardMarkup(
        [
            [KeyboardButton("🌐 Proxy"), KeyboardButton("🤖 Nuôi FB"), KeyboardButton("📄 Reg Page")],
            [KeyboardButton("📊 Trạng thái"), KeyboardButton("⏹ Dừng tất cả"), KeyboardButton("🏠 Menu")],
        ],
        resize_keyboard=True,
        input_field_placeholder="Chọn chức năng hoặc gõ lệnh..."
    )

def main_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🌐 Tool Proxy",     callback_data="menu_proxy"),
            InlineKeyboardButton("🤖 Nuôi Facebook",  callback_data="menu_nuoi"),
        ],
        [
            InlineKeyboardButton("📄 Reg Page Pro5",  callback_data="menu_reg"),
            InlineKeyboardButton("📊 Trạng thái",     callback_data="status"),
        ],
        [InlineKeyboardButton("❓ Hướng dẫn",         callback_data="help")],
    ])

def proxy_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("⛏️ Đào Proxy",       callback_data="proxy_dao"),
            InlineKeyboardButton("✅ Kiểm tra Proxy",  callback_data="proxy_check"),
        ],
        [
            InlineKeyboardButton("📋 Xem danh sách",  callback_data="proxy_list"),
            InlineKeyboardButton("🗑️ Xóa proxy",      callback_data="proxy_clear"),
        ],
        [InlineKeyboardButton("🔙 Quay lại Menu",     callback_data="back_main")],
    ])

def nuoi_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🍪 Thêm Cookie FB", callback_data="nuoi_addcookie"),
            InlineKeyboardButton("📋 Xem Cookies",    callback_data="nuoi_listcookie"),
        ],
        [
            InlineKeyboardButton("▶️ Bắt đầu nuôi",  callback_data="nuoi_start"),
            InlineKeyboardButton("⏹️ Dừng nuôi",     callback_data="nuoi_stop"),
        ],
        [
            InlineKeyboardButton("🗑️ Xóa Cookies",   callback_data="nuoi_clearcookie"),
            InlineKeyboardButton("🔙 Quay lại Menu", callback_data="back_main"),
        ],
    ])

def reg_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("▶️ Bắt đầu Reg",   callback_data="reg_start"),
            InlineKeyboardButton("⏹️ Dừng Reg",      callback_data="reg_stop"),
        ],
        [InlineKeyboardButton("🔙 Quay lại Menu", callback_data="back_main")],
    ])

# ===================== DECORATOR KIỂM TRA KEY =====================
def require_key(func):
    async def wrapper(update: Update, ctx: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        if not is_user_key_valid(user_id):
            await update.effective_message.reply_text(
                "🔐 *Bạn chưa có key hoặc key đã hết hạn!*\n\n"
                "Vui lòng tạo key mới bằng lệnh:\n"
                "➡️ `/getkey 12` (key 12 giờ)\n"
                "➡️ `/getkey 24` (key 24 giờ)\n\n"
                "Sau khi có key, dùng `/active <key>` để kích hoạt.",
                parse_mode="Markdown"
            )
            return
        return await func(update, ctx, *args, **kwargs)
    return wrapper

# ===================== LỆNH KEY =====================
async def cmd_getkey(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    args = ctx.args
    if not args or args[0] not in ['12', '24']:
        await update.message.reply_text(
            "❗ Cú pháp: `/getkey 12` hoặc `/getkey 24`\n"
            "Ví dụ: `/getkey 24` để tạo key 24 giờ.",
            parse_mode="Markdown"
        )
        return
    expiry_hours = int(args[0])
    key = create_key(expiry_hours)
    
    if expiry_hours == 24:
        final_link = build_double_shortened_link(key)
        step_desc = "2 lần vượt link"
    else:
        final_link = build_single_shortened_link(key)
        step_desc = "1 lần vượt link"
    
    if not final_link:
        await update.message.reply_text(
            "❌ Không thể tạo link rút gọn. Vui lòng thử lại sau.\n"
            f"🔑 Key dự phòng: `{key}`\n"
            f"Link trực tiếp: {make_key_link(key)}",
            parse_mode="Markdown"
        )
        return
    
    await update.message.reply_text(
        f"🔑 *Tạo key {expiry_hours} giờ thành công!*\n\n"
        f"📌 *Hướng dẫn:*\n"
        f"1. Nhấp vào link bên dưới\n"
        f"2. Vượt link {step_desc}\n"
        f"3. Sao chép key nhận được (dạng `TL-{expiry_hours}-XXXX-XXXX-XXXX`)\n"
        f"4. Dùng lệnh `/active <key_vua_nhan>` để kích hoạt\n\n"
        f"🔗 *Link lấy key:*\n{final_link}\n\n"
        f"⚠️ Key này chỉ có hiệu lực sau khi bạn active.",
        parse_mode="Markdown"
    )

async def cmd_active(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    args = ctx.args
    if not args:
        await update.message.reply_text("❗ Cú pháp: `/active <key>`", parse_mode="Markdown")
        return
    key = args[0].upper()
    
    if not re.match(r'^TL-(12|24)-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$', key):
        await update.message.reply_text("❌ Key không đúng định dạng. Hãy copy chính xác key từ link.", parse_mode="Markdown")
        return
    
    expiry_hours = 24 if key.startswith('TL-24') else 12
    activate_user_key(user_id, key, expiry_hours)
    expire_time = time.time() + expiry_hours * 3600
    await update.message.reply_text(
        f"✅ *Key đã được kích hoạt!*\n"
        f"🔑 Key: `{key}`\n"
        f"⏳ Hiệu lực: {expiry_hours} giờ\n"
        f"📅 Hết hạn lúc: {time.strftime('%H:%M %d/%m/%Y', time.localtime(expire_time))}\n\n"
        f"🛠️ Bạn có thể sử dụng bot ngay bây giờ!",
        parse_mode="Markdown",
        reply_markup=reply_keyboard_main()
    )

async def cmd_mykey(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    info = get_user_key_info(user_id)
    if not info:
        await update.message.reply_text(
            "🔐 Bạn chưa có key hoặc key đã hết hạn.\n"
            "Dùng `/getkey` để tạo key mới.",
            parse_mode="Markdown"
        )
        return
    key, created, expiry_hours = info
    remaining = (created + expiry_hours * 3600 - time.time()) / 3600
    expire_time = datetime.fromtimestamp(created + expiry_hours * 3600)
    await update.message.reply_text(
        f"🔑 *Thông tin key của bạn*\n"
        f"Key: `{key}`\n"
        f"Loại: {expiry_hours} giờ\n"
        f"Thời gian còn lại: {remaining:.1f} giờ\n"
        f"Hết hạn lúc: {expire_time.strftime('%H:%M %d/%m/%Y')}",
        parse_mode="Markdown"
    )

# ===================== HÀM CANCEL DÙNG CHUNG =====================
async def cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    ud = get_user(uid)
    ctx.user_data["waiting"] = ""
    if ud["task"] and not ud["task"].done():
        ud["task"].cancel()
    ud["running"] = False
    await update.message.reply_text("❌ *Đã hủy.*", parse_mode="Markdown", reply_markup=reply_keyboard_main())

# ===================== CONVERSATION HANDLER CHO NUÔI FB =====================
# (Giữ nguyên các hàm từ bản trước, chỉ thêm log)
async def nuoi_select_tasks(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    selected = ctx.user_data.get("selected_tasks", [])
    tasks = ["reaction", "follow", "group", "add_friend"]
    keyboard = []
    for t in tasks:
        status = "✅" if t in selected else "❌"
        keyboard.append([InlineKeyboardButton(f"{status} {t}", callback_data=f"toggle_{t}")])
    keyboard.append([InlineKeyboardButton("✅ Xác nhận", callback_data="confirm_tasks")])
    keyboard.append([InlineKeyboardButton("🔙 Hủy", callback_data="cancel_nuoi")])
    await query.edit_message_text(
        "📌 *Chọn nhiệm vụ nuôi FB:*\n"
        "Bấm vào nút để bật/tắt. Bạn có thể chọn nhiều.\n"
        "Sau khi chọn xong, bấm '✅ Xác nhận' để tiếp tục.",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return SELECT_TASKS

async def toggle_task(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    task = query.data.split("_")[1]
    selected = ctx.user_data.get("selected_tasks", [])
    if task in selected:
        selected.remove(task)
    else:
        selected.append(task)
    ctx.user_data["selected_tasks"] = selected
    
    tasks = ["reaction", "follow", "group", "add_friend"]
    keyboard = []
    for t in tasks:
        status = "✅" if t in selected else "❌"
        keyboard.append([InlineKeyboardButton(f"{status} {t}", callback_data=f"toggle_{t}")])
    keyboard.append([InlineKeyboardButton("✅ Xác nhận", callback_data="confirm_tasks")])
    keyboard.append([InlineKeyboardButton("🔙 Hủy", callback_data="cancel_nuoi")])
    await query.edit_message_text(
        "📌 *Chọn nhiệm vụ nuôi FB:*\n"
        "Bấm vào nút để bật/tắt. Bạn có thể chọn nhiều.\n"
        "Sau khi chọn xong, bấm '✅ Xác nhận' để tiếp tục.",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return SELECT_TASKS

async def confirm_tasks(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    selected = ctx.user_data.get("selected_tasks", [])
    if not selected:
        await query.edit_message_text("❌ Bạn chưa chọn nhiệm vụ nào. Vui lòng chọn ít nhất một nhiệm vụ.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="back_to_select")]]))
        return SELECT_TASKS
    ctx.user_data["nuoi_tasks"] = selected
    await query.edit_message_text(
        f"✅ Đã chọn các nhiệm vụ: {', '.join(selected)}\n\n"
        "➡️ *Bước 2/5: Delay sau mỗi job (giây)*\n"
        "Ví dụ: `5` (nghỉ 5 giây sau mỗi lần thực hiện thành công)\n"
        "Gửi số (có thể là số thực, ví dụ 2.5):",
        parse_mode="Markdown"
    )
    return INPUT_DELAY

async def back_to_select(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    selected = ctx.user_data.get("selected_tasks", [])
    tasks = ["reaction", "follow", "group", "add_friend"]
    keyboard = []
    for t in tasks:
        status = "✅" if t in selected else "❌"
        keyboard.append([InlineKeyboardButton(f"{status} {t}", callback_data=f"toggle_{t}")])
    keyboard.append([InlineKeyboardButton("✅ Xác nhận", callback_data="confirm_tasks")])
    keyboard.append([InlineKeyboardButton("🔙 Hủy", callback_data="cancel_nuoi")])
    await query.edit_message_text(
        "📌 *Chọn nhiệm vụ nuôi FB:*\n"
        "Bấm vào nút để bật/tắt. Bạn có thể chọn nhiều.\n"
        "Sau khi chọn xong, bấm '✅ Xác nhận' để tiếp tục.",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return SELECT_TASKS

async def input_delay(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    try:
        delay_val = float(update.message.text.strip())
        if delay_val < 0:
            raise ValueError
    except:
        await update.message.reply_text("❌ Vui lòng nhập một số hợp lệ (lớn hơn hoặc bằng 0).")
        return INPUT_DELAY
    ctx.user_data["delay_val"] = delay_val
    await update.message.reply_text(
        "➡️ *Bước 3/5: Sau bao nhiêu job thành công thì nghỉ chống block (job_block)*\n"
        "Ví dụ: `10` (sau 10 lần thành công sẽ nghỉ dài)\n"
        "Gửi số nguyên:",
        parse_mode="Markdown"
    )
    return INPUT_JOB_BLOCK

async def input_job_block(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    try:
        job_block = int(update.message.text.strip())
        if job_block <= 0:
            raise ValueError
    except:
        await update.message.reply_text("❌ Vui lòng nhập số nguyên dương.")
        return INPUT_JOB_BLOCK
    ctx.user_data["job_block"] = job_block
    await update.message.reply_text(
        "➡️ *Bước 4/5: Thời gian nghỉ khi chống block (delay_block - giây)*\n"
        "Ví dụ: `30` (nghỉ 30 giây sau mỗi job_block lần)\n"
        "Gửi số (có thể là số thực):",
        parse_mode="Markdown"
    )
    return INPUT_DELAY_BLOCK

async def input_delay_block(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    try:
        delay_block = float(update.message.text.strip())
        if delay_block < 0:
            raise ValueError
    except:
        await update.message.reply_text("❌ Vui lòng nhập số hợp lệ (lớn hơn hoặc bằng 0).")
        return INPUT_DELAY_BLOCK
    ctx.user_data["delay_block"] = delay_block
    await update.message.reply_text(
        "➡️ *Bước 5/5: Sau bao nhiêu job thành công thì đổi tài khoản (job_break)*\n"
        "Ví dụ: `5` (sau 5 job thành công sẽ chuyển sang cookie tiếp theo)\n"
        "Gửi số nguyên dương:",
        parse_mode="Markdown"
    )
    return INPUT_JOB_BREAK

async def input_job_break(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    try:
        job_break = int(update.message.text.strip())
        if job_break <= 0:
            raise ValueError
    except:
        await update.message.reply_text("❌ Vui lòng nhập số nguyên dương.")
        return INPUT_JOB_BREAK
    ctx.user_data["job_break"] = job_break
    
    tasks = ctx.user_data["nuoi_tasks"]
    delay_val = ctx.user_data["delay_val"]
    job_block = ctx.user_data["job_block"]
    delay_block = ctx.user_data["delay_block"]
    job_break_val = ctx.user_data["job_break"]
    
    user_id = update.effective_user.id
    ud = get_user(user_id)
    
    ud["running"] = True
    await update.message.reply_text(
        f"▶️ *Bắt đầu nuôi FB!*\n"
        f"• Nhiệm vụ: {', '.join(tasks)}\n"
        f"• Delay: {delay_val}s | Block: {job_block} lần → nghỉ {delay_block}s\n"
        f"• Đổi acc sau: {job_break_val} nhiệm vụ",
        parse_mode="Markdown"
    )
    
    async def run_nuoi_with_key_check():
        stt = 0
        ds_camxuc = ["LIKE", "LOVE", "CARE", "HAHA", "WOW", "SAD", "ANGRY"]
        cookies_copy = list(ud["cookies_fb"])
        cookie_idx = 0
        
        while ud["running"] and cookies_copy:
            if not is_user_key_valid(user_id):
                await update.message.reply_text(
                    "🔐 *Key của bạn đã hết hạn!*\n"
                    "Vui lòng tạo key mới bằng `/getkey` và active bằng `/active` để tiếp tục sử dụng bot.\n"
                    "Task nuôi FB đã dừng lại.",
                    parse_mode="Markdown"
                )
                ud["running"] = False
                break
            
            cookie = cookies_copy[cookie_idx % len(cookies_copy)]
            fb = await asyncio.to_thread(Facebook, cookie)
            info = await asyncio.to_thread(fb.info)
            if not isinstance(info, dict) or 'success' not in info:
                await update.message.reply_text(f"❌ Cookie #{cookie_idx+1} die, bỏ qua")
                if cookie in ud["cookies_fb"]:
                    ud["cookies_fb"].remove(cookie)
                cookies_copy.remove(cookie)
                if not cookies_copy:
                    break
                continue
            
            name_fb = info['name']
            job_success = 0
            job_fail = 0
            
            while ud["running"]:
                if not ud["running"]: break
                nv = random.choice(tasks)
                result_msg = ""
                success = False
                try:
                    if nv == "reaction":
                        post = await asyncio.to_thread(fb.getidpost)
                        if isinstance(post, dict) and post.get('status') == 'success':
                            camxuc = random.choice(ds_camxuc)
                            r = await asyncio.to_thread(fb.reaction, post['idpost'], camxuc)
                            if isinstance(r, dict) and r.get('trangthai') == 'thanhcong':
                                success = True
                                stt += 1; job_success += 1
                                result_msg = f"✅ #{stt} | {name_fb} | {camxuc} | {post['idpost']}"
                            else:
                                job_fail += 1
                    elif nv == "follow":
                        ten = get_random_name()
                        tb = await asyncio.to_thread(fb.timban, ten)
                        if isinstance(tb, dict) and tb.get('status') == 'success':
                            r = await asyncio.to_thread(fb.follow, tb['id'])
                            if isinstance(r, dict) and r.get('trangthai') == 'thanhcong':
                                success = True
                                stt += 1; job_success += 1
                                result_msg = f"✅ #{stt} | {name_fb} | FOLLOW | {tb['name']}"
                            else:
                                job_fail += 1
                    elif nv == "group":
                        ten = get_random_name()
                        tg = await asyncio.to_thread(fb.getidgr, ten)
                        if isinstance(tg, dict) and tg.get('status') == 'success':
                            r = await asyncio.to_thread(fb.group, tg['id'])
                            if isinstance(r, dict) and r.get('trangthai') == 'thanhcong':
                                success = True
                                stt += 1; job_success += 1
                                result_msg = f"✅ #{stt} | {name_fb} | GROUP | {tg['name']}"
                            else:
                                job_fail += 1
                    elif nv == "add_friend":
                        ten = get_random_name()
                        tb = await asyncio.to_thread(fb.timban, ten)
                        if isinstance(tb, dict) and tb.get('status') == 'success':
                            r = await asyncio.to_thread(fb.ketban, tb['id'])
                            if isinstance(r, dict) and r.get('trangthai') == 'thanhcong':
                                success = True
                                stt += 1; job_success += 1
                                result_msg = f"✅ #{stt} | {name_fb} | ADD FRIEND | {tb['name']}"
                            else:
                                job_fail += 1
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    job_fail += 1
                    logger.error(f"nuoi_task error: {e}")
                
                if result_msg:
                    try:
                        await update.message.reply_text(result_msg)
                    except Exception:
                        pass
                
                if job_fail >= 15:
                    chk = await asyncio.to_thread(fb.info)
                    if not isinstance(chk, dict) or 'success' not in chk:
                        await update.message.reply_text(f"⚠️ {name_fb} bị lỗi/die, đổi acc")
                        if cookie in ud["cookies_fb"]:
                            ud["cookies_fb"].remove(cookie)
                        cookies_copy.remove(cookie)
                        break
                    job_fail = 0
                
                if success:
                    if job_success % job_block == 0:
                        await asyncio.sleep(delay_block)
                    else:
                        await asyncio.sleep(delay_val)
                else:
                    await asyncio.sleep(1)
                
                if job_success >= job_break_val:
                    cookie_idx += 1
                    break
        
        ud["running"] = False
        try:
            await update.message.reply_text(
                f"⏹️ *Nuôi FB kết thúc!*\n📊 Tổng: {stt} nhiệm vụ thành công",
                parse_mode="Markdown",
                reply_markup=nuoi_keyboard()
            )
        except Exception:
            pass
    
    ud["task"] = asyncio.create_task(run_nuoi_with_key_check())
    return ConversationHandler.END

async def cancel_nuoi(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await query.edit_message_text("❌ Đã hủy cấu hình nuôi FB.", reply_markup=nuoi_keyboard())
    return ConversationHandler.END

async def nuoi_start_conversation(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    ud = get_user(user_id)
    if not ud["cookies_fb"]:
        await query.edit_message_text("⚠️ *Chưa có cookie FB!*\nThêm cookie trước.", parse_mode="Markdown", reply_markup=nuoi_keyboard())
        return
    if ud["running"]:
        await query.edit_message_text("⚠️ Đang chạy rồi.", reply_markup=nuoi_keyboard())
        return
    ctx.user_data["selected_tasks"] = []
    tasks = ["reaction", "follow", "group", "add_friend"]
    keyboard = []
    for t in tasks:
        keyboard.append([InlineKeyboardButton(f"❌ {t}", callback_data=f"toggle_{t}")])
    keyboard.append([InlineKeyboardButton("✅ Xác nhận", callback_data="confirm_tasks")])
    keyboard.append([InlineKeyboardButton("🔙 Hủy", callback_data="cancel_nuoi")])
    await query.edit_message_text(
        "📌 *Chọn nhiệm vụ nuôi FB:*\n"
        "Bấm vào nút để bật/tắt. Bạn có thể chọn nhiều.\n"
        "Sau khi chọn xong, bấm '✅ Xác nhận' để tiếp tục.",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return SELECT_TASKS

nuoi_conv_handler = ConversationHandler(
    entry_points=[CallbackQueryHandler(nuoi_start_conversation, pattern="^nuoi_start$")],
    states={
        SELECT_TASKS: [
            CallbackQueryHandler(toggle_task, pattern="^toggle_"),
            CallbackQueryHandler(confirm_tasks, pattern="^confirm_tasks$"),
            CallbackQueryHandler(back_to_select, pattern="^back_to_select$"),
            CallbackQueryHandler(cancel_nuoi, pattern="^cancel_nuoi$"),
        ],
        INPUT_DELAY: [MessageHandler(filters.TEXT & ~filters.COMMAND, input_delay)],
        INPUT_JOB_BLOCK: [MessageHandler(filters.TEXT & ~filters.COMMAND, input_job_block)],
        INPUT_DELAY_BLOCK: [MessageHandler(filters.TEXT & ~filters.COMMAND, input_delay_block)],
        INPUT_JOB_BREAK: [MessageHandler(filters.TEXT & ~filters.COMMAND, input_job_break)],
    },
    fallbacks=[CommandHandler("cancel", cancel)],
)

# ===================== CONVERSATION HANDLER CHO REG PAGE =====================
# (Giữ nguyên như bản trước, đã hoạt động)
async def reg_start_conversation(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    ud = get_user(user_id)
    if ud["running"]:
        await query.edit_message_text("⚠️ Đang có task chạy, hãy dừng trước khi bắt đầu reg mới.", reply_markup=reg_keyboard())
        return
    ud["cookie_reg"] = []
    ctx.user_data["reg_cookies_temp"] = []
    await query.edit_message_text(
        "📝 *Cấu hình Reg Page Pro5*\n\n"
        "➡️ *Bước 1/5: Nhập cookie Facebook (mỗi dòng 1 cookie)*\n"
        "Bạn có thể nhập nhiều cookie, mỗi cookie trên một dòng.\n"
        "Sau khi nhập xong, gửi /done để kết thúc nhập cookie.\n"
        "Hoặc gửi /cancel để hủy.\n\n"
        "Ví dụ:\n"
        "c_user=123...; xs=...\n"
        "c_user=456...; xs=...",
        parse_mode="Markdown"
    )
    return REG_INPUT_COOKIES

async def reg_input_cookies(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if 'c_user=' not in text:
        await update.message.reply_text("❌ Cookie không hợp lệ (thiếu c_user=). Vui lòng gửi lại hoặc gửi /done để kết thúc.")
        return REG_INPUT_COOKIES
    ctx.user_data.setdefault("reg_cookies_temp", []).append(text)
    await update.message.reply_text(f"✅ Đã thêm cookie #{len(ctx.user_data['reg_cookies_temp'])}. Nhập tiếp (hoặc gửi /done để kết thúc):")
    return REG_INPUT_COOKIES

async def reg_done(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    cookies = ctx.user_data.get("reg_cookies_temp", [])
    if not cookies:
        await update.message.reply_text("❌ Bạn chưa nhập cookie nào. Hãy nhập ít nhất một cookie.")
        return REG_INPUT_COOKIES
    user_id = update.effective_user.id
    ud = get_user(user_id)
    ud["cookie_reg"] = cookies
    await update.message.reply_text(
        f"✅ Đã lưu {len(cookies)} cookie reg page.\n\n"
        "➡️ *Bước 2/5: Delay MIN (giây)*\n"
        "Ví dụ: `1500` (tối thiểu 1500 giây giữa các lần reg)\n"
        "Gửi số:",
        parse_mode="Markdown"
    )
    return REG_INPUT_DELAY_MIN

async def reg_input_delay_min(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    try:
        delay_min = int(update.message.text.strip())
        if delay_min < 0:
            raise ValueError
        ctx.user_data["reg_delay_min"] = delay_min
        await update.message.reply_text(
            "➡️ *Bước 3/5: Delay MAX (giây)*\n"
            "Ví dụ: `1800` (tối đa 1800 giây)\n"
            "Gửi số (delay sẽ random trong khoảng min-max):",
            parse_mode="Markdown"
        )
        return REG_INPUT_DELAY_MAX
    except:
        await update.message.reply_text("❌ Vui lòng nhập số hợp lệ (lớn hơn hoặc bằng 0).")
        return REG_INPUT_DELAY_MIN

async def reg_input_delay_max(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    try:
        delay_max = int(update.message.text.strip())
        if delay_max < ctx.user_data.get("reg_delay_min", 0):
            await update.message.reply_text("❌ Delay MAX phải lớn hơn hoặc bằng Delay MIN.")
            return REG_INPUT_DELAY_MAX
        ctx.user_data["reg_delay_max"] = delay_max
        await update.message.reply_text(
            "➡️ *Bước 4/5: Chọn cách chạy*\n"
            "Gửi `Y` hoặc `N`:\n"
            "• `Y` - Reg cùng lúc: sau khi delay xong, reg mỗi acc 1 page (chạy lần lượt từng acc)\n"
            "• `N` - Reg tuần tự: reg xong hết số page của acc này rồi mới chuyển acc khác",
            parse_mode="Markdown"
        )
        return REG_INPUT_MODE
    except:
        await update.message.reply_text("❌ Vui lòng nhập số hợp lệ.")
        return REG_INPUT_DELAY_MAX

async def reg_input_mode(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    mode = update.message.text.strip().upper()
    if mode not in ['Y', 'N']:
        await update.message.reply_text("❌ Vui lòng gửi `Y` hoặc `N`.")
        return REG_INPUT_MODE
    ctx.user_data["reg_mode"] = mode
    await update.message.reply_text(
        "➡️ *Bước 5/5: Số page muốn reg cho mỗi acc*\n"
        "Ví dụ: `10` (mỗi cookie reg 10 page)\n"
        "Gửi số nguyên dương (hoặc 0 để chạy vô hạn):",
        parse_mode="Markdown"
    )
    return REG_INPUT_PAGES_PER_ACC

async def reg_input_pages_per_acc(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    try:
        pages_per_acc = int(update.message.text.strip())
        if pages_per_acc < 0:
            raise ValueError
        ctx.user_data["reg_pages_per_acc"] = pages_per_acc
    except:
        await update.message.reply_text("❌ Vui lòng nhập số nguyên (0 = vô hạn).")
        return REG_INPUT_PAGES_PER_ACC
    
    user_id = update.effective_user.id
    ud = get_user(user_id)
    cookies = ud["cookie_reg"]
    delay_min = ctx.user_data["reg_delay_min"]
    delay_max = ctx.user_data["reg_delay_max"]
    mode = ctx.user_data["reg_mode"]
    pages_per_acc = ctx.user_data["reg_pages_per_acc"]
    
    if not cookies:
        await update.message.reply_text("❌ Chưa có cookie reg nào. Vui lòng bắt đầu lại.", reply_markup=reg_keyboard())
        return ConversationHandler.END
    
    ud["running"] = True
    await update.message.reply_text(
        f"▶️ *Bắt đầu Reg Page Pro5!*\n"
        f"• Số cookie: {len(cookies)}\n"
        f"• Delay: {delay_min}s - {delay_max}s (random)\n"
        f"• Cách chạy: {'Cùng lúc (reg mỗi acc 1 page rồi vòng tiếp)' if mode == 'Y' else 'Tuần tự (reg hết page của acc rồi mới chuyển)'}\n"
        f"• Số page/acc: {'Vô hạn' if pages_per_acc == 0 else pages_per_acc}",
        parse_mode="Markdown"
    )
    
    async def run_reg_with_key_check():
        total_pages_regged = 0
        total_pages_success = 0
        total_pages_failed = 0
        
        if mode == 'Y':
            acc_pages_done = [0] * len(cookies)
            
            while ud["running"]:
                if not is_user_key_valid(user_id):
                    await update.message.reply_text(
                        "🔐 *Key của bạn đã hết hạn!*\n"
                        "Vui lòng tạo key mới và active để tiếp tục.\n"
                        "Task Reg Page đã dừng lại.",
                        parse_mode="Markdown"
                    )
                    ud["running"] = False
                    break
                
                all_done = True
                for i, done in enumerate(acc_pages_done):
                    if pages_per_acc == 0 or done < pages_per_acc:
                        all_done = False
                        break
                if all_done:
                    break
                
                for i, cookie in enumerate(cookies):
                    if not ud["running"]:
                        break
                    if pages_per_acc > 0 and acc_pages_done[i] >= pages_per_acc:
                        continue
                    
                    name = random_page_name()
                    try:
                        reg = await asyncio.to_thread(RegPro5, cookie, name)
                        result = await asyncio.to_thread(reg.Reg)
                        total_pages_regged += 1
                        
                        if is_reg_success(result):
                            page_id = get_page_id_from_result(result)
                            total_pages_success += 1
                            acc_pages_done[i] += 1
                            await update.message.reply_text(
                                f"✅ *Reg thành công!*\n"
                                f"📄 Page #{total_pages_success} | Acc {i+1}\n"
                                f"👤 Tên: {name}\n"
                                f"🆔 Page ID: `{page_id}`\n"
                                f"📊 Tổng: {total_pages_success}/{total_pages_regged} thành công",
                                parse_mode="Markdown"
                            )
                        else:
                            total_pages_failed += 1
                            error_msg = str(result)[:200]
                            await update.message.reply_text(
                                f"❌ *Reg thất bại!*\n"
                                f"📄 Page #{total_pages_regged} | Acc {i+1}\n"
                                f"👤 Tên: {name}\n"
                                f"⚠️ Lỗi: `{error_msg}`\n\n"
                                f"🛑 Dừng toàn bộ task reg page!",
                                parse_mode="Markdown"
                            )
                            ud["running"] = False
                            break
                    except asyncio.CancelledError:
                        raise
                    except Exception as e:
                        total_pages_failed += 1
                        await update.message.reply_text(f"❌ Lỗi Reg: {e}\n🛑 Dừng task!", parse_mode="Markdown")
                        ud["running"] = False
                        break
                    
                    delay = random.randint(delay_min, delay_max) if delay_max > delay_min else delay_min
                    for _ in range(delay):
                        if not ud["running"]:
                            break
                        await asyncio.sleep(1)
                
                if ud["running"]:
                    delay = random.randint(delay_min, delay_max) if delay_max > delay_min else delay_min
                    for _ in range(delay):
                        if not ud["running"]:
                            break
                        await asyncio.sleep(1)
        else:
            for i, cookie in enumerate(cookies):
                if not ud["running"]:
                    break
                if not is_user_key_valid(user_id):
                    await update.message.reply_text(
                        "🔐 *Key của bạn đã hết hạn!*\n"
                        "Vui lòng tạo key mới và active để tiếp tục.\n"
                        "Task Reg Page đã dừng lại.",
                        parse_mode="Markdown"
                    )
                    ud["running"] = False
                    break
                
                page_count = 0
                while ud["running"]:
                    if pages_per_acc > 0 and page_count >= pages_per_acc:
                        break
                    
                    name = random_page_name()
                    try:
                        reg = await asyncio.to_thread(RegPro5, cookie, name)
                        result = await asyncio.to_thread(reg.Reg)
                        total_pages_regged += 1
                        page_count += 1
                        
                        if is_reg_success(result):
                            page_id = get_page_id_from_result(result)
                            total_pages_success += 1
                            await update.message.reply_text(
                                f"✅ *Reg thành công!*\n"
                                f"📄 Page #{total_pages_success} | Acc {i+1}\n"
                                f"👤 Tên: {name}\n"
                                f"🆔 Page ID: `{page_id}`\n"
                                f"📊 Tổng: {total_pages_success}/{total_pages_regged} thành công",
                                parse_mode="Markdown"
                            )
                        else:
                            total_pages_failed += 1
                            error_msg = str(result)[:200]
                            await update.message.reply_text(
                                f"❌ *Reg thất bại!*\n"
                                f"📄 Page #{total_pages_regged} | Acc {i+1}\n"
                                f"👤 Tên: {name}\n"
                                f"⚠️ Lỗi: `{error_msg}`\n\n"
                                f"🛑 Dừng toàn bộ task reg page!",
                                parse_mode="Markdown"
                            )
                            ud["running"] = False
                            break
                    except asyncio.CancelledError:
                        raise
                    except Exception as e:
                        total_pages_failed += 1
                        await update.message.reply_text(f"❌ Lỗi Reg: {e}\n🛑 Dừng task!", parse_mode="Markdown")
                        ud["running"] = False
                        break
                    
                    delay = random.randint(delay_min, delay_max) if delay_max > delay_min else delay_min
                    for _ in range(delay):
                        if not ud["running"]:
                            break
                        await asyncio.sleep(1)
        
        ud["running"] = False
        try:
            await update.message.reply_text(
                f"⏹️ *Reg Page kết thúc!*\n"
                f"📊 Kết quả: Thành công {total_pages_success} / Thất bại {total_pages_failed} / Tổng {total_pages_regged} page",
                parse_mode="Markdown",
                reply_markup=reg_keyboard()
            )
        except Exception:
            pass
    
    ud["task"] = asyncio.create_task(run_reg_with_key_check())
    return ConversationHandler.END

async def reg_cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("❌ Đã hủy cấu hình Reg Page.", reply_markup=reg_keyboard())
    return ConversationHandler.END

reg_conv_handler = ConversationHandler(
    entry_points=[CallbackQueryHandler(reg_start_conversation, pattern="^reg_start$")],
    states={
        REG_INPUT_COOKIES: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, reg_input_cookies),
            CommandHandler("done", reg_done),
        ],
        REG_INPUT_DELAY_MIN: [MessageHandler(filters.TEXT & ~filters.COMMAND, reg_input_delay_min)],
        REG_INPUT_DELAY_MAX: [MessageHandler(filters.TEXT & ~filters.COMMAND, reg_input_delay_max)],
        REG_INPUT_MODE: [MessageHandler(filters.TEXT & ~filters.COMMAND, reg_input_mode)],
        REG_INPUT_PAGES_PER_ACC: [MessageHandler(filters.TEXT & ~filters.COMMAND, reg_input_pages_per_acc)],
    },
    fallbacks=[CommandHandler("cancel", reg_cancel)],
)

# ===================== CÁC HANDLER CHÍNH =====================
@require_key
async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    get_user(uid)
    name = update.effective_user.first_name or "bạn"
    await update.message.reply_text(
        "⌨️ Thanh công cụ nhanh đã bật!",
        reply_markup=reply_keyboard_main()
    )
    await update.message.reply_text(
        f"╔══════════════════════╗\n"
        f"║   🔥 *TLTOOL BOT* 🔥   ║\n"
        f"╚══════════════════════╝\n\n"
        f"👋 Xin chào *{name}*!\n\n"
        f"🛠️ *Danh sách công cụ:*\n"
        f"├ 🌐 Tool Đào & Kiểm tra Proxy\n"
        f"├ 🤖 Nuôi Facebook tự động\n"
        f"└ 📄 Reg Page Pro5\n\n"
        f"⬇️ Chọn công cụ bên dưới:",
        parse_mode="Markdown",
        reply_markup=main_keyboard()
    )

@require_key
async def button_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    uid = query.from_user.id
    ud = get_user(uid)
    data = query.data

    if data == "back_main":
        await query.edit_message_text(
            "╔══════════════════════╗\n"
            "║   🔥 *TLTOOL BOT* 🔥   ║\n"
            "╚══════════════════════╝\n\n"
            "⬇️ Chọn công cụ:",
            parse_mode="Markdown", reply_markup=main_keyboard()
        )
    elif data == "help":
        await query.edit_message_text(
            "❓ *HƯỚNG DẪN SỬ DỤNG*\n\n"
            "🌐 *Tool Proxy:*\n"
            "├ ⛏️ Đào → lấy proxy từ 15+ nguồn\n"
            "├ ✅ Kiểm tra → lọc proxy sống/chết\n"
            "└ 📋 Xem danh sách proxy đã đào\n\n"
            "🤖 *Nuôi Facebook:*\n"
            "├ 🍪 Thêm cookie FB (nhiều cookie OK)\n"
            "├ ▶️ Bắt đầu → chọn nhiệm vụ bằng nút bấm\n"
            "├ Sau đó nhập các tham số theo hướng dẫn\n"
            "└ Nhiệm vụ: reaction/follow/group/add\\_friend\n\n"
            "📄 *Reg Page Pro5:*\n"
            "├ ▶️ Bắt đầu Reg → nhập cookie (mỗi dòng 1 cookie, gửi /done khi xong)\n"
            "├ Sau đó nhập delay min/max, cách chạy, số page/acc\n"
            "├ Cách chạy: Y (cùng lúc) / N (tuần tự)\n"
            "└ Nếu reg thất bại sẽ dừng toàn bộ task\n\n"
            "⌨️ *Thanh nhanh dưới ô chat:*\n"
            "Bấm trực tiếp để vào menu nhanh\\!\n\n"
            "⏹️ Dùng /cancel để dừng mọi thứ",
            parse_mode="MarkdownV2",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 Quay lại Menu", callback_data="back_main")
            ]])
        )
    elif data == "menu_proxy":
        await query.edit_message_text(
            "🌐 *TOOL PROXY*\n━━━━━━━━━━━━━━━\nChọn chức năng:",
            parse_mode="Markdown", reply_markup=proxy_keyboard()
        )
    elif data == "menu_nuoi":
        n = len(ud["cookies_fb"])
        status = "🟢 Đang chạy" if ud["running"] else "🔴 Dừng"
        await query.edit_message_text(
            f"🤖 *NUÔI FACEBOOK*\n━━━━━━━━━━━━━━━\n🍪 Cookies: {n} | {status}\n\nChọn chức năng:",
            parse_mode="Markdown", reply_markup=nuoi_keyboard()
        )
    elif data == "menu_reg":
        n = len(ud["cookie_reg"])
        status = "🟢 Đang chạy" if ud["running"] else "🔴 Dừng"
        await query.edit_message_text(
            f"📄 *REG PAGE PRO5*\n━━━━━━━━━━━━━━━\n🍪 Cookies: {n} | {status}\n\nChọn chức năng:",
            parse_mode="Markdown", reply_markup=reg_keyboard()
        )
    elif data == "status":
        n_cookie_fb = len(ud["cookies_fb"])
        n_cookie_reg = len(ud["cookie_reg"])
        running = "🟢 Đang chạy" if ud["running"] else "🔴 Đang nghỉ"
        n_proxy = len(ud.get("proxy_list", []))
        await query.edit_message_text(
            f"📊 *TRẠNG THÁI CỦA BẠN*\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🤖 Task: {running}\n"
            f"🍪 Cookies Nuôi FB: {n_cookie_fb} tài khoản\n"
            f"📄 Cookies Reg Page: {n_cookie_reg} tài khoản\n"
            f"🌐 Proxy đã đào: {n_proxy}",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Làm mới", callback_data="status")],
                [InlineKeyboardButton("🔙 Quay lại", callback_data="back_main")],
            ])
        )
    # Proxy handlers
    elif data == "proxy_dao":
        if ud["running"]:
            await query.edit_message_text("⚠️ *Đang có task chạy!*\nDừng task trước rồi đào proxy.", parse_mode="Markdown", reply_markup=proxy_keyboard())
            return
        await query.edit_message_text("⏳ *Đang đào proxy...*\n🔄 Kết nối tới 15+ nguồn, chờ 1-2 phút...", parse_mode="Markdown")
        ud["running"] = True
        try:
            proxies = await dao_proxy_async()
            ud["proxy_list"] = proxies
            ud["running"] = False
            fname = f"proxy_{uid}.txt"
            with open(fname, "w") as f:
                f.write("\n".join(proxies))
            await query.edit_message_text(f"✅ *Đào proxy hoàn tất!*\n━━━━━━━━━━━━━━━\n📦 Tổng: *{len(proxies)}* proxy\n💾 Đã lưu: `{fname}`", parse_mode="Markdown", reply_markup=proxy_keyboard())
        except Exception as e:
            ud["running"] = False
            await query.edit_message_text(f"❌ Lỗi đào proxy: {e}", reply_markup=proxy_keyboard())
    elif data == "proxy_check":
        proxies = ud.get("proxy_list", [])
        fname = f"proxy_{uid}.txt"
        if not proxies and os.path.exists(fname):
            with open(fname) as f:
                proxies = [l.strip() for l in f if l.strip()]
        if not proxies:
            await query.edit_message_text("⚠️ *Chưa có proxy!*\nHãy đào proxy trước.", parse_mode="Markdown", reply_markup=proxy_keyboard())
            return
        if ud["running"]:
            await query.edit_message_text("⚠️ Đang có task chạy.", reply_markup=proxy_keyboard())
            return
        ud["running"] = True
        total = min(len(proxies), 500)
        msg = await query.edit_message_text(f"⏳ *Kiểm tra proxy...*\n🔄 0/{total}", parse_mode="Markdown")
        async def progress(done, tot):
            try:
                await msg.edit_text(f"⏳ *Kiểm tra proxy...*\n🔄 {done}/{tot}", parse_mode="Markdown")
            except: pass
        alive, dead = await check_proxies_async(proxies[:500], progress)
        ud["running"] = False
        elite = sum(1 for a in alive if a['anonymity'] == 'Elite')
        anon  = sum(1 for a in alive if a['anonymity'] == 'Anonymous')
        trans = sum(1 for a in alive if a['anonymity'] == 'Transparent')
        live_fname = f"live_proxy_{uid}.txt"
        with open(live_fname, "w") as f:
            for a in alive:
                f.write(f"{a['proxy']} | {a['anonymity']} | {a['latency']}ms\n")
        await msg.edit_text(f"✅ *Kết quả kiểm tra proxy*\n━━━━━━━━━━━━━━━━━━\n📦 Đã check: {total}\n🟢 Sống: *{len(alive)}*\n  ├ 👑 Elite (sạch): {elite}\n  ├ 🔵 Anonymous: {anon}\n  └ 🔴 Transparent: {trans}\n💀 Chết: {len(dead)}\n💾 Lưu vào: `{live_fname}`", parse_mode="Markdown", reply_markup=proxy_keyboard())
    elif data == "proxy_list":
        proxies = ud.get("proxy_list", [])
        fname = f"proxy_{uid}.txt"
        if not proxies and os.path.exists(fname):
            with open(fname) as f:
                proxies = [l.strip() for l in f if l.strip()]
        if not proxies:
            await query.edit_message_text("⚠️ Chưa có proxy nào.", reply_markup=proxy_keyboard())
        else:
            sample = proxies[:10]
            text = f"📋 *Proxy đã đào: {len(proxies)}*\n━━━━━━━━━━━━━━━\n_(Hiển thị 10 đầu)_\n\n" + "\n".join(f"`{p}`" for p in sample)
            await query.edit_message_text(text, parse_mode="Markdown", reply_markup=proxy_keyboard())
    elif data == "proxy_clear":
        ud["proxy_list"] = []
        fname = f"proxy_{uid}.txt"
        if os.path.exists(fname): os.remove(fname)
        await query.edit_message_text("🗑️ Đã xóa toàn bộ proxy.", reply_markup=proxy_keyboard())
    # Nuôi FB handlers
    elif data == "nuoi_addcookie":
        ctx.user_data["waiting"] = "cookie_fb"
        await query.edit_message_text("🍪 *Thêm Cookie Facebook*\n━━━━━━━━━━━━━━━\nGửi chuỗi cookie FB vào đây.\n_(Có thể thêm nhiều lần)_\n\nGửi /cancel để hủy", parse_mode="Markdown")
    elif data == "nuoi_listcookie":
        cookies = ud["cookies_fb"]
        if not cookies:
            await query.edit_message_text("⚠️ Chưa có cookie nào.", reply_markup=nuoi_keyboard())
        else:
            lines = []
            for i, ck in enumerate(cookies, 1):
                uid_fb = ck.split('c_user=')[1].split(';')[0] if 'c_user=' in ck else '?'
                lines.append(f"{i}. 👤 UID: `{uid_fb}`")
            await query.edit_message_text(f"🍪 *Danh sách {len(cookies)} Cookie FB:*\n━━━━━━━━━━━━━━━\n" + "\n".join(lines), parse_mode="Markdown", reply_markup=nuoi_keyboard())
    elif data == "nuoi_clearcookie":
        ud["cookies_fb"] = []
        await query.edit_message_text("🗑️ Đã xóa toàn bộ cookie FB.", reply_markup=nuoi_keyboard())
    elif data == "nuoi_stop":
        if ud["task"] and not ud["task"].done():
            ud["task"].cancel()
        ud["running"] = False
        await query.edit_message_text("⏹️ *Đã dừng nuôi FB!*", parse_mode="Markdown", reply_markup=nuoi_keyboard())
    # Reg Page handlers
    elif data == "reg_stop":
        if ud["task"] and not ud["task"].done():
            ud["task"].cancel()
        ud["running"] = False
        await query.edit_message_text("⏹️ *Đã dừng Reg Page!*", parse_mode="Markdown", reply_markup=reg_keyboard())

@require_key
async def reply_keyboard_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    ud = get_user(uid)
    text = update.message.text.strip()
    logger.info(f"reply_keyboard_handler received: {text}")

    if ctx.user_data.get("waiting"):
        await message_handler(update, ctx)
        return

    if text == "🌐 Proxy":
        await update.message.reply_text("🌐 *TOOL PROXY*\n━━━━━━━━━━━━━━━\nChọn chức năng:", parse_mode="Markdown", reply_markup=proxy_keyboard())
    elif text == "🤖 Nuôi FB":
        n = len(ud["cookies_fb"])
        status = "🟢 Đang chạy" if ud["running"] else "🔴 Dừng"
        await update.message.reply_text(f"🤖 *NUÔI FACEBOOK*\n━━━━━━━━━━━━━━━\n🍪 Cookies: {n} | {status}\n\nChọn chức năng:", parse_mode="Markdown", reply_markup=nuoi_keyboard())
    elif text == "📄 Reg Page":
        n = len(ud["cookie_reg"])
        status = "🟢 Đang chạy" if ud["running"] else "🔴 Dừng"
        await update.message.reply_text(f"📄 *REG PAGE PRO5*\n━━━━━━━━━━━━━━━\n🍪 Cookies: {n} | {status}\n\nChọn chức năng:", parse_mode="Markdown", reply_markup=reg_keyboard())
    elif text == "📊 Trạng thái":
        n_cookie_fb = len(ud["cookies_fb"])
        n_cookie_reg = len(ud["cookie_reg"])
        running = "🟢 Đang chạy" if ud["running"] else "🔴 Đang nghỉ"
        n_proxy = len(ud.get("proxy_list", []))
        await update.message.reply_text(
            f"📊 *TRẠNG THÁI CỦA BẠN*\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🤖 Task: {running}\n"
            f"🍪 Cookies Nuôi FB: {n_cookie_fb} tài khoản\n"
            f"📄 Cookies Reg Page: {n_cookie_reg} tài khoản\n"
            f"🌐 Proxy đã đào: {n_proxy}",
            parse_mode="Markdown",
            reply_markup=reply_keyboard_main()
        )
    elif text == "⏹ Dừng tất cả":
        if ud["task"] and not ud["task"].done():
            ud["task"].cancel()
        ud["running"] = False
        ctx.user_data["waiting"] = ""
        await update.message.reply_text("⏹️ *Đã dừng tất cả task!*", parse_mode="Markdown", reply_markup=reply_keyboard_main())
    elif text == "🏠 Menu":
        await update.message.reply_text("╔══════════════════════╗\n║   🔥 *TLTOOL BOT* 🔥   ║\n╚══════════════════════╝\n\n⬇️ Chọn công cụ:", parse_mode="Markdown", reply_markup=main_keyboard())
    else:
        await message_handler(update, ctx)

@require_key
async def message_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    ud = get_user(uid)
    waiting = ctx.user_data.get("waiting", "")

    if not waiting:
        # Nếu không có waiting, gửi menu chính
        await update.message.reply_text("Dùng /start để mở menu.", reply_markup=main_keyboard())
        return

    text = update.message.text.strip()
    logger.info(f"message_handler waiting={waiting}, text={text[:50]}")

    if waiting == "cookie_fb":
        ctx.user_data["waiting"] = ""
        if 'c_user=' not in text:
            await update.message.reply_text("❌ Cookie không hợp lệ (thiếu c_user=). Vui lòng gửi lại cookie đầy đủ.", reply_markup=nuoi_keyboard())
            return
        await update.message.reply_text("🔄 Đang kiểm tra cookie, vui lòng chờ...")
        try:
            # Chạy trong thread để tránh block
            fb = await asyncio.to_thread(Facebook, text)
            info = await asyncio.to_thread(fb.info)
            if isinstance(info, dict) and info.get('success') == 200:
                ud["cookies_fb"].append(text)
                await update.message.reply_text(
                    f"✅ Cookie hợp lệ!\n👤 {info['name']} | ID: {info['id']}\nTổng cookies: {len(ud['cookies_fb'])}",
                    reply_markup=nuoi_keyboard()
                )
            else:
                await update.message.reply_text(f"❌ Cookie lỗi: {info}\nHãy kiểm tra lại cookie (có thể đã hết hạn).", reply_markup=nuoi_keyboard())
        except Exception as e:
            logger.error(f"Error checking cookie: {e}")
            await update.message.reply_text(f"❌ Lỗi khi kiểm tra cookie: {str(e)[:100]}", reply_markup=nuoi_keyboard())
    else:
        # Các waiting khác không dùng trong bot này (chỉ có cookie_fb)
        ctx.user_data["waiting"] = ""
        await update.message.reply_text("Hết thời gian chờ. Vui lòng bắt đầu lại.", reply_markup=main_keyboard())

# ===================== MAIN =====================
def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("cancel", cancel))
    app.add_handler(CommandHandler("getkey", cmd_getkey))
    app.add_handler(CommandHandler("active", cmd_active))
    app.add_handler(CommandHandler("mykey", cmd_mykey))
    
    # Conversation handlers
    app.add_handler(reg_conv_handler)
    app.add_handler(nuoi_conv_handler)
    
    # Callback handler chung
    app.add_handler(CallbackQueryHandler(button_handler))

    REPLY_BTNS = ["🌐 Proxy", "🤖 Nuôi FB", "📄 Reg Page", "📊 Trạng thái", "⏹ Dừng tất cả", "🏠 Menu"]
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.Regex(f"^({'|'.join(REPLY_BTNS)})$"),
        reply_keyboard_handler
    ))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))

    print("🤖 TLTOOL Bot đang chạy (đã sửa lỗi nuôi FB và bàn phím).")
    print("- Các nút dưới thanh tin nhắn: Proxy, Nuôi FB, Reg Page, Trạng thái, Dừng tất cả, Menu")
    print("- Nuôi FB: thêm cookie, xem, xóa, bắt đầu với cấu hình nút bấm")
    print("- Reg Page: bắt đầu, nhập cookie (mỗi dòng 1, kết thúc /done), cấu hình delay, số page")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()