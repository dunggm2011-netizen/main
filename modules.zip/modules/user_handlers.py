"""user_handlers.py — Key, nạp tiền, bảng xếp hạng, giới thiệu, nội quy"""
import asyncio, io, urllib.request, os, json, random, base64, time, requests
from datetime import datetime
from telegram import (Update, InlineKeyboardButton, InlineKeyboardMarkup,
                       ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove)
from telegram.ext import ContextTypes
from . import system_db as db
from .system_db import now_ts, ts_to_str, VIP_PRICES

# ── TLTool Key helpers (vượt link lấy key free) ──────
_TLTOOL_STORE = "data/system/tltool_keys.dat"
_LINK4M_TOKEN = "68ee52a27332c023c82d3fa6"

def _tl_load():
    if not os.path.exists(_TLTOOL_STORE): return {}
    try:
        with open(_TLTOOL_STORE,"rb") as f:
            return json.loads(base64.b64decode(f.read()).decode())
    except: return {}

def _tl_save(data):
    os.makedirs(os.path.dirname(_TLTOOL_STORE), exist_ok=True)
    with open(_TLTOOL_STORE,"wb") as f:
        f.write(base64.b64encode(json.dumps(data).encode()))

def _tl_ud(store, uid):
    k = str(uid)
    if k not in store: store[k] = {"keys":{}, "active_key":None}
    return store[k]

def _tl_rand(n=4):
    return "".join(random.choices("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", k=n))

def _tl_create_key(h):
    p = "24" if h == 24 else "12"
    return "TL-{}-{}-{}-{}".format(p, _tl_rand(), _tl_rand(), _tl_rand())

def _tl_make_link(key):
    return "https://tl-key.neocities.org/api_key/?key={}".format(key)

def _tl_shorten(url):
    try:
        r = requests.get(
            "https://link4m.co/api-shorten/v2?api={}&url={}".format(_LINK4M_TOKEN, url),
            timeout=10)
        r.raise_for_status()
        return r.json().get("shortenedUrl")
    except: return None

def _tl_build_link(key, double=True):
    s1 = _tl_shorten(_tl_make_link(key))
    if not s1: return _tl_make_link(key)
    if double:
        s2 = _tl_shorten(_tl_make_link(s1))
        return s2 or s1
    return s1

def _tl_add_key(uid, key, h):
    store = _tl_load(); ud = _tl_ud(store, str(uid))
    ud["keys"][key] = {"created": time.time(), "expiry_hours": h}
    if len(ud["keys"]) > 20:
        oldest = min(ud["keys"].items(), key=lambda x: x[1]["created"])
        del ud["keys"][oldest[0]]
    _tl_save(store)

def _tl_check_key(uid, key):
    store = _tl_load(); ud = _tl_ud(store, str(uid))
    if key not in ud["keys"]: return False, 0, 0
    info = ud["keys"][key]
    elapsed = time.time() - info["created"]
    expiry_sec = info["expiry_hours"] * 3600
    if elapsed <= expiry_sec:
        return True, info["expiry_hours"], (expiry_sec - elapsed) / 3600
    return False, info["expiry_hours"], 0

def _tl_activate(uid, key, h):
    """Kích hoạt key tltool → cộng giờ free vào system_db"""
    store = _tl_load(); ud = _tl_ud(store, str(uid))
    ud["active_key"] = key
    _tl_save(store)
    # Cộng giờ vào system_db free key
    db.activate_free_key(int(uid), hours=h)

MAIN_ADMINS = []  # inject từ main.py
DIST_ADMINS_NAMES = []  # ["@admin1","@admin2"] inject từ main.py

# States
ST_ENTER_VIP_KEY  = "usr_enter_vip"
ST_REF_CODE       = "usr_ref_code"
ST_DEP_AMOUNT     = "usr_dep_amount"
ST_DEP_IMG        = "usr_dep_img"
ST_CANCEL_REASON  = "usr_cancel_rsn"
ST_CANCEL_IMG     = "usr_cancel_img"
# Tltool key free states
ST_FREE_WAITING_KEY = "usr_free_waiting_key"   # Chờ nhập key sau vượt link

# ── ReplyKeyboard bám dưới ô tin nhắn ────────────────
def _nokey_kb():
    """User chưa có key — 4 nút bám dưới ô chat"""
    return ReplyKeyboardMarkup(
        [
            [KeyboardButton("🔑 Nhập Key VIP"),  KeyboardButton("🔌 Dùng API Key")],
            [KeyboardButton("🔗 Lấy Key Free"),  KeyboardButton("💰 Giá Key")],
        ],
        resize_keyboard=True,
    )

def _haskey_kb(uid):
    """User đã có key — menu đầy đủ bám dưới ô chat"""
    from . import admin_handlers as adm
    rows = [
        [KeyboardButton("💸 BUMX"),       KeyboardButton("🔄 TDS")],
        [KeyboardButton("🤝 TTC"),        KeyboardButton("⚡ PRO5")],
        [KeyboardButton("🎮 XWorld"),     KeyboardButton("📊 Trạng thái")],
        [KeyboardButton("🚀 Đồng Bộ"),   KeyboardButton("❓ Help")],
        [KeyboardButton("🏆 Bảng xếp hạng"), KeyboardButton("👛 Tài khoản")],
        [KeyboardButton("💳 Nạp tiền"),   KeyboardButton("🔗 Giới thiệu")],
    ]
    if adm._is_any_admin(uid):
        rows.append([KeyboardButton("🛠 Admin Panel"), KeyboardButton("🏅 Bảng xếp hạng")])
    return ReplyKeyboardMarkup(rows, resize_keyboard=True)

# ── Check access và gửi màn hình phù hợp ──────────────
async def show_home(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    name = update.effective_user.first_name or "bạn"
    access = db.check_access(uid, MAIN_ADMINS)
    u = db.get_user(uid)

    if not access["ok"]:
        text = (
            f"👋 Xin chào <b>{name}</b>!\n"
            f"🆔 ID: <code>{uid}</code>\n"
            f"🔑 API Key: <code>{u['api_key']}</code>\n\n"
            f"⚠️ Bạn chưa có key để sử dụng bot.\n"
            f"Chọn cách truy cập bên dưới:"
        )
        kb = _nokey_kb()
    else:
        reason_map = {
            "admin": "👑 Admin",
            "vip": f"👑 VIP — hết hạn: {access.get('expire_str','')}",
            "free": f"🎁 Free — hết hạn: {access.get('expire_str','')}",
            "api_key": f"🔑 API Key — số dư: {access.get('balance',0)}k",
        }
        reason_str = reason_map.get(access["reason"], "✅ Có quyền")
        text = (
            f"👋 Xin chào <b>{name}</b>!\n"
            f"🆔 ID: <code>{uid}</code>\n"
            f"🔑 API Key: <code>{u['api_key']}</code>\n"
            f"📌 Trạng thái: {reason_str}\n"
            f"💰 Số dư: <b>{u.get('balance',0)}k</b>\n\n"
            f"Chọn bot từ menu bên dưới 👇"
        )
        kb = _haskey_kb(uid)

    # Luôn gửi tin nhắn mới (reply keyboard cần reply_text, không dùng edit)
    if update.message:
        await update.message.reply_text(text, reply_markup=kb, parse_mode="HTML")
    elif update.callback_query:
        await update.callback_query.message.reply_text(text, reply_markup=kb, parse_mode="HTML")

async def handle_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    query = update.callback_query
    data = query.data
    if not data.startswith("usr_") and data != "adm_panel": return False
    await query.answer()
    uid = query.from_user.id
    u = db.get_user(uid)

    if data == "adm_panel":
        from . import admin_handlers as adm
        await adm.show_admin_panel(update, ctx)
        return True

    if data == "usr_enter_key":
        ctx.user_data["usr_state"] = ST_ENTER_VIP_KEY
        await query.message.reply_text(
            f"🔑 <b>Nhập Key VIP</b>\n\n"
            f"Liên hệ admin phân phối key:\n"
            + "\n".join(f"• {a}" for a in DIST_ADMINS_NAMES) +
            f"\n\n📋 Giá key:\n• 1 ngày: <b>1k</b>\n• 1 tháng: <b>25k</b>\n• 1 năm: <b>250k</b>\n\n"
            f"Nhập key của bạn:\n(Gõ /huy để huỷ)", parse_mode="HTML",
            reply_markup=ReplyKeyboardRemove())
        return True

    if data == "usr_use_api":
        await query.message.reply_text(
            f"🔌 <b>Dùng API Key</b>\n\n"
            f"🔑 API Key của bạn: <code>{u['api_key']}</code>\n"
            f"💰 Số dư: <b>{u.get('balance',0)}k</b>\n\n"
            f"📌 Cơ chế trừ phí:\n"
            f"• BUMX: kiếm 10k → trừ 1k\n"
            f"• TDS/TTC: kiếm 1.000.000 xu → trừ 1k\n"
            f"• XWorld: mỗi lượt đặt → trừ 0.01k\n\n"
            f"💳 Nạp tiền để dùng API Key →",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💳 Nạp tiền ngay", callback_data="usr_deposit")],
                [InlineKeyboardButton("🔙 Quay lại",     callback_data="usr_back")],
            ]), parse_mode="HTML")
        return True

    if data == "usr_free_key":
        # Hiển thị menu chọn loại key free (24h / 12h)
        await query.message.reply_text(
            "🔗 <b>LẤY KEY FREE</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "Chọn loại key muốn lấy:\n\n"
            "🔑 <b>Key 24h</b> — vượt 2 link\n"
            "🔑 <b>Key 12h</b> — vượt 1 link\n\n"
            "Sau khi vượt link xong → nhập key vào đây.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔑 Lấy Key 24h (2 link)", callback_data="usr_free_make_24")],
                [InlineKeyboardButton("🔑 Lấy Key 12h (1 link)", callback_data="usr_free_make_12")],
                [InlineKeyboardButton("🔙 Quay lại",             callback_data="usr_back")],
            ]), parse_mode="HTML")
        return True

    if data in ("usr_free_make_24", "usr_free_make_12"):
        h = 24 if data == "usr_free_make_24" else 12
        try:
            await query.message.reply_text(f"⏳ Đang tạo link...")
        except Forbidden:
            return  # User đã block bot
        key  = _tl_create_key(h)
        link = _tl_build_link(key, double=(h == 24))
        _tl_add_key(uid, key, h)
        exp  = datetime.fromtimestamp(time.time() + h * 3600)
        layers = "2 lớp" if h == 24 else "1 lớp"
        ctx.user_data["usr_state"]    = ST_FREE_WAITING_KEY
        ctx.user_data["usr_free_key_val"] = key
        ctx.user_data["usr_free_hours"]   = h
        await query.message.reply_text(
            f"✅ <b>Link đã tạo!</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n\n"
            f"📋 <b>Hướng dẫn:</b>\n"
            f"1. Mở link bên dưới\n"
            f"2. Vượt link 4M <b>{layers}</b>\n"
            f"3. Nhận key → dán vào đây\n\n"
            f"🔗 <a href='{link}'>Mở link kích hoạt</a>\n\n"
            f"⏰ Key hết hạn: <b>{exp.strftime('%H:%M %d/%m/%Y')}</b>\n\n"
            f"<i>Sau khi vượt xong, gửi key vào đây.\nGõ /huy để huỷ.</i>",
            parse_mode="HTML",
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📋 Copy link", url=link)],
                [InlineKeyboardButton("🔙 Quay lại", callback_data="usr_free_key")],
            ]))
        return True

    if data == "usr_key_price":
        await query.message.reply_text(
            "💰 <b>BẢNG GIÁ KEY VIP</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🗓 1 ngày:  <b>1.000đ (1k)</b>\n"
            "📅 1 tháng: <b>25.000đ (25k)</b>\n"
            "📆 1 năm:   <b>250.000đ (250k)</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "🔌 API Key: Trả 10% thu nhập\n"
            "🎁 Key Free: 4 giờ miễn phí\n\n"
            "Liên hệ mua key:\n" +
            "\n".join(f"• {a}" for a in DIST_ADMINS_NAMES),
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💳 Nạp tiền", callback_data="usr_deposit")],
                [InlineKeyboardButton("🔙 Quay lại", callback_data="usr_back")],
            ]), parse_mode="HTML")
        return True

    if data == "usr_account":
        vip_status = ts_to_str(u["vip_expire"]) if u.get("vip_expire",0) > now_ts() else "Không có"
        free_status = ts_to_str(u["free_expire"]) if u.get("free_expire",0) > now_ts() else "Hết hạn"
        await query.message.reply_text(
            f"👛 <b>TÀI KHOẢN CỦA BẠN</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🆔 ID: <code>{uid}</code>\n"
            f"🔑 API Key: <code>{u['api_key']}</code>\n"
            f"💰 Số dư: <b>{u.get('balance',0)}k</b>\n"
            f"👑 VIP hết hạn: <b>{vip_status}</b>\n"
            f"🎁 Free hết hạn: <b>{free_status}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"📈 Tổng BUMX: <b>{u.get('total_earned_bumx',0):,}₫</b>\n"
            f"🔄 Tổng TDS: <b>{u.get('total_earned_tds',0):,} xu</b>\n"
            f"🤝 Tổng TTC: <b>{u.get('total_earned_ttc',0):,} xu</b>\n"
            f"🎮 XWorld: USDT {u.get('total_earned_xworld',{}).get('USDT',0):.4f} | BUILD {u.get('total_earned_xworld',{}).get('BUILD',0):.0f}",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💳 Nạp tiền", callback_data="usr_deposit")],
                [InlineKeyboardButton("🔙 Quay lại", callback_data="usr_back")],
            ]), parse_mode="HTML")
        return True

    if data == "usr_deposit":
        access = db.check_access(uid, MAIN_ADMINS)
        if not access["ok"]:
            await query.message.reply_text(
                "⚠️ Bạn cần có key để nạp tiền!\nVui lòng kích hoạt key trước.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="usr_back")]]))
            return True
        ctx.user_data["usr_state"] = ST_DEP_AMOUNT
        bank = db.get_bank()
        await query.message.reply_text(
            f"💳 <b>NẠP TIỀN VÀO TÀI KHOẢN</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🏦 Ngân hàng: <b>{bank['bank_name']}</b>\n"
            f"💳 Số TK: <code>{bank['account_no']}</code>\n"
            f"👤 Chủ TK: <b>{bank['account_name']}</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"⏰ Admin duyệt trong 1-24h\n\n"
            f"Nhập số tiền muốn nạp (đơn vị: k, VD: 50 = 50.000đ):\n(Gõ /huy để huỷ)",
            parse_mode="HTML")
        return True

    if data == "usr_referral":
        u = db.get_user(uid)
        ref_code = u.get("ref_code", f"REF{uid}")
        ref_link = f"https://t.me/your_bot?start={ref_code}"
        await query.message.reply_text(
            f"🔗 <b>GIỚI THIỆU BẠN BÈ</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"📎 Link của bạn:\n<code>{ref_link}</code>\n\n"
            f"💰 Khi bạn bè nạp tiền, bạn nhận <b>10%</b> hoa hồng!\n"
            f"Ví dụ: Bạn bè nạp 100k → Bạn nhận 10k\n\n"
            f"📋 <b>Nội quy giới thiệu:</b>\n"
            f"• Hoa hồng cộng ngay khi admin duyệt\n"
            f"• Không giới thiệu tài khoản ảo\n"
            f"• Vi phạm sẽ bị khóa tài khoản",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="usr_back")]]),
            parse_mode="HTML")
        return True

    if data == "usr_ranking":
        await show_ranking_menu(query)
        return True

    if data.startswith("usr_rank_"):
        parts = data.replace("usr_rank_", "").split("_")
        tool = parts[0]; coin = parts[1] if len(parts) > 1 else "xu"
        await show_ranking(query, tool, coin)
        return True

    if data == "usr_noquy":
        await show_rules(query)
        return True

    if data == "usr_back":
        await show_home(update, ctx)
        return True

    return False

async def show_ranking_menu(query):
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("💸 BUMX",         callback_data="usr_rank_bumx_VND"),
         InlineKeyboardButton("🔄 TDS",           callback_data="usr_rank_tds_xu")],
        [InlineKeyboardButton("🤝 TTC",           callback_data="usr_rank_ttc_xu")],
        [InlineKeyboardButton("🎮 XWorld USDT",   callback_data="usr_rank_xworld_USDT"),
         InlineKeyboardButton("🎮 BUILD",         callback_data="usr_rank_xworld_BUILD")],
        [InlineKeyboardButton("🎮 WORLD",         callback_data="usr_rank_xworld_WORLD")],
        [InlineKeyboardButton("📋 Nội quy đua top", callback_data="usr_noquy"),
         InlineKeyboardButton("🔙 Quay lại",       callback_data="usr_back")],
    ])
    await query.edit_message_text(
        "🏆 <b>BẢNG XẾP HẠNG</b>\nChọn bảng xếp hạng:",
        reply_markup=kb, parse_mode="HTML")

async def show_ranking(query, tool: str, coin: str):
    ranking = db.get_ranking(tool, coin, top_n=10)
    tool_names = {"bumx":"💸 BUMX","tds":"🔄 TDS","ttc":"🤝 TTC","xworld":f"🎮 XWorld {coin}"}
    icons = ["🥇","🥈","🥉","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"]
    bonus = {1:"(+5%)",2:"(+3%)",3:"(+2%)"}
    unit = {"VND":"₫","xu":"xu","USDT":"USDT","BUILD":"BUILD","WORLD":"WORLD"}.get(coin,"")
    lines = [f"🏆 <b>BẢNG XẾP HẠNG {tool_names.get(tool,'').upper()}</b>\n"]
    if not ranking:
        lines.append("Chưa có dữ liệu đủ điều kiện.")
    for i, row in enumerate(ranking):
        icon = icons[i] if i < len(icons) else f"{i+1}."
        bon = bonus.get(i+1,"")
        val = f"{row['val']:,.0f}" if coin != "USDT" else f"{row['val']:.4f}"
        lines.append(f"{icon} <code>{row['uid']}</code> — <b>{val} {unit}</b> {bon}")
    lines.append(f"\n💡 Top 3 nhận thưởng cuối kỳ!")
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="usr_ranking")]])
    await query.edit_message_text("\n".join(lines), reply_markup=kb, parse_mode="HTML")

async def show_rules(query):
    text = (
        "📋 <b>NỘI QUY & LƯU Ý</b>\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        "💳 <b>NẠP TIỀN:</b>\n"
        "• Nội dung CK: <i>chucmaymansongdai [ID]</i>\n"
        "• Gửi ảnh CK sau khi chuyển\n"
        "• Admin duyệt trong 1-24h\n"
        "• Tối thiểu nạp: 1k\n\n"
        "🔗 <b>GIỚI THIỆU BẠN BÈ:</b>\n"
        "• Nhận 10% mỗi lần bạn bè nạp\n"
        "• Không dùng acc ảo\n"
        "• Vi phạm bị khóa vĩnh viễn\n\n"
        "🏆 <b>ĐUA TOP CÀY:</b>\n"
        "• BUMX: Tối thiểu 100.000₫\n"
        "• TDS/TTC: Tối thiểu 100,000,000,000 xu\n"
        "• XWorld USDT: Tối thiểu 50 USDT\n"
        "• XWorld BUILD: Tối thiểu 100.000 BUILD\n"
        "• XWorld WORLD: Tối thiểu 100 WORLD\n"
        "• Top 1: +5% | Top 2: +3% | Top 3: +2%\n\n"
        "🔑 <b>API KEY:</b>\n"
        "• BUMX: kiếm 10k → trừ 1k (10%)\n"
        "• TDS/TTC: kiếm 1.000.000 xu → trừ 1k\n"
        "• XWorld: mỗi lượt đặt → trừ 0.01k\n"
        "• Hết tiền: bot tự dừng\n\n"
        "🗝 <b>KEY VIP:</b>\n"
        "• 1 ngày: 1k | 1 tháng: 25k | 1 năm: 250k\n"
        "• Hết hạn: bot tự dừng\n"
        "• Key free: 4 giờ/lần"
    )
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại", callback_data="usr_ranking")]])
    await query.edit_message_text(text, reply_markup=kb, parse_mode="HTML")

async def _check_api_balance_and_notify(uid: int, app) -> bool:
    """Kiểm tra API key còn tiền không. Nếu hết → gửi thông báo và trả về True."""
    from . import key_system as ks
    user = ks.get_user(uid)
    if user.get("api_key_active") and user.get("api_balance", 0) <= 0:
        # Tắt API key
        user["api_key_active"] = False
        ks.save_user(uid, user)
        try:
            await app.bot.send_message(
                chat_id=uid,
                text=(
                    "⚠️ <b>API Key hết tiền!</b>\n"
                    "Bot đã dừng hoạt động.\n\n"
                    "💳 Nạp tiền để tiếp tục dùng API Key,\n"
                    "hoặc chọn phương thức truy cập khác."
                ),
                parse_mode="HTML",
                reply_markup=_nokey_kb()
            )
        except Exception: pass
        return True
    return False


async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    uid = update.effective_user.id
    state = ctx.user_data.get("usr_state")
    if not state: return False
    text = update.message.text.strip() if update.message and update.message.text else ""
    photo = update.message.photo if update.message else None

    async def reply(msg, kb=None): 
        await update.message.reply_text(msg, parse_mode="HTML", reply_markup=kb)

    # Xử lý nhập key sau vượt link (tltool key free)
    if state == ST_FREE_WAITING_KEY:
        key_input = text.upper().strip()
        expected  = ctx.user_data.get("usr_free_key_val","").upper()
        h         = ctx.user_data.get("usr_free_hours", 24)

        if not key_input.startswith("TL-"):
            await reply(
                "⚠️ Key phải có dạng <code>TL-XX-XXXX-XXXX-XXXX</code>\n"
                "Vượt link xong mới có key.\nGõ /huy để huỷ.")
            return True

        valid, exp_h, rem = _tl_check_key(uid, key_input)
        if valid:
            _tl_activate(uid, key_input, exp_h)
            ctx.user_data.pop("usr_state",        None)
            ctx.user_data.pop("usr_free_key_val", None)
            ctx.user_data.pop("usr_free_hours",   None)
            u2 = db.get_user(uid)
            await reply(
                f"✅ <b>Xác thực thành công!</b>\n"
                f"🔑 Key: <code>{key_input}</code>\n"
                f"⏰ Còn lại: <b>{rem:.1f} giờ</b>\n"
                f"🕐 Hết hạn: <b>{ts_to_str(u2.get('free_expire',0))}</b>\n\n"
                f"👇 Chọn công cụ từ menu bên dưới:")
            await show_home(update, ctx)
        else:
            # Key sai hoặc không khớp
            if exp_h > 0:
                await reply(
                    f"❌ Key đã hết hạn hoặc không hợp lệ!\n"
                    f"Tạo lại link mới: nhấn 🔗 Lấy Key Free")
            else:
                await reply(
                    f"❌ Key <code>{key_input}</code> không tồn tại!\n"
                    f"Kiểm tra lại key hoặc tạo link mới.\n"
                    f"Gõ /huy để huỷ.")
        return True

    if state == ST_ENTER_VIP_KEY:
        result = db.use_vip_key(uid, text.upper())
        ctx.user_data.pop("usr_state", None)
        await reply(result["msg"])
        if result["ok"]:
            await show_home(update, ctx)
        return True

    if state == ST_DEP_AMOUNT:
        try:
            amount = float(text.replace(",",".")); assert amount >= 1
        except:
            await reply("❌ Nhập số hợp lệ (VD: 50 = 50k)!"); return True
        dep = db.create_deposit(uid, amount)
        bank = db.get_bank()
        content = dep["content"]
        # Tạo QR VietQR và gửi ảnh
        qr_url = db.get_qr_url(amount, content)
        ctx.user_data["usr_state"] = ST_DEP_IMG
        ctx.user_data["usr_dep_id"] = dep["dep_id"]
        await reply(
            f"💳 <b>THÔNG TIN CHUYỂN KHOẢN</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"🏦 NH: <b>{bank['bank_name']}</b>\n"
            f"💳 STK: <code>{bank['account_no']}</code>\n"
            f"👤 Tên: <b>{bank['account_name']}</b>\n"
            f"💰 Số tiền: <b>{amount}k ({int(amount*1000):,}₫)</b>\n"
            f"📝 Nội dung: <code>{content}</code>\n"
            f"━━━━━━━━━━━━━━━━━━━━\n"
            f"⚠️ Nhớ ghi đúng nội dung CK!\n\n"
            f"📸 Sau khi CK xong, gửi <b>ảnh xác nhận</b> vào đây.\n(Gõ /huy để huỷ)")
        # Tải và gửi ảnh QR
        try:
            import urllib.request as ur
            req = ur.Request(qr_url, headers={"User-Agent":"Mozilla/5.0"})
            img_data = ur.urlopen(req, timeout=10).read()
            from io import BytesIO
            await update.message.reply_photo(
                photo=BytesIO(img_data),
                caption=f"📱 Quét QR để chuyển {amount}k\nNội dung: {content}")
        except Exception as e:
            await reply(f"⚠️ Không tạo được QR ({e})\nChuyển khoản thủ công theo thông tin trên.")
        return True

    if state == ST_DEP_IMG:
        if photo:
            dep_id = ctx.user_data.get("usr_dep_id")
            deps = db._load(db.F_DEPOSIT, {})
            if dep_id in deps:
                deps[dep_id]["img_proof"] = "received"
                db._save(db.F_DEPOSIT, deps)
            ctx.user_data.pop("usr_state", None)
            ctx.user_data.pop("usr_dep_id", None)
            await reply(
                f"✅ <b>Đã nhận ảnh xác nhận!</b>\n"
                f"⏰ Admin sẽ duyệt trong 1-24h.\n"
                f"💰 Tiền sẽ vào tài khoản sau khi duyệt.")
        else:
            await reply("📸 Vui lòng gửi <b>ảnh chụp màn hình</b> chuyển khoản!")
        return True

    if state == ST_CANCEL_REASON:
        if not photo:
            ctx.user_data["usr_cancel_reason"] = text
            ctx.user_data["usr_state"] = ST_CANCEL_IMG
            await reply("📸 Vui lòng gửi <b>ảnh xác minh</b> cùng với lý do huỷ:")
        return True

    if state == ST_CANCEL_IMG:
        if photo:
            dep_id = ctx.user_data.pop("usr_dep_id", "")
            reason = ctx.user_data.pop("usr_cancel_reason", "Không có lý do")
            ctx.user_data.pop("usr_state", None)
            deps = db._load(db.F_DEPOSIT, {})
            if dep_id in deps:
                deps[dep_id]["status"] = "cancelled"
                deps[dep_id]["reject_reason"] = f"User huỷ: {reason}"
                db._save(db.F_DEPOSIT, deps)
                u = db.get_user(uid)
                u["pending_deposit"] = None
                db.save_user(uid, u)
            await reply("✅ Đã huỷ yêu cầu nạp tiền.")
        else:
            await reply("📸 Cần gửi ảnh xác minh!")
        return True

    return False

async def cmd_huy(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """
    Lệnh /huy — huỷ bước hiện tại và quay về đúng context:
    - Đang nhập key / lấy key free → quay về menu chọn key (chưa có key)
    - Đang cấu hình tool / nạp tiền (có key) → quay về menu chính (đã có key)
    - Đang nhập lý do huỷ nạp tiền → yêu cầu lý do + ảnh trước
    """
    uid       = update.effective_user.id
    usr_state = ctx.user_data.get("usr_state")
    adm_state = ctx.user_data.get("adm_state")

    # ── Trường hợp đặc biệt: huỷ nạp tiền đang chờ ảnh ──
    if usr_state == ST_DEP_IMG:
        dep_id = ctx.user_data.get("usr_dep_id")
        if dep_id:
            ctx.user_data["usr_state"]   = ST_CANCEL_REASON
            ctx.user_data["usr_dep_id"]  = dep_id
            await update.message.reply_text(
                "📝 Để huỷ yêu cầu nạp tiền, vui lòng nhập <b>lý do huỷ</b>:\n"
                "(Kèm ảnh xác minh sẽ được yêu cầu tiếp theo)", parse_mode="HTML")
            return

    # ── Xác định context hiện tại ──
    # Các state thuộc luồng "chưa có key"
    NO_KEY_STATES = {ST_ENTER_VIP_KEY, ST_FREE_WAITING_KEY, "usr_use_api", "usr_key_price"}
    is_nokey_flow = usr_state in NO_KEY_STATES

    # Kiểm tra user hiện có key không
    from . import system_db as _db
    access = _db.check_access(uid, MAIN_ADMINS)
    has_key = access["ok"]

    # ── Xoá tất cả states ──
    for k in ["adm_state","usr_state","bumx_state","tds_state","ttc_state",
              "module_state","adm_key_name","adm_key_uid","adm_key_days",
              "adm_bank_name","adm_bank_no","adm_dep_id","adm_bank_bin",
              "bumx_new_auth","bumx_new_cookie","bumx_tongjob","bumx_dmin",
              "bumx_dmax","bumx_amin","tds_list_nv","tds_delay",
              "tds_jobbblock","tds_delayblock","usr_dep_id",
              "usr_free_key_val","usr_free_hours",
              "usr_cancel_reason","adm_del_key_name"]:
        ctx.user_data.pop(k, None)

    await update.message.reply_text("✅ <b>Đã huỷ!</b>", parse_mode="HTML")

    # ── Quay về đúng màn hình ──
    if not has_key or is_nokey_flow:
        # Chưa có key → quay về menu chọn key
        await show_home(update, ctx)
    else:
        # Có key → quay về menu chính
        await show_home(update, ctx)

async def show_ranking_menu_msg(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Gọi từ main khi nhấn nút Bảng XH"""
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("💸 BUMX",       callback_data="usr_rank_bumx_VND"),
         InlineKeyboardButton("🔄 TDS",         callback_data="usr_rank_tds_xu")],
        [InlineKeyboardButton("🤝 TTC",         callback_data="usr_rank_ttc_xu")],
        [InlineKeyboardButton("🎮 XWorld USDT", callback_data="usr_rank_xworld_USDT"),
         InlineKeyboardButton("🎮 BUILD",       callback_data="usr_rank_xworld_BUILD")],
        [InlineKeyboardButton("🎮 WORLD",       callback_data="usr_rank_xworld_WORLD")],
        [InlineKeyboardButton("📋 Nội quy đua top", callback_data="usr_noquy"),
         InlineKeyboardButton("🔙 Quay lại",       callback_data="usr_back")],
    ])
    await update.message.reply_text(
        "🏆 <b>BẢNG XẾP HẠNG</b>\nChọn bảng xếp hạng:",
        reply_markup=kb, parse_mode="HTML")
