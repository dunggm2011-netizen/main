# modules/tds.py
"""Module TDS Facebook — traodoisub.com | Giao diện TBTOOL cao cấp (đã sửa lỗi UnboundLocalError)"""
import requests
import cloudscraper
import re
import os
import json
import base64
import uuid
import random
import threading
import asyncio
import time
from time import sleep
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from .crypto_utils import save_encrypted, load_encrypted

try:
    from .key_system import update_earnings, deduct_api_fee
except:
    update_earnings = None
    deduct_api_fee = None

BOT_TOKEN = ""

_MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
_BASE_DIR = os.path.dirname(_MODULE_DIR)
DATA_DIR = os.path.join(_BASE_DIR, "data", "tds_users")
os.makedirs(DATA_DIR, exist_ok=True)

ST_TAIKHOAN = "tds_taikhoan"
ST_ADD_TOKEN = "tds_add_token"
ST_ADD_COOKIE = "tds_add_cookie"
ST_ASSIGN_FB = "tds_assign_fb"
ST_DELAY = "tds_delay"
ST_JOBBBLOCK = "tds_jobbblock"
ST_DELAYBLOCK = "tds_delayblock"
ST_JOBTC = "tds_jobtc"
ST_PROXY = "tds_proxy"
ST_CHON_NV = "tds_chon_nv"
ST_MAX_FAIL = "tds_maxfail"
MAX_TDS_TOKENS = 10

user_sessions = {}
sessions_lock = threading.Lock()


def user_file(uid):
    return os.path.join(DATA_DIR, f"user_{uid}.json")


def load_user_data(uid):
    path = user_file(uid)
    data = load_encrypted(path, {
        "tokens": [],
        "fb_cookies": [],
        "accounts": [],
        "settings": {},
        "proxies": []
    })
    if data.get("accounts") and not data.get("tokens"):
        for a in data["accounts"]:
            t = a.get("token", "")
            ck = a.get("cookie", "")
            if t and not any(x["token"] == t for x in data["tokens"]):
                data["tokens"].append({
                    "token": t,
                    "name": a.get("name_tds", ""),
                    "enabled": a.get("enabled", True),
                    "idx": len(data["tokens"])
                })
            if ck and not any(x["cookie"] == ck for x in data["fb_cookies"]):
                data["fb_cookies"].append({
                    "cookie": ck,
                    "name_fb": a.get("name_fb", ""),
                    "fb_uid": "",
                    "token_idx": 0,
                    "enabled": True,
                })
    return data


def save_user_data(uid, sess):
    save_encrypted(user_file(uid), {
        "tokens": sess.get("tokens", []),
        "fb_cookies": sess.get("fb_cookies", []),
        "accounts": sess.get("accounts", []),
        "settings": sess.get("settings", {}),
        "proxies": sess.get("proxies", []),
    })


def get_session(uid):
    with sessions_lock:
        if uid not in user_sessions:
            saved = load_user_data(uid)
            user_sessions[uid] = {
                "tokens": saved.get("tokens", []),
                "fb_cookies": saved.get("fb_cookies", []),
                "accounts": saved.get("accounts", []),
                "settings": saved.get("settings", {}),
                "proxies": saved.get("proxies", []),
                "running": False,
                "thread": None,
                "stop_event": threading.Event(),
                "logs": [],
                "temp": {}
            }
        return user_sessions[uid]


def get_active_accounts(uid):
    sess = get_session(uid)
    return [a for a in sess["accounts"] if a.get("enabled", True)]


def add_log(sess, msg):
    sess["logs"].append(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")
    sess["logs"] = sess["logs"][-60:]


def parse_proxy(s):
    s = s.strip()
    if not s:
        return None
    if not s.startswith(("http", "socks")):
        parts = s.split(":")
        if len(parts) == 4:
            host, port, user, pw = parts
            s = f"http://{user}:{pw}@{host}:{port}"
        elif len(parts) == 2:
            s = f"http://{s}"
        else:
            return None
    return {"http": s, "https": s}


def get_proxy_for_account(sess, index):
    proxies = sess.get("proxies", [])
    if not proxies:
        return None
    return parse_proxy(proxies[index % len(proxies)])


def encode_to_base64(_data):
    return base64.b64encode(_data.encode("utf-8")).decode("utf-8")


class Facebook:
    def __init__(self, cookie, proxy=None):
        try:
            self.fb_dtsg = ""
            self.jazoest = ""
            self.cookie = cookie
            self.session = requests.Session()
            if proxy:
                self.session.proxies.update(proxy)
            self.id = self.cookie.split("c_user=")[1].split(";")[0]
            self.headers = {
                "authority": "www.facebook.com",
                "accept": "text/html,application/xhtml+xml",
                "accept-language": "vi",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Cookie": self.cookie
            }
            url = self.session.get(f"https://www.facebook.com/{self.id}", headers=self.headers).url
            response = self.session.get(url, headers=self.headers).text
            matches = re.findall(r'\["DTSGInitialData",\[\],\{"token":"(.*?)"\}', response)
            if matches:
                self.fb_dtsg += matches[0]
                self.jazoest += re.findall(r'jazoest=(.*?)\"', response)[0]
        except:
            pass

    def info(self):
        try:
            get = self.session.get("https://www.facebook.com/me", headers=self.headers).url
            url = "https://www.facebook.com/" + get.split("%2F")[-2] + "/" if "next=" in get else get
            resp = self.session.get(url, headers=self.headers, params={"locale": "vi_VN"})
            parsed = json.loads("{" + resp.text.split('"CurrentUserInitialData",[],{')[1].split("},")[0] + "}")
            id_ = parsed.get("USER_ID", "0")
            name = parsed.get("NAME", "")
            if id_ == "0" and name == "":
                return "cookieout"
            elif "828281030927956" in resp.text:
                return "956"
            elif "1501092823525282" in resp.text:
                return "282"
            elif "601051028565049" in resp.text:
                return "spam"
            return {"status": "success", "id": parsed.get("USER_ID"), "name": parsed.get("NAME")}
        except:
            pass

    def camxuc(self, id, type):
        try:
            reac = {
                "LIKE": "1635855486666999",
                "LOVE": "1678524932434102",
                "CARE": "613557422527858",
                "HAHA": "115940658764963",
                "WOW": "478547315650144",
                "SAD": "908563459236466",
                "ANGRY": "444813342392137"
            }
            data = {
                "av": self.id,
                "fb_dtsg": self.fb_dtsg,
                "jazoest": self.jazoest,
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "CometUFIFeedbackReactMutation",
                "variables": f'{{"input":{{"attribution_id_v2":"CometHomeRoot.react,comet.home,tap_tabbar,1719027162723,322693,4748854339,,","feedback_id":"{encode_to_base64("feedback:"+str(id))}","feedback_reaction_id":"{reac.get(type)}","feedback_source":"NEWS_FEED","is_tracking_encrypted":true,"tracking":[],"session_id":"{uuid.uuid4()}","actor_id":"{self.id}","client_mutation_id":"3"}},"useDefaultActor":false,"__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider":false}}',
                "server_timestamps": "true",
                "doc_id": "7047198228715224"
            }
            self.session.post("https://www.facebook.com/api/graphql/", headers=self.headers, data=data)
        except:
            pass

    def camxuccmt(self, id, type):
        try:
            reac = {
                "LIKE": "1635855486666999",
                "LOVE": "1678524932434102",
                "CARE": "613557422527858",
                "HAHA": "115940658764963",
                "WOW": "478547315650144",
                "SAD": "908563459236466",
                "ANGRY": "444813342392137"
            }
            data = {
                "av": self.id,
                "fb_dtsg": self.fb_dtsg,
                "jazoest": self.jazoest,
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "CometUFIFeedbackReactMutation",
                "variables": '{"input":{"feedback_id":"' + encode_to_base64("feedback:" + str(id)) + '","feedback_reaction_id":"' + reac.get(type) + '","feedback_source":"TAHOE","is_tracking_encrypted":true,"tracking":[],"session_id":"' + str(uuid.uuid4()) + '","actor_id":"' + self.id + '","client_mutation_id":"1"},"useDefaultActor":false,"__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider":false}',
                "server_timestamps": "true",
                "doc_id": "7616998081714004"
            }
            self.session.post("https://www.facebook.com/api/graphql/", headers=self.headers, data=data)
        except:
            pass

    def likepage(self, id):
        try:
            data = {
                "av": self.id,
                "fb_dtsg": self.fb_dtsg,
                "jazoest": self.jazoest,
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "CometProfilePlusLikeMutation",
                "variables": '{"input":{"is_tracking_encrypted":false,"page_id":"' + str(id) + '","source":null,"tracking":null,"actor_id":"' + str(self.id) + '","client_mutation_id":"1"},"scale":1}',
                "server_timestamps": "true",
                "doc_id": "6716077648448761"
            }
            self.session.post("https://www.facebook.com/api/graphql/", data=data, headers=self.headers)
        except:
            pass

    def follow(self, id):
        try:
            data = {
                "av": self.id,
                "fb_dtsg": self.fb_dtsg,
                "jazoest": self.jazoest,
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "CometUserFollowMutation",
                "variables": '{"input":{"subscribe_location":"PROFILE","subscribee_id":"' + str(id) + '","tracking":null,"actor_id":"' + str(self.id) + '","client_mutation_id":"5"},"scale":1}',
                "server_timestamps": "true",
                "doc_id": "25581663504782089"
            }
            self.session.post("https://www.facebook.com/api/graphql/", data=data, headers=self.headers)
        except:
            pass

    def share(self, id):
        try:
            data = {
                "av": self.id,
                "fb_dtsg": self.fb_dtsg,
                "jazoest": self.jazoest,
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "ComposerStoryCreateMutation",
                "variables": '{"input":{"composer_entry_point":"share_modal","idempotence_token":"' + str(uuid.uuid4()) + '_FEED","source":"WWW","attachments":[{"link":{"share_scrape_data":"{\\"share_type\\":22,\\"share_params\\":[' + id + ']}"}}],"audience":{"privacy":{"allow":[],"base_state":"EVERYONE","deny":[]}},"actor_id":"' + self.id + '","client_mutation_id":"3"},"feedLocation":"NEWSFEED","feedbackSource":1,"scale":1,"useDefaultActor":false,"isFeed":true}',
                "server_timestamps": "true",
                "doc_id": "8167261726632010"
            }
            self.session.post("https://www.facebook.com/api/graphql/", headers=self.headers, data=data)
        except:
            pass


class TDS_Facebook:
    def __init__(self, token, proxy=None):
        self.session = cloudscraper.create_scraper()
        if proxy:
            self.session.proxies.update(proxy)
        self.token = token

    def info(self):
        try:
            resp = self.session.get(
                f"https://traodoisub.com/api/?fields=profile&access_token={self.token}",
                timeout=15
            ).json()
            if resp.get("success") == 200:
                self.name = resp["data"]["user"]
                self.coin = resp["data"]["xu"]
                return {"status": "success", "name": self.name, "xu": self.coin}
            return {"status": "error", "msg": str(resp.get("error", "Token lỗi"))}
        except Exception as e:
            return {"status": "error", "msg": str(e)}

    def cauhinh(self, id):
        return self.session.get(
            f"https://traodoisub.com/api/?fields=run&id={id}&access_token={self.token}"
        ).json()

    def laynhiemvu(self, type):
        return self.session.get(
            f"https://traodoisub.com/api/?fields={type}&access_token={self.token}&type=ALL"
        )

    def nhantien(self, type, id):
        try:
            return self.session.get(
                f"https://traodoisub.com/api/coin/?type={type}&id={id}&access_token={self.token}",
                timeout=15
            ).json()
        except Exception:
            return {"error": "request_failed"}


def worker(uid, send_fn):
    sess = get_session(uid)
    _local_stop = sess["stop_event"]
    stop_event = _local_stop
    settings = sess["settings"]
    list_nv = settings.get("nhiemvu", [])
    if not list_nv:
        list_nv = ["1", "2", "3"]

    tokens = [t for t in sess.get("tokens", []) if t.get("enabled", True)]
    fb_cks = [f for f in sess.get("fb_cookies", []) if f.get("enabled", True)]

    list_ck = []
    for fb in fb_cks:
        tidx = fb.get("token_idx", 0)
        name_fb = fb.get("name_fb", "") or fb.get("name", "?")
        try:
            name_fb = name_fb.encode('utf-8').decode('utf-8')
        except:
            pass
        if tidx < len(tokens):
            tok = tokens[tidx]
            list_ck.append({
                "token": tok["token"],
                "cookie": fb["cookie"],
                "name_fb": name_fb,
                "name_tds": tok.get("name", "?"),
            })

    if not list_ck:
        old_accs = [a for a in sess.get("accounts", []) if a.get("enabled", True)]
        for a in old_accs:
            list_ck.append({
                "token": a.get("token", ""),
                "cookie": a.get("cookie", ""),
                "name_fb": a.get("name_fb", "?"),
                "name_tds": a.get("label", "?"),
            })

    if not list_ck:
        try:
            send_fn(uid, "⚠️ Chưa có tài khoản bật!\n👉 Vào 👥 Quản lý luồng để bật acc.")
        except:
            pass
        sess["running"] = False
        return

    fields_map = {
        "1": "facebook_reaction",
        "2": "facebook_reaction2",
        "3": "facebook_reactioncmt",
        "4": "facebook_share",
        "5": "facebook_follow",
        "6": "facebook_page"
    }

    def notify(msg):
        add_log(sess, msg)
        try:
            # CHỈ SỬA Ở ĐÂY: Thêm header TBTOOL + icon
            final_msg = f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n{msg}"
            send_fn(uid, final_msg)
        except:
            pass

    def isleep(sec):
        end = time.time() + sec
        while time.time() < end:
            if stop_event.is_set():
                return
            time.sleep(min(0.5, end - time.time()))

    luong_idx = 0
    while not stop_event.is_set():
        if not list_ck:
            notify("📦 Hết tài khoản trong danh sách!")
            break
        if luong_idx >= len(list_ck):
            luong_idx = 0
        if luong_idx >= len(list_ck):
            break

        pair = list_ck[luong_idx]
        token = pair["token"]
        cookie = pair["cookie"]
        luong = luong_idx + 1
        proxy = get_proxy_for_account(sess, luong_idx)

        tds = TDS_Facebook(token, proxy)
        info_tds = tds.info()
        if info_tds.get("status") != "success":
            notify(f"❌ Token lỗi ({info_tds.get('msg','?')})\n👉 Đã bỏ qua luồng #{luong}")
            list_ck.pop(luong_idx)
            continue

        name_tds = info_tds.get("name", "") or "?"
        xu_tds = info_tds.get("xu", 0)
        try:
            xu_fmt = "{:,}".format(int(str(xu_tds).replace(",", "")))
        except:
            xu_fmt = str(xu_tds)
        notify(f"🚀 Luồng #{luong} đã bắt đầu\n━━━━━━━━━━━━━━━━━━━━\n👤 TDS: <b>{name_tds}</b>\n💰 Số dư: <b>{xu_fmt}</b> xu")

        fb = Facebook(cookie, proxy)
        info_fb = fb.info()
        if not info_fb or not isinstance(info_fb, dict) or info_fb.get("status") != "success":
            err_type = str(info_fb) if info_fb else "lỗi kết nối"
            is_block = any(k in str(err_type) for k in ["checkpoint", "block", "spam", "cookieout", "956", "282"])
            if is_block:
                try:
                    _fbs = sess.get("fb_cookies", [])
                    _fbs = [x for x in _fbs if x.get("cookie", "") != cookie]
                    sess["fb_cookies"] = _fbs
                    save_user_data(uid, sess)
                except:
                    pass
                notify(f"🚫 Cookie FB bị block/checkpoint\n👉 Đã xóa khỏi danh sách")
            else:
                notify(f"⚠️ Cookie FB lỗi ({err_type[:30]})\n👉 Bỏ qua luồng #{luong}")
            list_ck.pop(luong_idx)
            continue

        id_fb = info_fb["id"]
        name_fb = (info_fb.get("name", "?") or "?").encode().decode("unicode_escape", errors="replace") if "\\u" in repr(info_fb.get("name", "")) else info_fb.get("name", "?")
        notify(f"👤 Kết nối thành công\n━━━━━━━━━━━━━━━━━━━━\nFB: <b>{name_fb}</b> (ID: {id_fb})\nTDS: <b>{name_tds}</b>")
        tds.cauhinh(id_fb)
        isleep(luong * 3)
        stt = 0
        totalxu = 0
        job_success_count = 0
        JobFail = 0

        while not stop_event.is_set():
            if not list_nv:
                list_nv = ["1", "2", "3"]
            random_nv = random.choice(list_nv)
            fields = fields_map.get(str(random_nv), "facebook_reaction")
            try:
                getjob = tds.laynhiemvu(fields)
            except Exception as _e:
                notify(f"⚠️ Lỗi mạng: {str(_e)[:50]}")
                isleep(10)
                continue

            if "id" in getjob.text:
                try:
                    raw = getjob.json()
                    job_list = raw["data"] if isinstance(raw, dict) and "data" in raw else raw
                    if not isinstance(job_list, list):
                        job_list = []
                except:
                    job_list = []
                for x in job_list:
                    if stop_event.is_set():
                        break
                    nextDelay = True
                    id_job = x["id"]
                    id_ = id_job.split("_")[1] if "_" in id_job else id_job
                    DHP07 = True
                    job_type_name = {
                        "1": "Cảm xúc",
                        "2": "Cảm xúc 2",
                        "3": "Cảm xúc Comment",
                        "4": "Chia sẻ",
                        "5": "Theo dõi",
                        "6": "Thích Page"
                    }.get(random_nv, "Nhiệm vụ")

                    if random_nv == "1":
                        fb.camxuc(id_, x["type"])
                        code = x["code"]
                        type_ = x["type"]
                    elif random_nv == "2":
                        fb.camxuc(id_, x["type"])
                        code = x["code"]
                        type_ = x["type"]
                    elif random_nv == "3":
                        fb.camxuccmt(id_, x["type"])
                        code = x["code"]
                        type_ = x["type"]
                    elif random_nv == "4":
                        fb.share(id_)
                        code = x["code"]
                        type_ = "SHARE"
                    elif random_nv == "5":
                        DHP07 = False
                        fb.follow(id_)
                        cache_res = tds.nhantien("facebook_follow_cache", x["code"])
                        cache = cache_res.get("cache", 0) if isinstance(cache_res, dict) else 0
                        nextDelay = True
                        JobFail = 0
                        stt += 1
                        job_success_count += 1
                        notify(f"📊 Job #{stt} | {job_type_name}\n👤 <b>{name_fb}</b> | ID: {id_fb}\n📈 Cache: <b>{cache}/5</b>")
                        if nextDelay:
                            isleep(luong * (settings["DelayBlock"] if stt % int(settings["JobbBlock"]) == 0 else settings["delay"]))
                        if cache >= 5:
                            code = "facebook_api"
                            type_ = "FOLLOW"
                            id_ = "Done"
                            DHP07 = True
                        else:
                            continue
                    elif random_nv == "6":
                        DHP07 = False
                        fb.likepage(id_)
                        cache = tds.nhantien("facebook_page_cache", x["code"]).get("cache", 0) or 0
                        nextDelay = True
                        JobFail = 0
                        stt += 1
                        job_success_count += 1
                        notify(f"📊 Job #{stt} | {job_type_name}\n👤 <b>{name_fb}</b> | ID: {id_fb}\n📈 Cache: <b>{cache}/5</b>")
                        if nextDelay:
                            isleep(luong * (settings["DelayBlock"] if stt % int(settings["JobbBlock"]) == 0 else settings["delay"]))
                        if cache >= 5:
                            code = "facebook_api"
                            type_ = "LIKEPAGE"
                            id_ = "Done"
                            DHP07 = True
                        else:
                            continue
                    if DHP07:
                        isleep(3)
                        nhan = tds.nhantien(fields, code)
                        if "success" in nhan:
                            xu = nhan["data"]["xu"]
                            xutotal = nhan["data"]["msg"].replace(" Xu", "")
                            totalxu += int(xutotal)
                            nextDelay = True
                            JobFail = 0
                            stt += 1
                            job_success_count += 1
                            notify(
                                f"✅ THÀNH CÔNG | Job #{stt}\n━━━━━━━━━━━━━━━━━━━━\n"
                                f"👤 FB: <b>{name_fb}</b>\n"
                                f"🎯 Hành động: <b>{job_type_name}</b>\n"
                                f"💰 +{nhan['data']['msg']}\n"
                                f"📊 Tổng xu: <b>{format(int(totalxu), ',')}</b> xu"
                            )
                            if job_success_count >= settings["JobThanhCong"]:
                                notify(
                                    f"🏁 HOÀN THÀNH MỤC TIÊU\n━━━━━━━━━━━━━━━━━━━━\n"
                                    f"✅ Đã đạt {settings['JobThanhCong']} job thành công!\n"
                                    f"📦 Tổng xu: <b>{format(int(totalxu), ',')}</b> xu"
                                )
                                with sessions_lock:
                                    if (token, cookie) in list_ck:
                                        list_ck.remove((token, cookie))
                                save_user_data(uid, sess)
                                break
                        else:
                            JobFail += 1
                            isleep(2)
                    _max_fail = int(settings.get("MaxFail", 99999))
                    if _max_fail > 0 and JobFail >= _max_fail:
                        notify(
                            f"⛔ DỪNG LUỒNG #{luong}\n━━━━━━━━━━━━━━━━━━━━\n"
                            f"👤 <b>{name_fb}</b>\n"
                            f"❌ Lỗi liên tiếp {JobFail} lần\n"
                            f"👉 Đã loại bỏ luồng này."
                        )
                        if pair in list_ck:
                            list_ck.remove(pair)
                        break
                    if nextDelay:
                        isleep(luong * (settings["DelayBlock"] if stt % int(settings["JobbBlock"]) == 0 else settings["delay"]))
            else:
                if "error" in getjob.text:
                    err = getjob.json().get("error", "")
                    if "Thao tac qua nhanh" in err or "Thao t\u00e1c qu\u00e1 nhanh" in err:
                        isleep(round(getjob.json().get("countdown", 20)))
                    else:
                        isleep(20)
        luong_idx += 1

    sess["running"] = False
    notify(
        f"⏹ ĐÃ DỪNG TOÀN BỘ\n━━━━━━━━━━━━━━━━━━━━\n"
        f"📦 Tổng job: <b>{stt}</b>\n"
        f"💰 Tổng xu: <b>{format(int(totalxu), ',')}</b> xu"
    )


async def _send_main_menu(uid, app):
    sess = get_session(uid)
    tokens = sess.get("tokens", [])
    fb_cks = sess.get("fb_cookies", [])
    tok_en = sum(1 for t in tokens if t.get("enabled", True))
    fb_en = sum(1 for f in fb_cks if f.get("enabled", True))
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🔑 Token TDS ({len(tokens)}/10)", callback_data="tds_token_menu"),
         InlineKeyboardButton(f"🍪 Cookie FB ({len(fb_cks)})", callback_data="tds_cookie_menu")],
        [InlineKeyboardButton("⚙️ Cấu hình", callback_data="tds_config"),
         InlineKeyboardButton("🌐 Proxy", callback_data="tds_proxy_menu")],
        [InlineKeyboardButton("▶️ Chạy", callback_data="tds_run"),
         InlineKeyboardButton("⏹ Dừng", callback_data="tds_stop")],
        [InlineKeyboardButton("📊 Trạng thái", callback_data="tds_status"),
         InlineKeyboardButton("🗑 Xóa tất cả", callback_data="tds_clear")],
        [InlineKeyboardButton("🔙 Menu chính", callback_data="back_home")],
    ])
    status = "🟢 Đang chạy" if sess["running"] else "🔴 Đã dừng"
    text = (f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n📘 <b>TDS Facebook Auto</b>\n"
            f"{status} | 🔑 {tok_en}/{len(tokens)} token | 🍪 {fb_en}/{len(fb_cks)} FB\n\n"
            f"Chọn thao tác:")
    try:
        await app.bot.send_message(chat_id=uid, text=text, reply_markup=kb, parse_mode="HTML")
    except:
        pass


async def _send_proxy_menu(uid, app):
    sess = get_session(uid)
    proxies = sess.get("proxies", [])
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Thêm proxy", callback_data="tds_px_add"),
         InlineKeyboardButton("🗑 Xóa tất cả", callback_data="tds_px_clear")],
        [InlineKeyboardButton("🔙 Quay lại", callback_data="bot_tds")]
    ])
    try:
        await app.bot.send_message(chat_id=uid, text=f"🌐 <b>Proxy</b> ({len(proxies)} proxy)\nChọn:", reply_markup=kb, parse_mode="HTML")
    except:
        pass


async def cmd_entry(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    sess = get_session(uid)
    tokens = sess.get("tokens", [])
    fb_cks = sess.get("fb_cookies", [])
    tok_en = sum(1 for t in tokens if t.get("enabled", True))
    fb_en = sum(1 for f in fb_cks if f.get("enabled", True))
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🔑 Token TDS ({len(tokens)}/10)", callback_data="tds_token_menu"),
         InlineKeyboardButton(f"🍪 Cookie FB ({len(fb_cks)})", callback_data="tds_cookie_menu")],
        [InlineKeyboardButton("⚙️ Cấu hình", callback_data="tds_config"),
         InlineKeyboardButton("🌐 Proxy", callback_data="tds_proxy_menu")],
        [InlineKeyboardButton("▶️ Chạy", callback_data="tds_run"),
         InlineKeyboardButton("⏹ Dừng", callback_data="tds_stop")],
        [InlineKeyboardButton("📊 Trạng thái", callback_data="tds_status"),
         InlineKeyboardButton("🗑 Xóa tất cả", callback_data="tds_clear")],
        [InlineKeyboardButton("🔙 Menu chính", callback_data="back_home")],
    ])
    status = "🟢 Đang chạy" if sess["running"] else "🔴 Đã dừng"
    text = (f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n📘 <b>TDS Facebook Auto</b>\n"
            f"{status} | 🔑 {tok_en}/{len(tokens)} token | 🍪 {fb_en}/{len(fb_cks)} FB\n\n"
            f"Chọn thao tác:")
    if update.callback_query:
        await update.callback_query.message.reply_text(text, reply_markup=kb, parse_mode="HTML")
    else:
        await update.message.reply_text(text, reply_markup=kb, parse_mode="HTML")


async def _show_token_list(uid, query_or_msg, is_query=True):
    sess = get_session(uid)
    tokens = sess.get("tokens", [])
    rows = []
    for i, t in enumerate(tokens):
        enabled = t.get("enabled", True)
        name = (t.get("name", "") or t.get("label", "") or f"Token {i+1}")[:15]
        btn_toggle = InlineKeyboardButton(
            f"{'🟢' if enabled else '🔴'} {i+1}. {name}",
            callback_data=f"tds_tok_toggle_{i}")
        rows.append([btn_toggle, InlineKeyboardButton("🗑", callback_data=f"tds_tok_del_{i}")])
    if len(tokens) < MAX_TDS_TOKENS:
        rows.append([InlineKeyboardButton("➕ Thêm Token TDS", callback_data="tds_add_token")])
    rows.append([InlineKeyboardButton("🔙 Quay lại", callback_data="bot_tds")])
    en = sum(1 for t in tokens if t.get("enabled", True))
    txt = (f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🔑 <b>Token TDS ({len(tokens)}/{MAX_TDS_TOKENS})</b>\n"
           f"🟢 Đang bật: <b>{en}</b> | 🔴 Tắt: <b>{len(tokens)-en}</b>\n\n"
           f"Nhấn nút để bật/tắt | 🗑 để xóa")
    kb = InlineKeyboardMarkup(rows)
    if is_query:
        try:
            await query_or_msg.edit_message_text(txt, reply_markup=kb, parse_mode="HTML")
        except:
            await query_or_msg.message.reply_text(txt, reply_markup=kb, parse_mode="HTML")
    else:
        await query_or_msg.reply_text(txt, reply_markup=kb, parse_mode="HTML")


async def _show_fb_list(uid, query_or_msg, is_query=True):
    sess = get_session(uid)
    fbs = sess.get("fb_cookies", [])
    tokens = sess.get("tokens", [])
    rows = []
    
    # Khởi tạo biến hint trước khi dùng
    hint = ""
    if tokens:
        tok_names = " | ".join([f"[{j+1}]{t.get('name','?')[:8]}" for j, t in enumerate(tokens)])
        hint = f"Token: {tok_names}"
    else:
        hint = "⚠️ Chưa có token TDS — thêm token trước!"

    for i, fb in enumerate(fbs):
        fb_name = fb.get("name_fb", "") or f"FB {i+1}"
        fb_uid = fb.get("fb_uid", "")
        icon = "🟢" if fb.get("enabled", True) else "🔴"
        row1 = [InlineKeyboardButton(f"{icon} {fb_name[:12]} ({fb_uid[-6:] if fb_uid else '?'})", callback_data=f"tds_fb_toggle_{i}"),
                InlineKeyboardButton("🗑", callback_data=f"tds_fb_del_{i}")]
        rows.append(row1)
        if tokens:
            tok_row = []
            assigned = fb.get("token_idx", 0)
            for j, t in enumerate(tokens):
                t_name = t.get("name", "") or f"T{j+1}"
                if j == assigned:
                    tok_row.append(InlineKeyboardButton(f"[{j+1}]✅", callback_data=f"tds_fb_assign_{i}_{j}"))
                else:
                    tok_row.append(InlineKeyboardButton(f"[{j+1}]", callback_data=f"tds_fb_assign_{i}_{j}"))
            rows.append(tok_row)
    rows.append([InlineKeyboardButton("➕ Thêm Cookie FB", callback_data="tds_add_cookie")])
    rows.append([InlineKeyboardButton("🔙 Quay lại", callback_data="bot_tds")])
    
    txt = (f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n👤 <b>Cookie Facebook ({len(fbs)})</b>\n"
           f"{hint}\n\nChọn ô [số] để gán FB → Token TDS tương ứng\n✅ = đang được gán | 🟢 bật | 🔴 tắt | 🗑 xóa")
    kb = InlineKeyboardMarkup(rows)
    if is_query:
        await query_or_msg.edit_message_text(txt, reply_markup=kb, parse_mode="HTML")
    else:
        await query_or_msg.reply_text(txt, reply_markup=kb, parse_mode="HTML")


async def handle_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    query = update.callback_query
    data = query.data
    if not data.startswith("tds_") and data != "bot_tds":
        return False
    await query.answer()
    uid = query.from_user.id
    sess = get_session(uid)

    if data == "bot_tds":
        await cmd_entry(update, ctx)
        return True

    if data == "tds_token_menu" or data == "tds_addacc":
        await _show_token_list(uid, query, is_query=True)
        return True

    if data == "tds_cookie_menu":
        await _show_fb_list(uid, query, is_query=True)
        return True

    if data == "tds_addacc_legacy":
        ctx.user_data["tds_state"] = ST_TAIKHOAN
        await query.edit_message_text("📥 Gửi danh sách tài khoản:\n<code>TOKEN_TDS|COOKIE_FACEBOOK</code>\n\nMỗi dòng 1 tài khoản:\n(Gõ /start để huỷ)", parse_mode="HTML")
        return True

    if data == "tds_manage_accs":
        accs = sess["accounts"]
        rows = []
        for i, a in enumerate(accs):
            lbl = a.get("label", f"acc{i+1}")
            enabled = a.get("enabled", True)
            icon = "🟢" if enabled else "🔴"
            rows.append([InlineKeyboardButton(f"{icon} {lbl[:20]}", callback_data=f"tds_acc_toggle_{i}"),
                         InlineKeyboardButton("🗑", callback_data=f"tds_acc_del_{i}")])
        rows.append([InlineKeyboardButton("➕ Thêm acc", callback_data="tds_addacc")])
        rows.append([InlineKeyboardButton("🗑 Xóa tất cả", callback_data="tds_clear"),
                     InlineKeyboardButton("🔙 Quay lại", callback_data="bot_tds")])
        enabled_count = sum(1 for a in accs if a.get("enabled", True))
        await query.edit_message_text(
            f"👥 <b>Quản lý luồng TDS</b>\nTổng: <b>{len(accs)}</b> | 🟢 Bật: <b>{enabled_count}</b> | 🔴 Tắt: <b>{len(accs)-enabled_count}</b>\n\n🟢 = đang chọn chạy | 🔴 = tạm dừng luồng | 🗑 = xóa luồng",
            reply_markup=InlineKeyboardMarkup(rows),
            parse_mode="HTML"
        )
        return True

    if data.startswith("tds_acc_toggle_"):
        idx = int(data.split("_")[-1])
        accs = sess["accounts"]
        if 0 <= idx < len(accs):
            accs[idx]["enabled"] = not accs[idx].get("enabled", True)
            save_user_data(uid, sess)
        rows = []
        for i, a in enumerate(accs):
            lbl = a.get("label", f"acc{i+1}")
            enabled = a.get("enabled", True)
            icon = "🟢" if enabled else "🔴"
            rows.append([InlineKeyboardButton(f"{icon} {lbl[:20]}", callback_data=f"tds_acc_toggle_{i}"),
                         InlineKeyboardButton("🗑", callback_data=f"tds_acc_del_{i}")])
        rows.append([InlineKeyboardButton("➕ Thêm acc", callback_data="tds_addacc")])
        rows.append([InlineKeyboardButton("🗑 Xóa tất cả", callback_data="tds_clear"),
                     InlineKeyboardButton("🔙 Quay lại", callback_data="bot_tds")])
        enabled_count = sum(1 for a in accs if a.get("enabled", True))
        await query.edit_message_text(
            f"👥 <b>Quản lý luồng TDS</b>\nTổng: <b>{len(accs)}</b> | 🟢 {enabled_count} | 🔴 {len(accs)-enabled_count}",
            reply_markup=InlineKeyboardMarkup(rows),
            parse_mode="HTML"
        )
        return True

    if data.startswith("tds_acc_del_"):
        idx = int(data.split("_")[-1])
        accs = sess["accounts"]
        if 0 <= idx < len(accs):
            accs.pop(idx)
            save_user_data(uid, sess)
        rows = []
        for i, a in enumerate(accs):
            lbl = a.get("label", f"acc{i+1}")
            enabled = a.get("enabled", True)
            icon = "🟢" if enabled else "🔴"
            rows.append([InlineKeyboardButton(f"{icon} {lbl[:20]}", callback_data=f"tds_acc_toggle_{i}"),
                         InlineKeyboardButton("🗑", callback_data=f"tds_acc_del_{i}")])
        rows.append([InlineKeyboardButton("➕ Thêm acc", callback_data="tds_addacc")])
        rows.append([InlineKeyboardButton("🗑 Xóa tất cả", callback_data="tds_clear"),
                     InlineKeyboardButton("🔙 Quay lại", callback_data="bot_tds")])
        enabled_count = sum(1 for a in accs if a.get("enabled", True))
        await query.edit_message_text(
            f"👥 <b>Quản lý luồng TDS</b>\nTổng: <b>{len(accs)}</b> | 🟢 {enabled_count} | 🔴 {len(accs)-enabled_count}",
            reply_markup=InlineKeyboardMarkup(rows),
            parse_mode="HTML"
        )
        return True

    if data == "tds_add_token":
        if len(get_session(uid).get("tokens", [])) >= MAX_TDS_TOKENS:
            await query.answer(f"❌ Đã đủ {MAX_TDS_TOKENS} token!", show_alert=True)
            return True
        ctx.user_data["tds_state"] = ST_ADD_TOKEN
        await query.edit_message_text("🔑 <b>Thêm Token TDS</b>\nGửi Access Token TDS của bạn:\n(Lấy tại traodoisub.com)", parse_mode="HTML")
        return True

    if data.startswith("tds_tok_toggle_"):
        i = int(data.split("_")[-1])
        sess = get_session(uid)
        toks = sess.get("tokens", [])
        if 0 <= i < len(toks):
            toks[i]["enabled"] = not toks[i].get("enabled", True)
            sess["tokens"] = toks
            save_user_data(uid, sess)
        await _show_token_list(uid, query, is_query=True)
        return True

    if data.startswith("tds_tok_del_"):
        i = int(data.split("_")[-1])
        sess = get_session(uid)
        toks = sess.get("tokens", [])
        if 0 <= i < len(toks):
            toks.pop(i)
            fbs = sess.get("fb_cookies", [])
            for fb in fbs:
                fb["token_idx"] = max(0, min(fb.get("token_idx", 0), len(toks) - 1))
            sess["tokens"] = toks
            save_user_data(uid, sess)
        await _show_token_list(uid, query, is_query=True)
        return True

    if data.startswith("tds_tok_info_"):
        i = int(data.split("_")[-1])
        sess = get_session(uid)
        toks = sess.get("tokens", [])
        if 0 <= i < len(toks):
            t = toks[i]
            await query.answer(f"Token {i+1}: {t.get('name','?')}\nXu: {t.get('xu','?')}\n{'🟢 Bật' if t.get('enabled',True) else '🔴 Tắt'}", show_alert=True)
        return True

    if data == "tds_add_cookie":
        ctx.user_data["tds_state"] = ST_ADD_COOKIE
        await query.edit_message_text("🍪 <b>Thêm Cookie Facebook</b>\nGửi cookie FB (chuỗi c_user=...;xs=...):", parse_mode="HTML")
        return True

    if data.startswith("tds_fb_toggle_"):
        i = int(data.split("_")[-1])
        sess = get_session(uid)
        fbs = sess.get("fb_cookies", [])
        if 0 <= i < len(fbs):
            fbs[i]["enabled"] = not fbs[i].get("enabled", True)
            sess["fb_cookies"] = fbs
            save_user_data(uid, sess)
        await _show_fb_list(uid, query, is_query=True)
        return True

    if data.startswith("tds_fb_del_"):
        i = int(data.split("_")[-1])
        sess = get_session(uid)
        fbs = sess.get("fb_cookies", [])
        if 0 <= i < len(fbs):
            fbs.pop(i)
            sess["fb_cookies"] = fbs
            save_user_data(uid, sess)
        await _show_fb_list(uid, query, is_query=True)
        return True

    if data.startswith("tds_fb_assign_"):
        parts = data.split("_")
        fb_idx = int(parts[-2])
        tok_idx = int(parts[-1])
        sess = get_session(uid)
        fbs = sess.get("fb_cookies", [])
        if 0 <= fb_idx < len(fbs):
            fbs[fb_idx]["token_idx"] = tok_idx
            sess["fb_cookies"] = fbs
            save_user_data(uid, sess)
        await _show_fb_list(uid, query, is_query=True)
        return True

    if data == "tds_config":
        if sess["settings"]:
            cfg = sess["settings"]
            nv_names = {"1": "React", "2": "React2", "3": "ReactCmt", "4": "Share", "5": "Follow", "6": "LikePage"}
            nv_str = ", ".join([nv_names.get(n, n) for n in cfg.get("nhiemvu", [])])
            kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ Dùng cấu hình cũ", callback_data="tds_cfg_old"),
                 InlineKeyboardButton("🆕 Cấu hình mới", callback_data="tds_cfg_new")]
            ])
            await query.edit_message_text(
                f"💾 <b>Cấu hình đã lưu:</b>\n• Nhiệm vụ: {nv_str}\n• Delay: {cfg.get('delay')}s\n• Dừng sau: {cfg.get('JobThanhCong')} job",
                reply_markup=kb,
                parse_mode="HTML"
            )
        else:
            ctx.user_data["tds_state"] = ST_CHON_NV
            ctx.user_data["tds_list_nv"] = []
            await query.edit_message_text("🎯 Chọn nhiệm vụ (gõ số liên tiếp VD: <code>123</code>):\n1=React, 2=React2, 3=ReactCmt, 4=Share, 5=Follow, 6=LikePage\n(Gõ /start để huỷ)", parse_mode="HTML")
        return True

    if data == "tds_cfg_old":
        await query.edit_message_text("✅ Giữ cấu hình cũ.")
        await _send_main_menu(uid, ctx.application)
        return True

    if data == "tds_cfg_new":
        ctx.user_data["tds_state"] = ST_CHON_NV
        ctx.user_data["tds_list_nv"] = []
        await query.edit_message_text("🎯 Chọn nhiệm vụ (gõ số VD: <code>1234</code>):\n1=React, 2=React2, 3=ReactCmt, 4=Share, 5=Follow, 6=LikePage\n(Gõ /start để huỷ)", parse_mode="HTML")
        return True

    if data == "tds_run":
        if sess["running"]:
            await query.edit_message_text("⚠️ Bot đang chạy rồi!")
            return True
        if not sess["settings"]:
            await query.edit_message_text("⚠️ Chưa cấu hình!\nVào ⚙️ Cấu hình trước.")
            return True
        tokens = [t for t in sess.get("tokens", []) if t.get("enabled", True)]
        fb_cks = [f for f in sess.get("fb_cookies", []) if f.get("enabled", True)]
        if not tokens or not fb_cks:
            old_accs = get_active_accounts(uid)
            if not old_accs:
                await query.edit_message_text(
                    "❌ Chưa có tài khoản!\nToken bật: {len(tokens)} | Cookie FB bật: {len(fb_cks)}\nVào 📂 Tài khoản → 🔑 Token TDS để thêm, rồi → 🍪 Cookie FB → nhấn [1] để gán.",
                    parse_mode="HTML"
                )
                return True
        new_ev = threading.Event()
        sess["stop_event"] = new_ev
        sess["running"] = True
        sess["logs"] = []
        app = ctx.application
        loop = asyncio.get_event_loop()

        def send_fn(user_id, msg):
            asyncio.run_coroutine_threadsafe(app.bot.send_message(chat_id=user_id, text=msg, parse_mode="HTML"), loop)

        t = threading.Thread(target=worker, args=(uid, send_fn), daemon=True)
        sess["thread"] = t
        t.start()
        await query.edit_message_text(f"🚀 <b>Đã bắt đầu TDS!</b>\n🔑 {len(tokens)} token | 🍪 {len(fb_cks)} cookie", parse_mode="HTML")
        return True

    if data == "tds_stop":
        if sess["running"] or (sess["thread"] and sess["thread"].is_alive()):
            sess["stop_event"].set()
            sess["running"] = False
            t = sess.get("thread")
            alive_msg = ""
            if t and t.is_alive():
                t.join(timeout=5)
                alive_msg = "" if not t.is_alive() else "\n⚠️ Thread đang kết thúc job cuối..."
            import threading as _thr2
            sess["stop_event"] = _thr2.Event()
            await query.message.reply_text(f"⏹ <b>Đã dừng TDS!</b>{alive_msg}", parse_mode="HTML")
        else:
            await query.message.reply_text("ℹ️ TDS chưa chạy.")
        await _send_main_menu(uid, ctx.application)
        return True

    if data == "tds_status":
        cfg = sess["settings"]
        nv_names = {"1": "React", "2": "React2", "3": "ReactCmt", "4": "Share", "5": "Follow", "6": "LikePage"}
        cfg_text = (f"NV: {', '.join([nv_names.get(n,n) for n in cfg.get('nhiemvu',[])])}\nDelay: {cfg.get('delay','-')}s | Dừng sau: {cfg.get('JobThanhCong','-')} job") if cfg else "Chưa cấu hình"
        logs = sess["logs"][-8:]
        log_text = "\n".join(logs) if logs else "Chưa có log."
        status = "🟢 Đang chạy" if sess["running"] else "🔴 Đã dừng"
        await query.edit_message_text(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n📊 <b>{status}</b> | 👥 {len(sess.get('accounts',[]))} acc\n⚙️ {cfg_text}\n\n📝 Log:\n<pre>{log_text}</pre>",
            parse_mode="HTML"
        )
        return True

    if data == "tds_clear":
        if sess["running"]:
            await query.edit_message_text("⚠️ Dừng bot trước!")
            return True
        sess["accounts"] = []
        save_user_data(uid, sess)
        await query.edit_message_text("🗑 Đã xóa tất cả tài khoản!")
        await _send_main_menu(uid, ctx.application)
        return True

    if data == "tds_proxy_menu":
        proxies = sess.get("proxies", [])
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ Thêm proxy", callback_data="tds_px_add"),
             InlineKeyboardButton("🗑 Xóa tất cả", callback_data="tds_px_clear")],
            [InlineKeyboardButton("🔙 Quay lại", callback_data="bot_tds")]
        ])
        await query.edit_message_text(f"🌐 <b>Proxy</b> ({len(proxies)} proxy)\nChọn:", reply_markup=kb, parse_mode="HTML")
        return True

    if data == "tds_px_add":
        ctx.user_data["tds_state"] = ST_PROXY
        await query.edit_message_text("📥 Gửi danh sách proxy (mỗi dòng 1 proxy):\n(Gõ /start để huỷ)")
        return True

    if data == "tds_px_clear":
        sess["proxies"] = []
        save_user_data(uid, sess)
        await query.edit_message_text("🗑 Đã xóa proxy!")
        await _send_proxy_menu(uid, ctx.application)
        return True

    return False


async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    uid = update.effective_user.id
    text = update.message.text.strip()
    state = ctx.user_data.get("tds_state")
    if not state:
        return False
    sess = get_session(uid)

    async def reply(msg, parse_mode="HTML", reply_markup=None):
        await update.message.reply_text(msg, parse_mode=parse_mode, reply_markup=reply_markup)

    if state == ST_ADD_TOKEN:
        token = text.strip()
        if not token:
            await reply("❌ Token rỗng!")
            return True
        sess = get_session(uid)
        toks = sess.get("tokens", [])
        if len(toks) >= MAX_TDS_TOKENS:
            await reply(f"❌ Đã đủ {MAX_TDS_TOKENS} token!")
            return True
        try:
            from . import tds as _tds_self
            _tmp = _tds_self.TDS_Facebook(token)
            info = _tmp.info()
            if info.get("status") == "success":
                name = info.get("name", f"Token {len(toks)+1}")
                xu = info.get("xu", "?")
            else:
                name = f"Token {len(toks)+1}"
                xu = "?"
        except:
            name = f"Token {len(toks)+1}"
            xu = "?"
        toks.append({"token": token, "name": name, "xu": xu, "enabled": True, "_new": True})
        sess["tokens"] = toks
        save_user_data(uid, sess)
        ctx.user_data.pop("tds_state", None)
        await reply(f"✅ <b>Đã thêm Token TDS #{len(toks)}</b>\n👤 <b>{name}</b> | Xu: <b>{xu}</b>\nTrạng thái: 🔴 Chưa bật — nhấn nút để bật)")
        await _send_main_menu(uid, ctx.application)
        return True

    if state == ST_ADD_COOKIE:
        cookie = text.strip()
        if not cookie:
            await reply("❌ Cookie rỗng!")
            return True
        fb_uid = "?"
        name_fb = "?"
        try:
            if "c_user=" in cookie:
                fb_uid = cookie.split("c_user=")[1].split(";")[0]
            from .bumx import FB as _FB
            _fb = _FB(cookie)
            name_fb = _fb.get_name() or f"UID:{fb_uid}"
        except:
            name_fb = f"UID:{fb_uid}"
        sess = get_session(uid)
        fbs = sess.get("fb_cookies", [])
        fbs.append({"cookie": cookie, "name_fb": name_fb, "fb_uid": fb_uid, "token_idx": 0, "enabled": True})
        sess["fb_cookies"] = fbs
        save_user_data(uid, sess)
        ctx.user_data.pop("tds_state", None)
        await reply(f"✅ <b>Đã thêm Cookie FB</b>\n👤 <b>{name_fb}</b> (UID: {fb_uid})\nMặc định chạy cho Token 1 — vào Cookie FB để đổi")
        await _send_main_menu(uid, ctx.application)
        return True

    if state == ST_TAIKHOAN:
        added = 0
        skipped = 0
        existing_keys = {(a["token"], a["cookie"]) for a in sess["accounts"]}
        for i, line in enumerate(text.splitlines()):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split("|", 1)
            if len(parts) != 2:
                skipped += 1
                continue
            token, cookie = parts[0].strip(), parts[1].strip()
            if not token or not cookie:
                skipped += 1
                continue
            key = (token, cookie)
            if key in existing_keys:
                skipped += 1
                continue
            _name_fb = ""
            try:
                _fb_tmp = Facebook(cookie, get_proxy_for_account(sess, len(sess["accounts"])))
                _info = _fb_tmp.info()
                if isinstance(_info, dict) and _info.get("status") == "success":
                    _name_fb = _info.get("name", "")
            except:
                pass
            _tds_tmp = TDS_Facebook(token)
            _tds_info = _tds_tmp.info()
            _tds_name = _tds_info.get("name", "") if _tds_info.get("status") == "success" else ""
            label = f"{_name_fb or _tds_name or f'TDS-{len(sess["accounts"])+1}'}"
            sess["accounts"].append({
                "token": token,
                "cookie": cookie,
                "enabled": True,
                "label": label,
                "name_fb": _name_fb,
                "name_tds": _tds_name
            })
            existing_keys.add(key)
            added += 1
        save_user_data(uid, sess)
        ctx.user_data.pop("tds_state", None)
        await reply(f"✅ Thêm <b>{added}</b> tài khoản\n⏭ Bỏ qua <b>{skipped}</b> dòng\nTổng: <b>{len(sess['accounts'])}</b>")
        await _send_main_menu(uid, ctx.application)
        return True

    if state == ST_CHON_NV:
        valid = {"1", "2", "3", "4", "5", "6"}
        list_nv = [c for c in text if c in valid]
        if not list_nv:
            await reply("❌ Không hợp lệ! VD: <code>123</code>")
            return True
        ctx.user_data["tds_list_nv"] = list_nv
        ctx.user_data["tds_state"] = ST_DELAY
        await reply(f"✅ NV: <code>{''.join(list_nv)}</code>\n⏱ Delay giữa các job (giây):")
        return True

    if state == ST_DELAY:
        try:
            ctx.user_data["tds_delay"] = int(text)
            ctx.user_data["tds_state"] = ST_JOBBBLOCK
            await reply("🔢 Sau bao nhiêu job chống block (>1):")
        except:
            await reply("❌ Nhập số nguyên!")
        return True

    if state == ST_JOBBBLOCK:
        try:
            v = int(text)
            assert v > 1
            ctx.user_data["tds_jobbblock"] = v
            ctx.user_data["tds_state"] = ST_DELAYBLOCK
            await reply(f"⏸ Nghỉ bao nhiêu giây sau {v} job?")
        except:
            await reply("❌ Nhập số > 1!")
        return True

    if state == ST_DELAYBLOCK:
        try:
            ctx.user_data["tds_delayblock"] = int(text)
            ctx.user_data["tds_state"] = ST_JOBTC
            await reply("🏁 Dừng sau bao nhiêu job thành công (>1)?")
        except:
            await reply("❌ Nhập số nguyên!")
        return True

    if state == ST_JOBTC:
        try:
            v = int(text)
            assert v > 1
            ctx.user_data["tds_jobtc"] = v
            ctx.user_data["tds_state"] = ST_MAX_FAIL
            await reply(f"✅ Dừng sau: <b>{v}</b> job\n\n⚠️ <b>[6/6] Giới hạn lỗi liên tiếp</b>:\nVD: <code>20</code> = bỏ acc sau 20 job lỗi liên tiếp\nNhập <code>0</code> = không giới hạn:")
        except:
            await reply("❌ Nhập số > 1!")
        return True

    if state == ST_MAX_FAIL:
        try:
            v = int(text)
            assert v >= 0
            max_fail = v if v > 0 else 99999
            settings = {
                "nhiemvu": ctx.user_data.pop("tds_list_nv", []),
                "delay": ctx.user_data.pop("tds_delay", 3),
                "JobbBlock": ctx.user_data.pop("tds_jobbblock", 10),
                "DelayBlock": ctx.user_data.pop("tds_delayblock", 30),
                "JobThanhCong": ctx.user_data.pop("tds_jobtc", 10),
                "MaxFail": max_fail
            }
            sess["settings"] = settings
            sess["temp"] = {}
            save_user_data(uid, sess)
            ctx.user_data.pop("tds_state", None)
            fail_txt = "Không giới hạn" if v == 0 else f"{v} lỗi liên tiếp"
            await reply(
                f"✅ <b>Đã lưu cấu hình TDS!</b>\n"
                f"├ Nhiệm vụ: {settings['nhiemvu']}\n"
                f"├ Delay: {settings['delay']}s\n"
                f"├ Chống block: {settings['JobbBlock']} job → nghỉ {settings['DelayBlock']}s\n"
                f"├ Dừng sau: {settings['JobThanhCong']} job thành công\n"
                f"└ Giới hạn lỗi: {fail_txt}"
            )
            await _send_main_menu(uid, ctx.application)
        except:
            await reply("❌ Nhập số >= 0:")
        return True

    if state == ST_PROXY:
        lines = [l.strip() for l in text.splitlines() if l.strip() and not l.strip().startswith("#")]
        added = 0
        skipped = 0
        existing = set(sess.get("proxies", []))
        for line in lines:
            if line in existing:
                skipped += 1
                continue
            sess["proxies"].append(line)
            existing.add(line)
            added += 1
        save_user_data(uid, sess)
        ctx.user_data.pop("tds_state", None)
        await reply(f"✅ Thêm <b>{added}</b> proxy\nTổng: <b>{len(sess['proxies'])}</b>")
        await _send_proxy_menu(uid, ctx.application)
        return True

    return False