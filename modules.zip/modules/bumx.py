"""Module BUMX — bumx.vn | Quản lý cookie với chọn/xóa từng acc"""
import asyncio, json, os, random, re, time, uuid, base64, threading
from datetime import datetime
from pathlib import Path
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from .crypto_utils import save_encrypted, load_encrypted
from .key_system import update_earnings, deduct_api_fee, can_use_api

BOT_TOKEN = ""
DATA_DIR = Path("data/bumx_users")
DATA_DIR.mkdir(parents=True, exist_ok=True)

ST_AUTH="bumx_wait_auth"; ST_AUTHPROXY="bumx_wait_auth_proxy"
ST_COOKIE="bumx_wait_cookie"; ST_CKPROXY="bumx_wait_cookie_proxy"
ST_TONGJOB="bumx_wait_tongjob"; ST_DMIN="bumx_wait_dmin"
ST_DMAX="bumx_wait_dmax"; ST_AMIN="bumx_wait_amin"; ST_AMAX="bumx_wait_amax"
ST_ADD_AUTH="bumx_add_auth"; ST_ADD_COOKIE="bumx_add_cookie_new"
MAX_BUMX_AUTH = 10   # Tối đa 10 token BUMX

running_tasks: dict = {}
stop_flags:    dict = {}

import requests

def _udir(uid):
    d = DATA_DIR / str(uid); d.mkdir(parents=True, exist_ok=True); return d

def save_config(uid, data):
    save_encrypted(str(_udir(uid)/"config.json"), data)
def load_config(uid):
    return load_encrypted(str(_udir(uid)/"config.json"), {})

def save_auth_list(uid, auths):
    save_encrypted(str(_udir(uid)/"auth_list.json"), {"auths": auths})
def load_auth_list(uid):
    d = load_encrypted(str(_udir(uid)/"auth_list.json"), {"auths": []})
    return d.get("auths", []) if isinstance(d, dict) else []

def save_cookies(uid, cookies):
    save_encrypted(str(_udir(uid)/"cookies.json"), {"cookies": cookies})
def load_cookies(uid):
    return load_encrypted(str(_udir(uid)/"cookies.json"), {}).get("cookies", [])

def save_stats(uid, stats):
    save_encrypted(str(_udir(uid)/"stats.json"), stats)
def load_stats(uid):
    return load_encrypted(str(_udir(uid)/"stats.json"), {})

def to_proxies(px):
    if not px: return None
    p=px.strip().split(":")
    if len(p)==4:
        try: host,port,user,pw=p; int(port)
        except: user,pw,host,port=p
        return {"http":f"http://{user}:{pw}@{host}:{port}","https":f"http://{user}:{pw}@{host}:{port}"}
    if len(p)==2: return {"http":f"http://{p[0]}:{p[1]}","https":f"http://{p[0]}:{p[1]}"}
    return None

def encode_b64(s): return base64.b64encode(s.encode()).decode()

def get_id(link):
    try:
        r=requests.post("https://id.traodoisub.com/api.php",data={"link":link},timeout=8).json()
        if r.get("success")==200: return r["id"]
    except: pass
    return None

class BUMX:
    def __init__(self,authorization,proxy=None):
        self.proxy=to_proxies(proxy) if proxy else None
        self.authorization=authorization
        self.base_url="https://api-v2.bumx.vn/api"
        self.session=requests.Session()
        self.headers={"User-Agent":"Dart/3.3 (dart:io)","Content-Type":"application/json",
                      "lang":"vi","version":"37","origin":"app","authorization":self.authorization}
    def get_wallet_balance(self):
        try:
            r=self.session.get(f"{self.base_url}/business/wallet",headers=self.headers,timeout=10,proxies=self.proxy).json()
            return str(r.get("data",{}).get("balance","N/A"))
        except Exception as e: return f"Lỗi: {e}"
    def connect_account_fb(self,uid):
        try: self.session.post("https://api-v2.bumx.vn/api/account-facebook/connect-link",
                               headers=self.headers,json={"link":f"https://www.facebook.com/profile.php?id={uid}"},timeout=10,proxies=self.proxy)
        except: pass
    def reload(self,type_job):
        try:
            r=self.session.post("https://api-v2.bumx.vn/api/buff/get-new-mission",
                                headers=self.headers,json={"type":type_job},timeout=10,proxies=self.proxy).json()
            if "đã hết nhiệm vụ" in str(r): return {"sonv":0,"cmt":False,"hetnv":True}
            if "Bạn cần làm job comment" in str(r): return {"sonv":0,"cmt":True,"hetnv":False}
            return {"sonv":len(r.get("data",[])),"cmt":False,"hetnv":False}
        except: return {"sonv":0,"cmt":False,"hetnv":False}
    def show_job(self):
        try:
            r=self.session.get("https://api-v2.bumx.vn/api/buff/mission",
                               headers=self.headers,params={"is_from_mobile":"true"},timeout=10,proxies=self.proxy).json()
            if r.get("success") and r.get("count",0)>0: return r.get("data",[])
        except: pass
        return None
    def show_single_job(self,job):
        try:
            r=self.session.post("https://api-v2.bumx.vn/api/buff/load-mission",
                                headers=self.headers,json={"buff_id":job["buff_id"]},timeout=10,proxies=self.proxy).json()
            if job.get("type")=="like_poster":
                if "Nhiệm vụ này đã đủ số lượng" in str(r): return {"vaild_job":False}
                return {"vaild_job":True,"type_reaction":"","data":r.get("data",""),"comment_id":r.get("comment_id",""),
                        "link_job":"https://www.facebook.com/"+r.get("object_id","")}
            elif job.get("type")=="like_facebook":
                if "Nhiệm vụ này đã đủ số lượng" in str(r): return {"vaild_job":False}
                icon=r.get("icon","").lower(); react="LIKE"
                for k,v in [("love","LOVE"),("care","CARE"),("wow","WOW"),("sad","SAD"),("angry","ANGRY"),("haha","HAHA")]:
                    if k in icon: react=v; break
                return {"vaild_job":True,"link_job":"https://www.facebook.com/"+r.get("object_id",""),
                        "type_reaction":react,"data":"","comment_id":""}
        except: pass
        return {"vaild_job":False}
    def format_json_job(self,job,res):
        return {"vaild_job":res.get("vaild_job"),"comment_msg":res.get("data"),"comment_id":res.get("comment_id"),
                "link_job":res.get("link_job"),"buff_id":job.get("buff_id"),"type_job":job.get("type"),"type_reaction":res.get("type_reaction")}
    def skip_job(self,job):
        bid=job.get("buff_id") if isinstance(job,dict) else None
        if not bid: return
        try: self.session.post(f"{self.base_url}/buff/report-buff",headers=self.headers,json={"buff_id":bid},timeout=10,proxies=self.proxy)
        except: pass
    def submit_job(self,json_job):
        try:
            data={"buff_id":json_job["buff_id"],"comment":None,"comment_id":None,"code_submit":None,
                  "attachments":[],"link_share":"","code":"","is_from_mobile":True,"type":json_job["type_job"],"sub_id":None,"data":None}
            if json_job["type_job"]=="like_facebook": data["comment"]="tt nha"
            elif json_job["type_job"]=="like_poster": data["comment"]=json_job.get("data"); data["comment_id"]=json_job.get("comment_id")
            return self.session.post("https://api-v2.bumx.vn/api/buff/submit-mission",headers=self.headers,json=data,timeout=10,proxies=self.proxy).json()
        except: return None

class FB:
    """
    Facebook class — logic từ Bumx_v1.py gốc.
    Dùng session Chrome headers thật, lấy đủ fb_dtsg/jazoest/lsd/session_id.
    """
    def __init__(self, cookie, proxy=None):
        self.cookie  = cookie
        self.proxy   = to_proxies(proxy) if proxy else None
        self.session = requests.Session()
        self.user_id = self.fb_dtsg = self.jazoest = self.lsd = self.session_id = self.name = None
        self.headers_fb = {}
        try:
            self.user_id = cookie.split("c_user=")[1].split(";")[0]
            headers = {
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "accept-language": "vi,en;q=0.9",
                "sec-ch-ua": '"Chromium";v="140","Not=A?Brand";v="24","Google Chrome";v="140"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": '"Windows"',
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "none",
                "upgrade-insecure-requests": "1",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
                "viewport-width": "811",
                "cookie": cookie,
            }
            if self.proxy: self.session.proxies.update(self.proxy)
            resp = self.session.get("https://www.facebook.com/", headers=headers, timeout=20).text
            # Lấy fb_dtsg (2 cách)
            try:
                self.fb_dtsg = re.findall(r'{"dtsg":{"token":".*?"', resp)[0].split('":"')[1].split('"')[0]
            except:
                try: self.fb_dtsg = re.findall(r'\["DTSGInitialData",\[\],{"token":"(.*?)"\}', resp)[0]
                except: pass
            try: self.jazoest = re.findall(r'&jazoest=.*?"', resp)[0].split('=')[1].split('"')[0]
            except: pass
            try: self.lsd = re.findall(r'"LSD".*?"}', resp)[0].split('":"')[1].split('"}')[0]
            except:
                try: self.lsd = re.findall(r'"LSD",\[\],{"token":"(.*?)"}', resp)[0]
                except: pass
            try: self.session_id = re.findall(r'sessionID":".*?"', resp)[0].split('":"')[1].split('"')[0]
            except:
                try: self.session_id = re.findall(r'"profile_session_id":"(.*?)"', resp)[0]
                except: self.session_id = str(uuid.uuid4())
            try: self.name = re.findall(r'"NAME":".*?"', resp)[0].split('":"')[1].split('"')[0]
            except: self.name = f"UID:{self.user_id}"
            self.headers_fb = headers
        except Exception as e:
            self.user_id = None

    def get_post_id(self, link):
        """Lấy post_id/permalink_id/stories_id từ link Facebook — giống tool gốc"""
        headers = dict(self.headers_fb)
        headers["cookie"] = self.cookie
        post_id = permalink_id = stories_id = page_id = ""
        try:
            resp = self.session.get(link, headers=headers, timeout=15).text
            resp = re.sub(r"\\", "", resp)
            try:
                if '"post_id":"' in resp:
                    permalink_id = re.findall(r'"post_id":".*?"', resp)[0].split(':"')[1].split('"')[0]
            except: pass
            try:
                if "posts" in resp:
                    post_id = resp.split("posts")[1].split('"')[0].replace("/", "")
                    post_id = re.sub(r"\\", "", post_id)
            except: pass
            try:
                if "storiesTrayType" in resp and '"profile_type_name_for_content":"PAGE"' not in resp:
                    stories_id = re.findall(r'"card_id":".*?"', resp)[0].split('":"')[1].split('"')[0]
            except: pass
            try:
                if '"page_id"' in resp:
                    page_id = re.findall(r'"page_id":".*?"', resp)[0].split('id":"')[1].split('"')[0]
            except: pass
        except: pass
        return {"post_id": post_id, "permalink_id": permalink_id, "stories_id": stories_id, "page_id": page_id}

    def _react_headers(self, object_id):
        return {
            "accept": "*/*", "accept-language": "en-US,en;q=0.9,vi;q=0.8",
            "content-type": "application/x-www-form-urlencoded",
            "origin": "https://www.facebook.com",
            "referer": f"https://www.facebook.com/{object_id}",
            "sec-ch-ua": '"Chromium";v="140","Not=A?Brand";v="24","Google Chrome";v="140"',
            "sec-ch-ua-mobile": "?0", "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-origin",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
            "x-asbd-id": "359341",
            "x-fb-friendly-name": "CometUFIFeedbackReactMutation",
            "x-fb-lsd": self.lsd or "",
            "cookie": self.cookie,
        }

    def react(self, object_id, type_react="LIKE"):
        """Thả cảm xúc — logic từ react_post_defaul trong tool gốc"""
        react_list = {"LIKE":"1635855486666999","LOVE":"1678524932434102","CARE":"613557422527858",
                      "HAHA":"115940658764963","WOW":"478547315650144","SAD":"908563459236466","ANGRY":"444813342392137"}
        try:
            headers = self._react_headers(object_id)
            ts = str(int(time.time()*1000))
            data = {
                "av": str(self.user_id), "__aaid": "0", "__user": str(self.user_id),
                "fb_dtsg": self.fb_dtsg, "jazoest": str(self.jazoest), "lsd": self.lsd,
                "__spin_r": "1027704617", "__spin_b": "trunk", "__spin_t": "1759056792",
                "__crn": "comet.fbweb.CometSinglePostDialogRoute",
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "CometUFIFeedbackReactMutation",
                "variables": (
                    '{"input":{"attribution_id_v2":"CometSinglePostDialogRoot.react,comet.post.single_dialog,via_cold_start,'
                    + ts + ',912367,,,","feedback_id":"' + encode_b64(f"feedback:{object_id}")
                    + '","feedback_reaction_id":"' + str(react_list.get(type_react.upper(), react_list["LIKE"]))
                    + '","feedback_source":"OBJECT","is_tracking_encrypted":true,"tracking":[],"session_id":"' + str(self.session_id)
                    + '","downstream_share_session_id":"' + str(self.session_id)
                    + '","downstream_share_session_origin_uri":"https://www.facebook.com/' + str(object_id)
                    + '","downstream_share_session_start_time":"' + ts
                    + '","actor_id":"' + str(self.user_id)
                    + '","client_mutation_id":"1"},"useDefaultActor":false,"__relay_internal__pv__CometUFIReactionsEnableShortNamerelayprovider":false}'
                ),
                "server_timestamps": "true",
                "doc_id": "24034997962776771",
            }
            if self.proxy: self.session.proxies.update(self.proxy)
            r = self.session.post("https://www.facebook.com/api/graphql/", headers=headers, data=data, timeout=15)
            return r.status_code == 200
        except: return False

    def comment(self, object_id, msg, id_profile=None):
        """Comment vào bài — logic từ comment_fb trong tool gốc"""
        try:
            if not id_profile: id_profile = self.user_id
            headers = {
                "accept": "*/*", "accept-language": "vi,en;q=0.9",
                "content-type": "application/x-www-form-urlencoded",
                "origin": "https://www.facebook.com",
                "referer": f"https://www.facebook.com/{object_id}",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "x-fb-lsd": self.lsd or "", "cookie": self.cookie,
            }
            data = {
                "av": str(id_profile), "__user": str(id_profile),
                "fb_dtsg": self.fb_dtsg, "jazoest": str(self.jazoest), "lsd": self.lsd,
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "useCometUFICreateCommentMutation",
                "variables": (
                    '{"feedLocation":"DEDICATED_COMMENTING_SURFACE","feedbackSource":110,"groupID":null,'
                    '"input":{"client_mutation_id":"4","actor_id":"' + str(id_profile)
                    + '","attachments":null,"feedback_id":"' + encode_b64(f"feedback:{object_id}")
                    + '","message":{"ranges":[],"text":"' + str(msg).replace('"', " ")
                    + '"},"attribution_id_v2":"CometHomeRoot.react,comet.home,via_cold_start,'
                    + str(int(time.time()*1000)) + ',521928,4748854339,,","is_tracking_encrypted":true,"tracking":[],"feedback_source":"DEDICATED_COMMENTING_SURFACE","idempotence_token":"client:'
                    + str(uuid.uuid4()) + '","session_id":"' + str(self.session_id)
                    + '"},"scale":1,"useDefaultActor":false,"focusCommentID":null}'
                ),
                "server_timestamps": "true",
                "doc_id": "7147724938669397",
            }
            if self.proxy: self.session.proxies.update(self.proxy)
            r = self.session.post("https://www.facebook.com/api/graphql/", headers=headers, data=data, timeout=15)
            return r.status_code == 200
        except: return False

    def check_cookie(self):
        """Kiểm tra cookie thật bằng request đến Facebook"""
        try:
            r = self.session.get("https://www.facebook.com/", headers=self.headers_fb, proxies=self.proxy, timeout=15)
            # Nếu có các dấu hiệu login -> cookie die
            for sig in ["601051028565049","1501092823525282","828281030927956",'title="Log in to Facebook"']:
                if sig in r.text: return False
            return True
        except: return False

    def get_name(self): return self.name or f"UID:{self.user_id}"


def LAMJOB(fb, json_job):
    """
    Làm job BUMX theo logic tool gốc:
    1. like_facebook → react_post (lấy post_id thật rồi react)
       Nếu react thất bại → fallback sang comment (like_poster)
    2. like_poster → comment vào post
    """
    try:
        link = json_job.get("link_job", "")
        type_job = json_job.get("type_job", "")

        if not link: return False

        if type_job == "like_facebook":
            # Lấy post_id thật từ link (giống tool gốc)
            ids = fb.get_post_id(link)
            react_type = json_job.get("type_reaction", "LIKE")

            # Thử react theo thứ tự: permalink → post_id thường
            object_id = ids.get("permalink_id") or ids.get("post_id") or ""

            if object_id:
                ok = fb.react(object_id, react_type)
                if ok: return True
            # ── Fallback: không react được → comment ──
            # Đây là logic yêu cầu: "nếu BUMX không cho làm cảm xúc thì làm comment"
            msg = json_job.get("comment_msg") or "Hay quá bạn ơi 👍"
            fallback_id = object_id or ids.get("post_id") or ""
            if fallback_id:
                ok2 = fb.comment(fallback_id, msg)
                if ok2:
                    json_job["_fallback_comment"] = True  # Đánh dấu đã fallback
                    return True
            return False

        elif type_job == "like_poster":
            # Comment job — lấy post_id thật rồi comment
            ids = fb.get_post_id(link)
            object_id = ids.get("post_id") or ids.get("permalink_id") or ""
            if not object_id:
                # Fallback: lấy id từ cuối link
                object_id = get_id(link)
            msg = json_job.get("comment_msg", "Hay lắm 😍")
            if object_id:
                return fb.comment(object_id, msg)
            return False

    except Exception as e:
        return False
    return False

async def worker(uid, app):
    """
    BUMX worker — chạy tối đa 10 cookie song song.
    Mỗi cookie = 1 task asyncio riêng (không blocking).
    """
    cfg      = load_config(uid)
    cookies  = load_cookies(uid)
    # Tạo stop_event mới sạch
    stop_ev  = threading.Event()
    stop_flags[uid] = stop_ev

    async def send(msg):
        try: await app.bot.send_message(chat_id=uid, text=msg, parse_mode=ParseMode.HTML)
        except: pass

    # Kiểm tra quyền
    try:
        from . import system_db as _sdb
        import sys
        _main   = sys.modules.get('__main__') or sys.modules.get('main')
        _admins = getattr(_main, 'MAIN_ADMINS', []) if _main else []
        access  = _sdb.check_access(uid, _admins)
        if not access.get("ok", True):
            await send("🔒 <b>Không thể chạy BUMX</b>\nBạn chưa có key hoặc hết tiền API!")
            return
    except Exception: pass

    # Lấy danh sách auth đang bật
    auths_all = [a for a in load_auth_list(uid) if a.get("enabled",True)]
    if not auths_all:
        cfg_auth = cfg.get("authorization","")
        if cfg_auth:
            auths_all = [{"auth": cfg_auth, "name": "Auth 1", "enabled": True}]
    if not auths_all:
        await send("⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n❌ Chưa có Auth! Vào 🔑 Auth BUMX để thêm."); return
    # Test auth đầu tiên
    bx = BUMX(auths_all[0]["auth"], cfg.get("proxy_bumx",""))
    try: balance = bx.get_wallet_balance()
    except: await send("⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n❌ Auth lỗi!"); return
    # Map auth_idx → BUMX object
    bx_map = {}
    for j, a in enumerate(auths_all):
        try: bx_map[j] = BUMX(a["auth"], cfg.get("proxy_bumx",""))
        except: pass
    if not bx_map: bx_map[0] = bx

    TONGJOB  = int(cfg.get("tongjob", 10))
    dmin     = int(cfg.get("delay_min", 5)); dmax = int(cfg.get("delay_max", 15))
    amin     = int(cfg.get("api_min", 2));   amax = int(cfg.get("api_max", 5))
    MAX_LUONG = min(10, len(cookies))   # Tối đa 10 luồng

    stats = {
        "balance": balance, "job_done": 0, "earned": 0,
        "cookie_total": len(cookies), "cookie_live": len(cookies),
        "cookie_block": 0, "job_block": 0,
        "started_at": datetime.now().strftime("%H:%M:%S %d/%m/%Y"),
    }
    save_stats(uid, stats)

    active_cks = [ck for ck in cookies if ck.get("enabled", True)]
    await send(
        f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🚀 <b>BẮT ĐẦU — {MAX_LUONG} luồng song song</b>\n"
        f"├ 💰 {balance}\n"
        f"├ 🍪 {len(active_cks)} cookie bật\n"
        f"├ ⏱ Delay: {dmin}-{dmax}s\n"
        f"└ 🎯 Mỗi cookie: {TONGJOB} job")

    loop = asyncio.get_event_loop()
    stats_lock = asyncio.Lock()   # Lock cho stats dùng chung

    # ── Reload job queue ──────────────────────────────
    async def auto_reload(type_job="like_facebook"):
        for _attempt in range(3):
            if stop_ev.is_set(): break
            try:
                res = await loop.run_in_executor(None, lambda: bx.reload(type_job))
            except: res = {}
            if res.get("cmt"):
                await loop.run_in_executor(None, lambda: bx.reload("like_poster"))
                break
            elif res.get("hetnv"):
                await asyncio.sleep(60); continue
            else:
                break
        if not stop_ev.is_set():
            try: await loop.run_in_executor(None, lambda: bx.reload("like_poster"))
            except: pass

    # ── Worker cho từng cookie ────────────────────────
    async def run_one_cookie(idx_acc, data_fb):
        if stop_ev.is_set(): return
        ck = data_fb.get("cookie",""); px = data_fb.get("proxy","")
        # Lấy BUMX object theo auth_idx của cookie
        auth_idx = data_fb.get("auth_idx", 0) % max(1, len(auths_all))
        bx_cur   = bx_map.get(auth_idx, bx)
        _ck = ck; _px = px; _bx = bx_cur
        fb = await loop.run_in_executor(None, lambda: FB(_ck, _px))
        if not fb.user_id:
            async with stats_lock:
                stats["cookie_block"] += 1; save_stats(uid, stats)
            await send(f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n⚠️ Cookie {idx_acc} lỗi — bỏ qua")
            return

        _fb_ref = fb
        name_fb = await loop.run_in_executor(None, lambda: _fb_ref.get_name())
        await send(f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n✅ L{idx_acc} Login: <b>{name_fb}</b> | UID: <code>{fb.user_id}</code>")
        _uid_fb = fb.user_id
        await loop.run_in_executor(None, lambda: bx.connect_account_fb(_uid_fb))
        await auto_reload("like_facebook")

        sonv = 0; no_job = 0
        while sonv < TONGJOB and not stop_ev.is_set():
            ck_ok = await loop.run_in_executor(None, fb.check_cookie)
            if not ck_ok:
                async with stats_lock:
                    stats["cookie_live"] -= 1; save_stats(uid, stats)
                # Xóa cookie bị die khỏi file lưu
                try:
                    _cks = load_cookies(uid)
                    _cks = [x for x in _cks if x.get("cookie","") != ck]
                    save_cookies(uid, _cks)
                except: pass
                await send(f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n💀 L{idx_acc} Cookie die — <b>{name_fb}</b> (đã xóa khỏi cấu hình)")
                return

            all_jobs = await loop.run_in_executor(None, bx.show_job)
            if not all_jobs:
                no_job += 1
                if no_job >= 3:
                    await send(f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\nL{idx_acc} 🔄 Queue trống — xin job...")
                    await auto_reload("like_facebook"); no_job = 0
                await asyncio.sleep(10); continue
            no_job = 0

            for job in all_jobs:
                if stop_ev.is_set() or sonv >= TONGJOB: break
                _job = job
                res_load = await loop.run_in_executor(None, lambda: _bx.show_single_job(_job))
                if not isinstance(res_load, dict) or not res_load.get("vaild_job"):
                    await loop.run_in_executor(None, lambda: bx.skip_job(_job))
                    async with stats_lock:
                        stats["job_block"] += 1; save_stats(uid, stats)
                    continue

                json_job = bx.format_json_job(_job, res_load); _jj = json_job
                delay_fb = random.randint(dmin, dmax); start_t = time.time()
                success  = await loop.run_in_executor(None, lambda: LAMJOB(fb, _jj))
                if success:
                    _jj2 = _jj
                    res_submit = await loop.run_in_executor(None, lambda: bx.submit_job(_jj2))
                    tien_nhan  = 0
                    if isinstance(res_submit, dict):
                        d = res_submit.get("data",{}) or {}
                        tien_nhan = d.get("price") or d.get("coin") or d.get("amount") or d.get("reward") or 0

                    type_job = _jj2.get("type_job","")
                    if _jj2.get("_fallback_comment"):
                        loai = "💬 COMMENT (fallback)"; detail = ""
                        if not tien_nhan: tien_nhan = 50
                    elif type_job == "like_poster":
                        loai = "💬 COMMENT"
                        txt_c = (_jj2.get("comment_msg","") or "")[:35]
                        detail = f"\n│ 📝 <i>{txt_c}</i>"
                        if not tien_nhan: tien_nhan = 50
                    elif type_job == "like_facebook":
                        react = _jj2.get("type_reaction","LIKE")
                        icon  = {"LIKE":"👍","LOVE":"❤️","CARE":"🥰","HAHA":"😂","WOW":"😮","SAD":"😢","ANGRY":"😡"}.get(react,"👍")
                        loai  = "😍 CẢM XÚC"; detail = f"\n│ {icon} <i>{react}</i>"
                        if not tien_nhan: tien_nhan = 20
                    else:
                        loai  = type_job.upper(); detail = ""
                        if not tien_nhan: tien_nhan = 20

                    sonv += 1
                    async with stats_lock:
                        stats["job_done"] += 1; stats["earned"] += tien_nhan
                        save_stats(uid, stats)
                    try: update_earnings(uid,"bumx",tien_nhan); deduct_api_fee(uid,tien_nhan,"vnd")
                    except: pass

                    await send(
                        f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n<b>[BUMX L{idx_acc}]</b> ✅ JOB {stats['job_done']} | {loai}{detail}\n"
                        f"│ 👤 <b>{name_fb}</b>\n"
                        f"│ 💰 ĐƯỢC CỘNG: <b>+{tien_nhan}₫</b>\n"
                        f"└ 💵 TỔNG PHIÊN: <b>{stats['earned']}₫</b>")
                    await loop.run_in_executor(None, lambda: _bx.reload("like_facebook"))
                    await asyncio.sleep(random.randint(amin, amax))
                    remain = max(0, delay_fb - (time.time()-start_t))
                    if remain > 0: await asyncio.sleep(remain)
                else:
                    async with stats_lock:
                        stats["job_block"] += 1; save_stats(uid, stats)
                    await loop.run_in_executor(None, lambda: _bx.skip_job(_jj))

        async with stats_lock:
            save_stats(uid, stats)

    # ── Chạy song song tối đa 10 cookie cùng lúc ──────
    # Dùng semaphore để giới hạn đúng 10 luồng
    sem = asyncio.Semaphore(MAX_LUONG)

    async def run_with_sem(idx, ck):
        async with sem:
            await run_one_cookie(idx, ck)

    tasks = [
        asyncio.create_task(run_with_sem(i+1, ck))
        for i, ck in enumerate(active_cks)
    ]
    running_tasks[uid] = tasks

    # Chờ tất cả hoàn thành
    await asyncio.gather(*tasks, return_exceptions=True)

    save_stats(uid, stats)
    await send(
        f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🏁 <b>HOÀN THÀNH TẤT CẢ</b>\n"
        f"✅ Tổng job: <b>{stats['job_done']}</b>\n"
        f"💵 Tổng kiếm: <b>{stats['earned']}₫</b>\n"
        f"🍪 Cookie live: <b>{stats['cookie_live']}/{stats['cookie_total']}</b>")
    running_tasks.pop(uid, None)
    stop_flags.pop(uid, None)


# ── Keyboards ────────────────────────────────────────
def _main_kb(uid):
    auths   = load_auth_list(uid)
    cookies = load_cookies(uid)
    auth_en = sum(1 for a in auths if a.get("enabled", True))
    ck_en   = sum(1 for c in cookies if c.get("enabled", True))
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🔑 Auth BUMX ({len(auths)}/10)",  callback_data="bumx_auth_menu"),
         InlineKeyboardButton(f"🍪 Cookie FB ({len(cookies)})",   callback_data="bumx_cookie_menu")],
        [InlineKeyboardButton("🛠 Cài đặt chạy",                  callback_data="bumx_settings")],
        [InlineKeyboardButton("▶️ Bắt đầu",                       callback_data="bumx_run"),
         InlineKeyboardButton("⏹ Dừng",                          callback_data="bumx_stop")],
        [InlineKeyboardButton("📊 Thống kê",                      callback_data="bumx_stats"),
         InlineKeyboardButton("📋 Xem cấu hình",                 callback_data="bumx_viewcfg")],
        [InlineKeyboardButton("🔙 Menu chính",                    callback_data="back_home")],
    ])

def _cookie_kb(uid):
    """Keyboard cookie FB — hiển thị tên + auth đang gán"""
    cookies = load_cookies(uid)
    auths   = load_auth_list(uid)
    rows    = []
    for i, ck in enumerate(cookies):
        enabled  = ck.get("enabled", True)
        name     = (ck.get("name","") or "").strip()
        fb_uid   = ck.get("fb_uid","")
        if not fb_uid and "c_user=" in ck.get("cookie",""):
            fb_uid = ck["cookie"].split("c_user=")[1].split(";")[0]
        _n     = name[:10] if name else f"...{(fb_uid or '')[-6:]}"
        # Hiển thị auth đang gán
        auth_idx = ck.get("auth_idx", 0)
        auth_lbl = f"A{auth_idx+1}" if auth_idx < len(auths) else "—"
        rows.append([
            InlineKeyboardButton(
                f"{'🟢' if enabled else '🔴'} {_n}",
                callback_data=f"bumx_ck_toggle_{i}"),
            InlineKeyboardButton(
                f"🔑{auth_lbl}",
                callback_data=f"bumx_ck_auth_{i}"),
            InlineKeyboardButton("🗑", callback_data=f"bumx_ck_del_{i}"),
        ])
    rows.append([InlineKeyboardButton("➕ Thêm Cookie FB", callback_data="bumx_ck_add")])
    rows.append([InlineKeyboardButton("🗑 Xóa tất cả", callback_data="bumx_ck_clear"),
                 InlineKeyboardButton("🔙 Quay lại",   callback_data="bumx_back_main")])
    return InlineKeyboardMarkup(rows)

def _auth_kb(uid):
    """Keyboard Auth BUMX — nút màu xanh/đỏ giống TDS"""
    auths = load_auth_list(uid)
    rows  = []
    for i, a in enumerate(auths):
        enabled = a.get("enabled", True)
        name    = (a.get("name","") or f"Auth {i+1}")[:18]
        # Lấy tên ngắn gọn để hiển thị
        _short = name[:22] if name else f"Auth {i+1}"
        rows.append([
            InlineKeyboardButton(
                f"{'🟢' if enabled else '🔴'} {i+1}. {_short}",
                callback_data=f"bumx_auth_toggle_{i}"),
            InlineKeyboardButton("🗑", callback_data=f"bumx_auth_del_{i}"),
        ])
    if len(auths) < MAX_BUMX_AUTH:
        rows.append([InlineKeyboardButton("➕ Thêm Auth BUMX", callback_data="bumx_auth_add")])
    rows.append([InlineKeyboardButton("🔙 Quay lại", callback_data="bumx_back_main")])
    return InlineKeyboardMarkup(rows)

async def _send_main(uid, app):
    cfg=load_config(uid); cookies=load_cookies(uid)
    status="✅ Đã cấu hình" if cfg.get("authorization") else "⚠️ Chưa cấu hình"
    is_run=uid in running_tasks and not running_tasks[uid].done()
    run_icon="🟢 Đang chạy" if is_run else "🔴 Dừng"
    try:
        await app.bot.send_message(chat_id=uid,
            text=f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n💸 <b>BUMX Auto Job</b>\n{run_icon} | {status} | 🍪 {len(cookies)} cookie",
            reply_markup=_main_kb(uid), parse_mode="HTML")
    except: pass

async def cmd_entry(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid=update.effective_user.id; cfg=load_config(uid); cookies=load_cookies(uid)
    status="✅ Đã cấu hình" if cfg.get("authorization") else "⚠️ Chưa cấu hình"
    is_run=uid in running_tasks and not running_tasks[uid].done()
    run_icon="🟢 Đang chạy" if is_run else "🔴 Dừng"
    text=f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n💸 <b>BUMX Auto Job</b>\n{run_icon} | {status} | 🍪 {len(cookies)} cookie"
    if update.callback_query:
        await update.callback_query.message.reply_text(text, reply_markup=_main_kb(uid), parse_mode="HTML")
    else:
        await update.message.reply_text(text, reply_markup=_main_kb(uid), parse_mode="HTML")

async def handle_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    query=update.callback_query; data=query.data
    if not (data.startswith("bumx_") or data=="bumx_back_main"): return False
    await query.answer()
    uid=query.from_user.id

    if data=="bumx_back_main":
        await cmd_entry(update,ctx); return True

    # ── AUTH BUMX MENU ──────────────────────────────────
    if data in ("bumx_auth", "bumx_auth_menu"):
        auths = load_auth_list(uid)
        en    = sum(1 for a in auths if a.get("enabled",True))
        await query.edit_message_text(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🔑 <b>Auth BUMX ({len(auths)}/{MAX_BUMX_AUTH})</b>\n"
            f"🟢 Đang bật: <b>{en}</b> | 🔴 Tắt: <b>{len(auths)-en}</b>\n"
            f"Nhấn nút để bật/tắt | 🗑 để xóa",
            reply_markup=_auth_kb(uid), parse_mode="HTML")
        return True

    if data == "bumx_auth_add":
        if len(load_auth_list(uid)) >= MAX_BUMX_AUTH:
            await query.answer(f"❌ Tối đa {MAX_BUMX_AUTH} auth!", show_alert=True); return True
        ctx.user_data["bumx_state"] = ST_ADD_AUTH
        await query.edit_message_text(
            "⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🔑 <b>Thêm Authorization BUMX</b>\n"
            "Gửi chuỗi Authorization từ bumx.vn:\n"
            "(F12 → Network → tìm request → copy header Authorization)",
            parse_mode="HTML")
        return True

    if data.startswith("bumx_auth_toggle_"):
        idx   = int(data.split("_")[-1])
        auths = load_auth_list(uid)
        if 0 <= idx < len(auths):
            auths[idx]["enabled"] = not auths[idx].get("enabled", True)
            save_auth_list(uid, auths)
        en = sum(1 for a in load_auth_list(uid) if a.get("enabled",True))
        await query.edit_message_text(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🔑 <b>Auth BUMX ({len(load_auth_list(uid))}/{MAX_BUMX_AUTH})</b> | 🟢 {en} bật",
            reply_markup=_auth_kb(uid), parse_mode="HTML")
        return True

    if data.startswith("bumx_auth_del_"):
        idx   = int(data.split("_")[-1])
        auths = load_auth_list(uid)
        if 0 <= idx < len(auths):
            auths.pop(idx); save_auth_list(uid, auths)
        en = sum(1 for a in load_auth_list(uid) if a.get("enabled",True))
        await query.edit_message_text(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🔑 <b>Auth BUMX ({len(load_auth_list(uid))}/{MAX_BUMX_AUTH})</b> | 🟢 {en} bật",
            reply_markup=_auth_kb(uid), parse_mode="HTML")
        return True

    # ── COOKIE FB MENU ───────────────────────────────────
    if data in ("bumx_cookie", "bumx_cookie_menu"):
        cookies = load_cookies(uid)
        en      = sum(1 for ck in cookies if ck.get("enabled",True))
        await query.edit_message_text(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🍪 <b>Cookie Facebook ({len(cookies)})</b>\n"
            f"🟢 Đang bật: <b>{en}</b> | 🔴 Tắt: <b>{len(cookies)-en}</b>\n"
            f"Nhấn nút để bật/tắt | 🗑 để xóa",
            reply_markup=_cookie_kb(uid), parse_mode="HTML")
        return True

    if data.startswith("bumx_ck_toggle_"):
        idx     = int(data.split("_")[-1])
        cookies = load_cookies(uid)
        if 0 <= idx < len(cookies):
            cookies[idx]["enabled"] = not cookies[idx].get("enabled", True)
            save_cookies(uid, cookies)
        cks2 = load_cookies(uid)
        en   = sum(1 for ck in cks2 if ck.get("enabled",True))
        await query.edit_message_text(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🍪 <b>Cookie Facebook ({len(cks2)})</b> | 🟢 {en} bật",
            reply_markup=_cookie_kb(uid), parse_mode="HTML")
        return True

    if data.startswith("bumx_ck_auth_"):
        idx     = int(data.split("_")[-1])
        auths   = load_auth_list(uid)
        if not auths:
            await query.answer("❌ Thêm Auth trước!", show_alert=True); return True
        cookies = load_cookies(uid)
        if not (0 <= idx < len(cookies)):
            await query.answer("❌ Cookie không tồn tại!", show_alert=True); return True
        ck      = cookies[idx]
        cur_idx = ck.get("auth_idx", 0)
        rows    = []
        tok_row = []
        for j, a in enumerate(auths):
            sel = "✅" if j == cur_idx else "⬜"
            tok_row.append(InlineKeyboardButton(
                f"{sel} A{j+1}", callback_data=f"bumx_ck_setauth_{idx}_{j}"))
            if len(tok_row) == 5:
                rows.append(tok_row); tok_row = []
        if tok_row: rows.append(tok_row)
        rows.append([InlineKeyboardButton("✅ Xong", callback_data="bumx_cookie_menu")])
        name = ck.get("name","?")
        await query.edit_message_text(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🔑 Chọn Auth BUMX cho cookie <b>{name}</b>:",
            reply_markup=InlineKeyboardMarkup(rows), parse_mode="HTML")
        return True

    if data.startswith("bumx_ck_setauth_"):
        parts   = data.split("_"); ck_idx = int(parts[-2]); auth_idx = int(parts[-1])
        cookies = load_cookies(uid)
        if 0 <= ck_idx < len(cookies):
            cookies[ck_idx]["auth_idx"] = auth_idx
            save_cookies(uid, cookies)
        await query.answer(f"✅ Đã gán Auth {auth_idx+1}!")
        # Refresh cookie menu
        cks2 = load_cookies(uid); en = sum(1 for ck in cks2 if ck.get("enabled",True))
        await query.edit_message_text(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🍪 <b>Cookie Facebook ({len(cks2)})</b> | 🟢 {en} bật",
            reply_markup=_cookie_kb(uid), parse_mode="HTML")
        return True

    if data.startswith("bumx_ck_del_"):
        idx     = int(data.split("_")[-1])
        cookies = load_cookies(uid)
        if 0 <= idx < len(cookies):
            cookies.pop(idx); save_cookies(uid, cookies)
        cks2 = load_cookies(uid)
        en   = sum(1 for ck in cks2 if ck.get("enabled",True))
        await query.edit_message_text(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🍪 <b>Cookie Facebook ({len(cks2)})</b> | 🟢 {en} bật",
            reply_markup=_cookie_kb(uid), parse_mode="HTML")
        return True

    if data == "bumx_ck_add":
        ctx.user_data["bumx_state"] = ST_ADD_COOKIE
        await query.edit_message_text(
            "⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🍪 <b>Thêm Cookie Facebook</b>\n"
            "Gửi cookie FB (chuỗi c_user=...;xs=...):",
            parse_mode="HTML")
        return True

    if data == "bumx_ck_clear":
        save_cookies(uid, [])
        await query.edit_message_text("⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🗑 Đã xóa tất cả cookie!")
        await _send_main(uid, ctx.application); return True

    if data=="bumx_settings":
        ctx.user_data["bumx_state"]=ST_TONGJOB
        cfg=load_config(uid)
        cur=f"\n\n📌 Hiện tại: {cfg.get('tongjob',10)} job/acc, delay {cfg.get('delay_min',5)}-{cfg.get('delay_max',15)}s" if cfg.get("tongjob") else ""
        await query.edit_message_text(f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n🔄 <b>[1/5] Số job rồi nghỉ/đổi acc:</b>{cur}\nVD: <code>10</code>",parse_mode="HTML")
        return True

    if data=="bumx_run":
        cfg=load_config(uid); cookies=[c for c in load_cookies(uid) if c.get("enabled",True)]
        if uid in running_tasks and not running_tasks[uid].done():
            await query.edit_message_text("⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n⚠️ Tool đang chạy rồi!"); return True
        auths_en = [a for a in load_auth_list(uid) if a.get("enabled",True)]
        if not auths_en and not cfg.get("authorization"):
            await query.edit_message_text(
                "⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n❌ Chưa có Auth BUMX bật!\nVào 🔑 Auth BUMX để thêm và bật."); return True
        if not cookies:
            await query.edit_message_text("⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n❌ Chưa có cookie bật!\nVào 🍪 Cookie để bật acc."); return True
        stop_ev=threading.Event(); stop_flags[uid]=stop_ev
        task=asyncio.create_task(worker(uid,ctx.application))
        running_tasks[uid]=task
        await query.edit_message_text(f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n✅ <b>BUMX đã khởi động!</b>\n🍪 {len(cookies)} cookie đang bật",parse_mode="HTML")
        return True

    if data=="bumx_stop":
        stopped = False
        # Set flag cho tất cả luồng
        if uid in stop_flags:
            stop_flags[uid].set(); stopped = True
        # Cancel tất cả tasks (list hoặc single Task)
        tasks = running_tasks.get(uid)
        if tasks:
            task_list = tasks if isinstance(tasks, list) else [tasks]
            for t in task_list:
                try:
                    if not t.done(): t.cancel()
                except: pass
            stopped = True
        running_tasks.pop(uid, None)
        stop_flags.pop(uid, None)
        await query.edit_message_text(
            "⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n⏹ <b>Đã dừng tất cả luồng BUMX!</b>" if stopped else "ℹ️ BUMX chưa chạy.",
            parse_mode="HTML")
        await _send_main(uid, ctx.application); return True

    if data=="bumx_stats":
        stats=load_stats(uid)
        _tasks_r = running_tasks.get(uid)
        is_run   = bool(_tasks_r and (
            any(not t.done() for t in _tasks_r) if isinstance(_tasks_r,list)
            else not _tasks_r.done()))
        if not stats: await query.edit_message_text("📭 Chưa có dữ liệu."); return True
        st="🟢 Đang chạy" if is_run else "🔴 Đã dừng"
        await query.edit_message_text(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n📊 <b>THỐNG KÊ BUMX</b> [{st}]\n"
            f"├ ⏰ {stats.get('started_at','N/A')}\n"
            f"├ ✅ Job: <b>{stats.get('job_done',0)}</b>\n"
            f"├ 💵 Kiếm: <b>{stats.get('earned',0)}₫</b>\n"
            f"├ 🍪 Cookie live: {stats.get('cookie_live',0)}/{stats.get('cookie_total',0)}\n"
            f"└ ❌ Block: cookie {stats.get('cookie_block',0)}, job {stats.get('job_block',0)}",
            parse_mode="HTML"); return True

    if data=="bumx_viewcfg":
        cfg=load_config(uid); cookies=load_cookies(uid)
        if not cfg: await query.edit_message_text("❌ Chưa có cấu hình."); return True
        auth_p=cfg["authorization"][:25]+"..." if cfg.get("authorization") else "Chưa có"
        await query.edit_message_text(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n📋 <b>CẤU HÌNH BUMX</b>\n"
            f"└ Auth: <code>{auth_p}</code>\n"
            f"└ Cookie: <b>{len(cookies)}</b> acc\n"
            f"└ Job/acc: <b>{cfg.get('tongjob',10)}</b>\n"
            f"└ Delay: <b>{cfg.get('delay_min',5)}-{cfg.get('delay_max',15)}s</b>",
            parse_mode="HTML"); return True

    return False

async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    uid=update.effective_user.id; text=update.message.text.strip()
    state=ctx.user_data.get("bumx_state")
    if not state: return False
    async def reply(msg, parse_mode="HTML", reply_markup=None):
        await update.message.reply_text(msg, parse_mode=parse_mode, reply_markup=reply_markup)

    # ── Thêm Auth BUMX mới ──────────────────────────────
    if state == ST_ADD_AUTH:
        auth_str = text.strip()
        if not auth_str: await reply("❌ Authorization rỗng!"); return True
        auths = load_auth_list(uid)
        if len(auths) >= MAX_BUMX_AUTH:
            await reply(f"❌ Đã đủ {MAX_BUMX_AUTH} auth!"); return True
        try:
            _bx  = BUMX(auth_str, "")
            bal  = _bx.get_wallet_balance()
            _bal_str = str(bal).replace("₫","").strip()[:10]
            name = f"Auth {len(auths)+1} ({_bal_str}₫)"
        except Exception as _e:
            name = f"Auth {len(auths)+1}"; bal = "?"
        auths.append({"auth": auth_str, "name": name, "enabled": True})
        save_auth_list(uid, auths)
        cfg = load_config(uid)
        if not cfg.get("authorization"):
            cfg["authorization"] = auth_str; save_config(uid, cfg)
        ctx.user_data.pop("bumx_state", None)
        await reply(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n✅ <b>Đã thêm Auth BUMX #{len(auths)}</b>\n"
            f"💰 Ví: <b>{bal}</b>\n"
            f"Trạng thái: 🟢 Đã bật (mặc định)")
        await _send_main(uid, ctx.application); return True

    # ── Thêm Cookie FB mới ───────────────────────────────
    if state == ST_ADD_COOKIE:
        cookie = text.strip()
        if "c_user=" not in cookie:
            await reply("❌ Cookie không hợp lệ! Cần có c_user=..."); return True
        fb_uid = cookie.split("c_user=")[1].split(";")[0]
        ctx.user_data["bumx_new_cookie"] = cookie
        ctx.user_data["bumx_ck_fb_uid"]  = fb_uid
        ctx.user_data["bumx_state"]       = ST_CKPROXY
        await reply(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n✅ Cookie OK | UID: <code>{fb_uid}</code>\n"
            f"🌐 Proxy? (bỏ qua gõ <code>skip</code>)", parse_mode="HTML")
        return True

    if state==ST_AUTH:
        ctx.user_data["bumx_new_auth"]=text; ctx.user_data["bumx_state"]=ST_AUTHPROXY
        await reply("🌐 Proxy BUMX (hoặc <code>-</code>):")
    elif state==ST_AUTHPROXY:
        proxy=text if text!="-" else ""
        cfg=load_config(uid); cfg["authorization"]=ctx.user_data.pop("bumx_new_auth",""); cfg["proxy_bumx"]=proxy
        if not cfg.get("tongjob"): cfg.update({"tongjob":10,"delay_min":5,"delay_max":15,"api_min":2,"api_max":5})
        try:
            b=BUMX(cfg["authorization"],proxy); balance=b.get_wallet_balance()
            cfg["balance"]=balance; msg_ok=f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n✅ Lưu auth OK!\n💰 Số dư: <b>{balance}</b>"
        except: msg_ok="⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n✅ Đã lưu auth"
        save_config(uid,cfg); ctx.user_data.pop("bumx_state",None)
        await reply(msg_ok); await _send_main(uid,ctx.application)
    elif state==ST_COOKIE:
        ctx.user_data["bumx_new_cookie"]=text; ctx.user_data["bumx_state"]=ST_CKPROXY
        await reply("🌐 Proxy cho cookie này (hoặc <code>-</code>):")
    elif state==ST_CKPROXY:
        proxy=text if text!="-" else ""; cookie=ctx.user_data.pop("bumx_new_cookie","")
        if "c_user=" not in cookie:
            ctx.user_data.pop("bumx_state",None); await reply("❌ Cookie không hợp lệ (thiếu c_user=)"); return True
        cookies=load_cookies(uid)
        fb_uid=cookie.split("c_user=")[1].split(";")[0]
        # Thử lấy tên Facebook ngay khi thêm cookie
        _fb_tmp = FB(cookie, proxy if proxy else None)
        fb_name = ""
        if _fb_tmp.user_id:
            try: fb_name = _fb_tmp.get_name()
            except: pass
        cookies.append({"cookie":cookie,"proxy":proxy,"enabled":True,
                        "fb_uid":fb_uid,"name":fb_name,
                        "added_at":datetime.now().strftime("%d/%m/%Y %H:%M")})
        save_cookies(uid,cookies); ctx.user_data.pop("bumx_state",None)
        name_display = fb_name if fb_name else fb_uid
        await reply(
            f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n✅ Thêm cookie OK!\n"
            f"👤 <b>{name_display}</b> | UID: <code>{fb_uid}</code>\n"
            f"📦 Tổng: <b>{len(cookies)}</b>")
        await _send_main(uid,ctx.application)
    elif state==ST_TONGJOB:
        try:
            v=int(text); assert v>0; ctx.user_data["bumx_tongjob"]=v; ctx.user_data["bumx_state"]=ST_DMIN
            await reply(f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n✅ Job/acc: <b>{v}</b>\n⏱ <b>[2/5] Delay MIN</b> (giây):")
        except: await reply("❌ Nhập số nguyên dương:")
    elif state==ST_DMIN:
        try:
            v=int(text); assert v>=0; ctx.user_data["bumx_dmin"]=v; ctx.user_data["bumx_state"]=ST_DMAX
            await reply(f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n✅ Delay min: <b>{v}s</b>\n⏱ <b>[3/5] Delay MAX</b>:")
        except: await reply("❌ Nhập số >= 0:")
    elif state==ST_DMAX:
        try:
            v=int(text); assert v>=ctx.user_data.get("bumx_dmin",0); ctx.user_data["bumx_dmax"]=v; ctx.user_data["bumx_state"]=ST_AMIN
            await reply(f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n✅ Delay max: <b>{v}s</b>\n🔌 <b>[4/5] API Delay MIN</b>:")
        except: await reply("❌ Phải >= delay min:")
    elif state==ST_AMIN:
        try:
            v=int(text); assert v>=0; ctx.user_data["bumx_amin"]=v; ctx.user_data["bumx_state"]=ST_AMAX
            await reply(f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n✅ API min: <b>{v}s</b>\n🔌 <b>[5/5] API Delay MAX</b>:")
        except: await reply("❌ Nhập số >= 0:")
    elif state==ST_AMAX:
        try:
            v=int(text); assert v>=ctx.user_data.get("bumx_amin",0)
            cfg=load_config(uid)
            cfg["tongjob"]=ctx.user_data.pop("bumx_tongjob",10)
            cfg["delay_min"]=ctx.user_data.pop("bumx_dmin",5)
            cfg["delay_max"]=ctx.user_data.pop("bumx_dmax",15)
            cfg["api_min"]=ctx.user_data.pop("bumx_amin",2)
            cfg["api_max"]=v
            save_config(uid,cfg); ctx.user_data.pop("bumx_state",None)
            await reply(
                f"⚡ TBTOOL ⚡\n━━━━━━━━━━━━━━━━━━━━\n✅ <b>Đã lưu cài đặt BUMX!</b>\n"
                f"├ Job/acc: {cfg['tongjob']}\n"
                f"├ Delay: {cfg['delay_min']}-{cfg['delay_max']}s\n"
                f"└ API: {cfg['api_min']}-{cfg['api_max']}s")
            await _send_main(uid,ctx.application)
        except: await reply("❌ Phải >= API min:")
    else:
        return False
    return True