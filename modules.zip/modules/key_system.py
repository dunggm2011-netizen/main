"""
key_system.py — Hệ thống Key VIP + API Key + Nạp tiền + Admin
Tích hợp vào Unified Multi-Bot
"""
import os, json, time, uuid, random, string, hashlib, base64, asyncio
from datetime import datetime, timedelta
from pathlib import Path
from telegram import (
    Update, InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardMarkup, KeyboardButton, InputMediaPhoto
)
from telegram.ext import ContextTypes

# ══════════════════════════════════════════════════════
#  CẤU HÌNH — ADMIN CHỈNH Ở ĐÂY
# ══════════════════════════════════════════════════════
MAIN_ADMIN_ID   = 0          # Telegram ID admin chính — PHẢI ĐẶT
MAIN_ADMIN_NAME = "@bomaylatop1"
_MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
_BASE_DIR   = os.path.dirname(_MODULE_DIR)
_DATA_SYS   = os.path.join(_BASE_DIR, "data", "system")
os.makedirs(_DATA_SYS, exist_ok=True)
SUB_ADMINS_FILE = os.path.join(_DATA_SYS, "sub_admins.json")

# Ngân hàng nhận tiền (admin chính có thể đổi)
BANK_CONFIG_FILE = os.path.join(_DATA_SYS, "bank_config.json")
DEFAULT_BANK = {
    "bank_name":    "Vietcombank",
    "account_no":   "1234567890",
    "account_name": "NGUYEN VAN A",
    "bin":          "970436",   # Mã BIN VCB cho QR
}

# Giá key VIP
KEY_PRICES = {
    "1day":   1_000,    # 1.000đ / ngày
    "1month": 25_000,   # 25.000đ / tháng
    "1year":  250_000,  # 250.000đ / năm
}
KEY_DAYS = {"1day": 1, "1month": 30, "1year": 365}

# Hoa hồng
REFERRAL_PCT   = 0.10   # 10% tiền nạp của người được giới thiệu
TOPUP_FEE_PCT  = 0.10   # API key trừ 10% thu nhập

# Đua top (tính theo đơn vị: đ hoặc xu)
TOP_BONUS_PCT  = {1: 0.05, 2: 0.03, 3: 0.02}
TOP_MIN_EARN   = 100_000        # Bumx: 100.000đ
TOP_MIN_XU     = 100_000_000      # TDS/TTC: 100 triệu xu

DATA_DIR = Path("data/system")
DATA_DIR.mkdir(parents=True, exist_ok=True)

# ══════════════════════════════════════════════════════
#  FILE HELPERS
# ══════════════════════════════════════════════════════
def _read(path, default=None):
    if default is None: default = {}
    p = Path(path)
    if not p.exists(): return default
    try:
        with open(p, "r", encoding="utf-8") as f: return json.load(f)
    except: return default

def _write(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

# ══════════════════════════════════════════════════════
#  ADMIN HELPERS
# ══════════════════════════════════════════════════════
def get_sub_admins() -> list:
    return _read(SUB_ADMINS_FILE, {"admins": []}).get("admins", [])

def is_admin(uid: int) -> bool:
    return uid == MAIN_ADMIN_ID or uid in get_sub_admins()

def is_main_admin(uid: int) -> bool:
    return uid == MAIN_ADMIN_ID

def get_bank() -> dict:
    return _read(BANK_CONFIG_FILE, DEFAULT_BANK)

def set_bank(data: dict):
    _write(BANK_CONFIG_FILE, data)

# ══════════════════════════════════════════════════════
#  USER DATA
# ══════════════════════════════════════════════════════
USERS_FILE = os.path.join(_DATA_SYS, "users.json")

def get_all_users() -> dict:
    return _read(USERS_FILE, {})

def get_user(uid: int) -> dict:
    users = get_all_users()
    key = str(uid)
    if key not in users:
        users[key] = {
            "uid": uid, "balance": 0, "api_balance": 0,
            "vip_key": None, "vip_expires": 0,
            "api_key": None, "api_key_active": False,
            "referral_by": None, "referral_code": _gen_ref_code(uid),
            "total_earned_bumx": 0,    # đ
            "total_earned_tds": 0,     # xu
            "total_earned_ttc": 0,     # xu
            "total_earned_xworld_build": 0.0,  # BUILD coin
            "total_earned_xworld_world": 0.0,  # WORLD coin
            "total_earned_xworld_usdt": 0.0,   # USDT
            "created_at": time.time(),
        }
        _write(USERS_FILE, users)
    return users[key]

def save_user(uid: int, data: dict):
    users = get_all_users()
    users[str(uid)] = data
    _write(USERS_FILE, users)

def _gen_ref_code(uid: int) -> str:
    return hashlib.md5(f"ref{uid}{time.time()}".encode()).hexdigest()[:8].upper()

# ══════════════════════════════════════════════════════
#  KEY VIP
# ══════════════════════════════════════════════════════
KEYS_FILE = "data/system/vip_keys.json"

def get_all_keys() -> dict:
    return _read(KEYS_FILE, {})

def _save_keys(data): _write(KEYS_FILE, data)

def create_vip_key(name: str, uid: int, days: int, reason: str = "", created_by: int = 0) -> str:
    keys = get_all_keys()
    key_str = f"VIP-{''.join(random.choices(string.ascii_uppercase+string.digits,k=4))}-{''.join(random.choices(string.ascii_uppercase+string.digits,k=4))}-{''.join(random.choices(string.ascii_uppercase+string.digits,k=4))}"
    keys[key_str] = {
        "name": name, "uid": uid, "days": days,
        "created_at": time.time(),
        "expires_at": time.time() + days * 86400,
        "reason": reason, "created_by": created_by,
        "used": False,
    }
    _save_keys(keys)
    return key_str

def activate_vip_key(uid: int, key_str: str) -> tuple:
    """Returns (ok, message)"""
    keys = get_all_keys()
    if key_str not in keys:
        return False, "❌ Key không tồn tại!"
    k = keys[key_str]
    if k["used"] and k["uid"] != uid:
        return False, "❌ Key đã được dùng bởi người khác!"
    if time.time() > k["expires_at"]:
        return False, "❌ Key đã hết hạn!"
    if k["uid"] not in (0, uid):
        return False, "❌ Key không thuộc về bạn!"
    # Kích hoạt
    user = get_user(uid)
    now = time.time()
    # Nếu còn key cũ, cộng thêm
    if user["vip_expires"] > now:
        user["vip_expires"] += k["days"] * 86400
    else:
        user["vip_expires"] = now + k["days"] * 86400
    user["vip_key"] = key_str
    save_user(uid, user)
    k["used"] = True; k["uid"] = uid
    _save_keys(keys)
    exp = datetime.fromtimestamp(user["vip_expires"]).strftime("%H:%M %d/%m/%Y")
    return True, f"✅ Kích hoạt thành công!\nKey VIP hết hạn lúc: <b>{exp}</b>"

def check_vip(uid: int) -> bool:
    user = get_user(uid)
    return user.get("vip_expires", 0) > time.time()

def delete_vip_key(key_str: str) -> bool:
    keys = get_all_keys()
    if key_str in keys:
        del keys[key_str]; _save_keys(keys); return True
    return False

# ══════════════════════════════════════════════════════
#  API KEY
# ══════════════════════════════════════════════════════
def generate_api_key(uid: int) -> str:
    user = get_user(uid)
    if not user.get("api_key"):
        user["api_key"] = f"TLAPI-{uid}-{''.join(random.choices(string.ascii_uppercase+string.digits,k=12))}"
        user["api_balance"] = 0
        user["api_key_active"] = False
        save_user(uid, user)
    return user["api_key"]

def get_api_balance(uid: int) -> float:
    return get_user(uid).get("api_balance", 0)

def deduct_api_fee(uid: int, earned: float, unit: str = "vnd") -> float:
    """
    Trừ phí API 10% thu nhập theo từng job riêng lẻ.
    unit='vnd'  : earned = đồng (BUMX)
    unit='xu'   : earned = xu (TDS/TTC); 1,000,000 xu → trừ 1k
    unit='xworld': earned = 1 lượt đặt = 10đ cố định
    Trả về số tiền thực trừ (đồng).
    Dừng hoạt động nếu hết tiền.
    """
    user = get_user(uid)
    if not user.get("api_key_active"): return 0
    if unit == "xu":
        # 1,000,000 xu = 1k → trừ 1k phí (10%)
        # Công thức: earned xu / 1,000,000 * 1k * 10% = fee
        # VD: 1,000,000 xu → fee = 1,000,000/1,000,000 * 1 * 0.1 = 0.1k? 
        # Theo yêu cầu: 1,000,000 xu → trừ 1k → fee_rate = 1k/1,000,000xu = 0.000001k/xu
        fee_vnd = (earned / 1_000_000) * 1_000  # 1triệu xu = 1k phí (100%)
    elif unit == "xworld":
        fee_vnd = 10 * TOPUP_FEE_PCT  # 10đ/lượt * 10% = 1đ/lượt
    else:
        fee_vnd = earned * TOPUP_FEE_PCT
    fee_vnd = round(fee_vnd, 2)
    if fee_vnd <= 0: return 0
    old_bal = user.get("api_balance", 0)
    user["api_balance"] = max(0, old_bal - fee_vnd)
    # Nếu hết tiền, tắt API key
    if user["api_balance"] <= 0:
        user["api_key_active"] = False
    save_user(uid, user)
    return fee_vnd

def check_and_stop_if_no_balance(uid: int) -> bool:
    """Kiểm tra và dừng nếu hết tiền/hết key. Returns True nếu nên dừng."""
    from . import key_system as ks
    user = get_user(uid)
    if is_admin(uid): return False  # Admin không bị dừng
    # Kiểm tra VIP
    if check_vip(uid): return False
    # Kiểm tra API
    ok, _ = can_use_api(uid)
    if ok: return False
    return True  # Không có quyền → dừng

def can_use_api(uid: int) -> tuple:
    """Returns (ok, reason)"""
    user = get_user(uid)
    if not user.get("api_key"): return False, "Chưa có API key"
    if not user.get("api_key_active"): return False, "API key chưa được kích hoạt"
    if user.get("api_balance", 0) <= 0: return False, "Số dư API = 0, cần nạp tiền"
    return True, ""

# ══════════════════════════════════════════════════════
#  NẠP TIỀN
# ══════════════════════════════════════════════════════
TOPUP_FILE = "data/system/topup_requests.json"

def get_topup_requests() -> dict:
    return _read(TOPUP_FILE, {})

def _save_topup(data): _write(TOPUP_FILE, data)

def create_topup_request(uid: int, amount: int) -> str:
    reqs = get_topup_requests()
    req_id = f"TOPUP-{uid}-{int(time.time())}"
    reqs[req_id] = {
        "uid": uid, "amount": amount,
        "status": "pending",   # pending / approved / rejected
        "created_at": time.time(),
        "screenshot": None,
        "reject_reason": None,
        "content": f"chuc may man song dai {uid}",
    }
    _save_topup(reqs)
    return req_id

def approve_topup(req_id: str, admin_id: int) -> tuple:
    reqs = get_topup_requests()
    if req_id not in reqs: return False, "Không tìm thấy yêu cầu"
    r = reqs[req_id]
    if r["status"] != "pending": return False, "Yêu cầu đã xử lý rồi"
    uid = r["uid"]; amount = r["amount"]
    # Cộng tiền
    user = get_user(uid)
    user["balance"] = user.get("balance", 0) + amount
    # Hoa hồng giới thiệu
    ref_uid = user.get("referral_by")
    bonus_msg = ""
    if ref_uid:
        ref_user = get_user(ref_uid)
        bonus = int(amount * REFERRAL_PCT)
        ref_user["balance"] = ref_user.get("balance", 0) + bonus
        save_user(ref_uid, ref_user)
        bonus_msg = f"\n💰 Giới thiệu viên (UID {ref_uid}) nhận +{bonus:,}đ hoa hồng"
    save_user(uid, user)
    r["status"] = "approved"; r["approved_by"] = admin_id; r["approved_at"] = time.time()
    _save_topup(reqs)
    return True, f"✅ Duyệt nạp {amount:,}đ cho UID {uid}{bonus_msg}"

def reject_topup(req_id: str, reason: str, admin_id: int) -> tuple:
    reqs = get_topup_requests()
    if req_id not in reqs: return False, "Không tìm thấy"
    r = reqs[req_id]
    r["status"] = "rejected"; r["reject_reason"] = reason
    r["rejected_by"] = admin_id; r["rejected_at"] = time.time()
    _save_topup(reqs)
    return True, "✅ Đã từ chối"

# ══════════════════════════════════════════════════════
#  QR CHUYỂN KHOẢN
# ══════════════════════════════════════════════════════
def generate_qr_url(amount: int, content: str, uid: int) -> str:
    bank = get_bank()
    # VietQR API: https://api.vietqr.io
    url = (f"https://api.vietqr.io/image/{bank['bin']}-{bank['account_no']}-compact2.jpg"
           f"?amount={amount}&addInfo={content.replace(' ','%20')}&accountName={bank['account_name'].replace(' ','%20')}")
    return url

# ══════════════════════════════════════════════════════
#  BẢNG XẾP HẠNG
# ══════════════════════════════════════════════════════
# XWorld thresholds
TOP_MIN_BUILD = 100_000    # 100.000 BUILD
TOP_MIN_WORLD = 100        # 100 WORLD
TOP_MIN_USDT  = 50         # 50 USDT

def get_leaderboard(tool: str = "all") -> list:
    """
    tool: 'bumx'|'tds'|'ttc'|'tds_ttc'|'xworld_build'|'xworld_world'|'xworld_usdt'|'all'
    Returns list of (uid, score, unit)
    """
    users = get_all_users()
    rows = []
    for uid_str, u in users.items():
        uid = int(uid_str)
        if tool == "bumx":
            score = u.get("total_earned_bumx", 0)
            if score >= TOP_MIN_EARN: rows.append((uid, score, "đ"))
        elif tool == "tds":
            score = u.get("total_earned_tds", 0)
            if score >= TOP_MIN_XU: rows.append((uid, score, "xu"))
        elif tool == "ttc":
            score = u.get("total_earned_ttc", 0)
            if score >= TOP_MIN_XU: rows.append((uid, score, "xu"))
        elif tool == "tds_ttc":
            # TDS + TTC chung 1 bảng
            score = u.get("total_earned_tds", 0) + u.get("total_earned_ttc", 0)
            if score >= TOP_MIN_XU: rows.append((uid, score, "xu"))
        elif tool == "xworld_build":
            score = u.get("total_earned_xworld_build", 0.0)
            if score >= TOP_MIN_BUILD: rows.append((uid, score, "BUILD"))
        elif tool == "xworld_world":
            score = u.get("total_earned_xworld_world", 0.0)
            if score >= TOP_MIN_WORLD: rows.append((uid, score, "WORLD"))
        elif tool == "xworld_usdt":
            score = u.get("total_earned_xworld_usdt", 0.0)
            if score >= TOP_MIN_USDT: rows.append((uid, score, "USDT"))
        else:
            # Tổng hợp: quy đổi về đ
            b   = u.get("total_earned_bumx", 0)
            tds = u.get("total_earned_tds", 0) / 1_000_000 * 10_000
            ttc = u.get("total_earned_ttc", 0) / 1_000_000 * 10_000
            score = b + tds + ttc
            rows.append((uid, round(score), "đ"))
    rows.sort(key=lambda x: x[1], reverse=True)
    return rows[:10]

def update_earnings(uid: int, tool: str, amount: float):
    """Cập nhật thu nhập tích lũy theo tool"""
    user = get_user(uid)
    if tool == "bumx":
        user["total_earned_bumx"] = user.get("total_earned_bumx", 0) + amount
    elif tool == "tds":
        user["total_earned_tds"] = user.get("total_earned_tds", 0) + amount
    elif tool == "ttc":
        user["total_earned_ttc"] = user.get("total_earned_ttc", 0) + amount
    elif tool == "xworld_build":
        user["total_earned_xworld_build"] = user.get("total_earned_xworld_build", 0.0) + amount
    elif tool == "xworld_world":
        user["total_earned_xworld_world"] = user.get("total_earned_xworld_world", 0.0) + amount
    elif tool == "xworld_usdt":
        user["total_earned_xworld_usdt"] = user.get("total_earned_xworld_usdt", 0.0) + amount
    save_user(uid, user)

# ══════════════════════════════════════════════════════
#  THÔNG BÁO (admin gửi, main admin duyệt)
# ══════════════════════════════════════════════════════
ANNOUNCE_FILE = "data/system/announcements.json"

def get_announcements() -> list:
    return _read(ANNOUNCE_FILE, {"list": []}).get("list", [])

def submit_announcement(admin_id: int, text: str) -> str:
    anns = get_announcements()
    ann_id = f"ANN-{int(time.time())}"
    anns.append({"id": ann_id, "from": admin_id, "text": text,
                 "status": "pending", "created_at": time.time()})
    _write(ANNOUNCE_FILE, {"list": anns})
    return ann_id

def approve_announcement(ann_id: str) -> tuple:
    data = _read(ANNOUNCE_FILE, {"list": []})
    for a in data["list"]:
        if a["id"] == ann_id:
            a["status"] = "approved"; _write(ANNOUNCE_FILE, data)
            return True, a["text"]
    return False, ""

# ══════════════════════════════════════════════════════
#  KIỂM TRA QUYỀN DÙNG BOT (vip / api key)
# ══════════════════════════════════════════════════════
def check_access(uid: int) -> tuple:
    """
    Returns (can_use, reason)
    can_use=True nếu:
      - Là admin, HOẶC
      - Có key VIP còn hạn, HOẶC
      - Có API key còn tiền
    """
    if is_admin(uid): return True, "admin"
    user = get_user(uid)
    if check_vip(uid): return True, "vip"
    ok, reason = can_use_api(uid)
    if ok: return True, "api"
    return False, reason

# ══════════════════════════════════════════════════════
#  FORMAT HELPERS
# ══════════════════════════════════════════════════════
def fmt_vip_status(uid: int) -> str:
    user = get_user(uid)
    exp = user.get("vip_expires", 0)
    if exp > time.time():
        d = datetime.fromtimestamp(exp)
        rem = (exp - time.time()) / 86400
        return f"👑 VIP còn <b>{rem:.1f} ngày</b> (hết {d.strftime('%d/%m/%Y')})"
    return "🔓 Chưa có VIP"

def fmt_api_status(uid: int) -> str:
    user = get_user(uid)
    if not user.get("api_key"):
        return "🔑 Chưa có API key"
    bal = user.get("api_balance", 0)
    active = user.get("api_key_active", False)
    status = "🟢 Bật" if active else "🔴 Tắt"
    return f"🔑 API key: {status} | Số dư: <b>{bal:,.1f}đ</b>"

def fmt_balance(uid: int) -> str:
    user = get_user(uid)
    bal = user.get("balance", 0)
    api_bal = user.get("api_balance", 0)
    return f"💰 Số dư ví: <b>{bal:,}đ</b>\n🔑 Số dư API: <b>{api_bal:,.1f}đ</b>"

# ══════════════════════════════════════════════════════
#  NỘI QUY
# ══════════════════════════════════════════════════════
RULES_TEXT = """📜 <b>NỘI QUY &amp; LƯU Ý</b>

━━━━━━━━━━━━━━━━━━
💳 <b>NẠP TIỀN</b>
• Nội dung CK: <code>chuc may man song dai [ID]</code>
• Gửi ảnh CK sau khi chuyển
• Admin duyệt trong <b>1-24h</b>
• Tối thiểu nạp: <b>1.000đ</b>
• Không hoàn tiền sau khi duyệt
• Hủy nạp phải có lý do + ảnh xác minh

━━━━━━━━━━━━━━━━━━
👑 <b>KEY VIP</b>
• 1 ngày: <b>1.000đ</b>
• 1 tháng: <b>25.000đ</b>
• 1 năm: <b>250.000đ</b>
• Key hết hạn → bot dừng hoạt động
• Liên hệ admin để mua key: @bomaylatop1

━━━━━━━━━━━━━━━━━━
🔑 <b>API KEY</b>
• Cần nạp tiền để dùng
• Phí: <b>10% thu nhập</b> mỗi job
  - BUMX: 10đ kiếm → trừ 1đ
  - TDS/TTC: 1.000.000 xu kiếm → trừ 1k
• Trừ <b>theo từng job riêng lẻ</b>
• Hết tiền → dừng toàn bộ hoạt động
• Không dùng API key đồng thời nhiều thiết bị

━━━━━━━━━━━━━━━━━━
👥 <b>GIỚI THIỆU BẠN BÈ</b>
• Bạn nhận <b>10%</b> mỗi lần bạn được giới thiệu nạp tiền
• Chia sẻ link: /reflink

━━━━━━━━━━━━━━━━━━
🏆 <b>ĐUA TOP CÀY</b>
• Top 1: +5% tổng thu nhập phiên
• Top 2: +3% tổng thu nhập phiên
• Top 3: +2% tổng thu nhập phiên
• Yêu cầu: BUMX ≥ 100.000đ | TDS/TTC ≥ 100,000,000,000 xu
• Thưởng được cộng vào ví cuối tuần"""

