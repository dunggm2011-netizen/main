#!/bin/bash
echo "=========================================="
echo "  CAI DAT UNIFIED MULTI-BOT (Termux)"
echo "=========================================="

pkg update -y && pkg upgrade -y
pkg install -y python

pip install python-telegram-bot==20.7 \
            requests \
            cloudscraper \
            PySocks \
            websocket-client \
            certifi \
            cryptography

echo ""
echo "=========================================="
echo "  CAI DAT XONG!"
echo "  Chay bot: cd /sdcard/Download && python main.py"
echo "=========================================="
