"""
key_handlers.py — Telegram handlers cho hệ thống Key/VIP/Nạp tiền/Admin
"""
import asyncio, time, io, requests
from datetime import datetime
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes
from .key_system import (
    MAIN_ADMIN_ID, MAIN_ADMIN_NAME, KEY_PRICES, KEY_DAYS,
    get_user, save_user, is_admin, is_main_admin,
    get_sub_admins, check_vip, check_access,
    create_vip_key, activate_vip_key, delete_vip_key, get_all_keys,
    generate_api_key, get_api_balance, can_use_api,
    create_topup_request, approve_topup, reject_topup, get_topup_requests,
    generate_qr_url, get_leaderboard, get_all_users,
    submit_announcement, approve_announcement, get_announcements,
    fmt_vip_status, fmt_api_status, fmt_balance,
    get_bank, set_bank, update_earnings, deduct_api_fee,
    check_and_stop_if_no_balance,
    RULES_TEXT, _write, _read,
)

# ── State keys ────────────────────────────────────────
ST_TOPUP_AMOUNT  = "ks_topup_amount"
ST_TOPUP_PHOTO   = "ks_topup_photo"
ST_TOPUP_REQ_ID  = "ks_topup_req_id"
ST_VIP_KEY_INPUT = "ks_vip_key_input"
ST_API_TOPUP_AMT = "ks_api_topup_amt"
ST_CANCEL_REASON = "ks_cancel_reason"
ST_CANCEL_REQ_ID = "ks_cancel_req_id"
ST_ADMIN_ANN     = "ks_admin_ann"
ST_ADMIN_KEY_NAME= "ks_admin_key_name"
ST_ADMIN_KEY_UID = "ks_admin_key_uid"
ST_ADMIN_KEY_DAYS= "ks_admin_key_days"
ST_ADMIN_KEY_RSN = "ks_admin_key_rsn"
ST_ADMIN_BANK    = "ks_admin_bank"
ST_ADMIN_ADD_SUB = "ks_admin_add_sub"
ST_REF_LINK      = "ks_ref_link"

# ── Keyboard helpers ──────────────────────────────────
def _key_menu_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("👑 Key VIP",      callback_data="ks_vip_menu"),
         InlineKeyboardButton("🔑 API Key",      callback_data="ks_api_menu")],
        [InlineKeyboardButton("💳 Nạp tiền",     callback_data="ks_topup_menu"),
         InlineKeyboardButton("💰 Số dư",        callback_data="ks_balance")],
        [InlineKeyboardButton("🏆 Bảng xếp hạng",callback_data="ks_leaderboard"),
         InlineKeyboardButton("📜 Nội quy",      callback_data="ks_rules")],
        [InlineKeyboardButton("👥 Giới thiệu",   callback_data="ks_reflink"),
         InlineKeyboardButton("📊 Thống kê",     callback_data="ks_stats")],
        [InlineKeyboardButton("🔙 Menu chính",   callback_data="back_home")],
    ])

def _vip_menu_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔓 Nhập Key VIP",    callback_data="ks_vip_enter"),
         InlineKeyboardButton("🛒 Mua Key VIP",     callback_data="ks_vip_buy")],
        [InlineKeyboardButton("📋 Trạng thái VIP",  callback_data="ks_vip_status")],
        [InlineKeyboardButton("🔙 Quay lại",        callback_data="ks_menu")],
    ])

def _api_menu_kb(uid):
    user = get_user(uid)
    active = user.get("api_key_active", False)
    toggle_text = "⏹ Tắt API key" if active else "▶️ Bật API key"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔑 Xem API key",     callback_data="ks_api_show")],
        [InlineKeyboardButton(toggle_text,           callback_data="ks_api_toggle")],
        [InlineKeyboardButton("💳 Nạp tiền API",    callback_data="ks_api_topup")],
        [InlineKeyboardButton("🔙 Quay lại",        callback_data="ks_menu")],
    ])

def _topup_menu_kb():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💳 Nạp tiền ví",     callback_data="ks_topup_start"),
         InlineKeyboardButton("📋 Lịch sử nạp",    callback_data="ks_topup_history")],
        [InlineKeyboardButton("❌ Hủy yêu cầu",    callback_data="ks_topup_cancel")],
        [InlineKeyboardButton("🔙 Quay lại",        callback_data="ks_menu")],
    ])

# ── /menu_key handler ─────────────────────────────────
async def cmd_key_menu(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    user = get_user(uid)
    text = (f"🔐 <b>QUẢN LÝ KEY &amp; TÀI KHOẢN</b>\n\n"
            f"{fmt_vip_status(uid)}\n"
            f"{fmt_api_status(uid)}\n"
            f"{fmt_balance(uid)}\n\n"
            f"🪪 ID của bạn: <code>{uid}</code>\n"
            f"🔑 API Key: <code>{user.get('api_key','Chưa có')}</code>\n"
            f"👥 Ref code: <code>{user.get('referral_code','')}</code>")
    if update.callback_query:
        await update.callback_query.message.reply_text(text, reply_markup=_key_menu_kb(), parse_mode="HTML")
    else:
        await update.message.reply_text(text, reply_markup=_key_menu_kb(), parse_mode="HTML")

# ── /huy ─────────────────────────────────────────────
async def cmd_huy(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Hủy bước đang làm"""
    keys_to_clear = [k for k in ctx.user_data if k.startswith("ks_")]
    for k in keys_to_clear: ctx.user_data.pop(k, None)
    await update.message.reply_text("❌ Đã hủy thao tác hiện tại.")

# ── Callback handler ──────────────────────────────────
async def handle_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    query = update.callback_query
    data  = query.data
    if not data.startswith("ks_"): return False
    await query.answer()
    uid = query.from_user.id

    # ── Menu chính ────────────────────────────────────
    if data == "ks_menu":
        await cmd_key_menu(update, ctx); return True

    # ── Số dư ─────────────────────────────────────────
    if data == "ks_balance":
        user = get_user(uid)
        await query.edit_message_text(
            f"💰 <b>SỐ DƯ TÀI KHOẢN</b>\n\n"
            f"💵 Ví chính: <b>{user.get('balance',0):,}đ</b>\n"
            f"🔑 Ví API: <b>{user.get('api_balance',0):,.1f}đ</b>\n\n"
            f"{fmt_vip_status(uid)}\n"
            f"{fmt_api_status(uid)}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","ks_menu")]]),
            parse_mode="HTML"); return True

    # ── VIP ───────────────────────────────────────────
    if data == "ks_vip_menu":
        await query.edit_message_text(
            f"👑 <b>KEY VIP</b>\n\n{fmt_vip_status(uid)}\n\n"
            f"💵 Giá key:\n• 1 ngày: <b>1.000đ</b>\n• 1 tháng: <b>25.000đ</b>\n• 1 năm: <b>250.000đ</b>\n\n"
            f"Liên hệ admin mua key: {MAIN_ADMIN_NAME}",
            reply_markup=_vip_menu_kb(), parse_mode="HTML"); return True

    if data == "ks_vip_enter":
        ctx.user_data[ST_VIP_KEY_INPUT] = True
        await query.edit_message_text(
            "🔓 <b>Nhập Key VIP</b>\n\nGửi key dạng <code>VIP-XXXX-XXXX-XXXX</code>\n(Gõ /huy để hủy)",
            parse_mode="HTML"); return True

    if data == "ks_vip_buy":
        await query.edit_message_text(
            f"🛒 <b>MUA KEY VIP</b>\n\n"
            f"• 1 ngày: <b>1.000đ</b>\n• 1 tháng: <b>25.000đ</b>\n• 1 năm: <b>250.000đ</b>\n\n"
            f"Liên hệ admin để mua:\n👤 {MAIN_ADMIN_NAME}\n\n"
            f"💡 Hoặc nạp tiền vào ví rồi dùng API key!",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","ks_vip_menu")]]),
            parse_mode="HTML"); return True

    if data == "ks_vip_status":
        exp = get_user(uid).get("vip_expires", 0)
        if exp > time.time():
            d = datetime.fromtimestamp(exp)
            rem = (exp - time.time()) / 86400
            text = f"👑 <b>VIP đang hoạt động</b>\nCòn: <b>{rem:.1f} ngày</b>\nHết hạn: {d.strftime('%d/%m/%Y %H:%M')}"
        else:
            text = "🔓 Bạn chưa có VIP hoặc đã hết hạn."
        await query.edit_message_text(text,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","ks_vip_menu")]]),
            parse_mode="HTML"); return True

    # ── API Key ───────────────────────────────────────
    if data == "ks_api_menu":
        api_key = generate_api_key(uid)
        await query.edit_message_text(
            f"🔑 <b>API KEY</b>\n\n{fmt_api_status(uid)}\n\n"
            f"Key của bạn:\n<code>{api_key}</code>\n\n"
            f"📌 Phí: 10% thu nhập mỗi job",
            reply_markup=_api_menu_kb(uid), parse_mode="HTML"); return True

    if data == "ks_api_show":
        api_key = generate_api_key(uid)
        await query.edit_message_text(
            f"🔑 API Key của bạn:\n\n<code>{api_key}</code>\n\n"
            f"{fmt_api_status(uid)}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","ks_api_menu")]]),
            parse_mode="HTML"); return True

    if data == "ks_api_toggle":
        user = get_user(uid)
        if not user.get("api_key"): generate_api_key(uid); user = get_user(uid)
        if not user.get("api_key_active") and user.get("api_balance", 0) <= 0:
            await query.edit_message_text(
                "❌ Số dư API = 0!\nNạp tiền trước khi bật API key.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("💳 Nạp tiền API","ks_api_topup")]]),
                parse_mode="HTML"); return True
        user["api_key_active"] = not user.get("api_key_active", False)
        save_user(uid, user)
        st = "🟢 BẬT" if user["api_key_active"] else "🔴 TẮT"
        await query.edit_message_text(
            f"🔑 API Key đã {st}\n\n{fmt_api_status(uid)}",
            reply_markup=_api_menu_kb(uid), parse_mode="HTML"); return True

    if data == "ks_api_topup":
        ctx.user_data[ST_API_TOPUP_AMT] = True
        await query.edit_message_text(
            "💳 <b>Nạp tiền vào ví API</b>\n\nNhập số tiền muốn nạp (VD: <code>10000</code>)\n(Gõ /huy để hủy)",
            parse_mode="HTML"); return True

    # ── Nạp tiền ──────────────────────────────────────
    if data == "ks_topup_menu":
        await query.edit_message_text(
            f"💳 <b>NẠP TIỀN</b>\n\n{fmt_balance(uid)}\n\n"
            "Admin duyệt trong <b>1-24h</b>",
            reply_markup=_topup_menu_kb(), parse_mode="HTML"); return True

    if data == "ks_topup_start":
        ctx.user_data[ST_TOPUP_AMOUNT] = True
        await query.edit_message_text(
            "💳 <b>Nạp tiền vào ví</b>\n\nNhập số tiền muốn nạp (tối thiểu 1.000đ)\nVD: <code>50000</code>\n\n(Gõ /huy để hủy)",
            parse_mode="HTML"); return True

    if data == "ks_topup_history":
        reqs = get_topup_requests()
        user_reqs = [(rid, r) for rid, r in reqs.items() if r["uid"] == uid]
        user_reqs.sort(key=lambda x: x[1]["created_at"], reverse=True)
        if not user_reqs:
            await query.edit_message_text("📋 Chưa có lịch sử nạp tiền.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","ks_topup_menu")]])); return True
        lines = ["📋 <b>LỊCH SỬ NẠP TIỀN</b>\n"]
        for rid, r in user_reqs[:10]:
            st_icon = {"pending":"⏳","approved":"✅","rejected":"❌"}.get(r["status"],"❓")
            d = datetime.fromtimestamp(r["created_at"]).strftime("%d/%m %H:%M")
            lines.append(f"{st_icon} <b>{r['amount']:,}đ</b> — {d}")
        await query.edit_message_text("\n".join(lines),
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","ks_topup_menu")]]),
            parse_mode="HTML"); return True

    if data == "ks_topup_cancel":
        reqs = get_topup_requests()
        pending = [(rid, r) for rid, r in reqs.items() if r["uid"] == uid and r["status"] == "pending"]
        if not pending:
            await query.edit_message_text("ℹ️ Không có yêu cầu nạp tiền đang chờ.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","ks_topup_menu")]])); return True
        rid, r = pending[-1]
        ctx.user_data[ST_CANCEL_REQ_ID] = rid
        ctx.user_data[ST_CANCEL_REASON] = True
        await query.edit_message_text(
            f"❌ <b>Hủy yêu cầu nạp {r['amount']:,}đ</b>\n\n"
            "Nhập lý do hủy và gửi kèm ảnh xác minh trong tin tiếp theo.\n(Gõ /huy để thoát)",
            parse_mode="HTML"); return True

    # ── Bảng xếp hạng ─────────────────────────────────
    if data == "ks_leaderboard":
        rows = get_leaderboard("all")
        medals = ["🥇","🥈","🥉","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"]
        lines = ["🏆 <b>BẢNG XẾP HẠNG TỔNG HỢP</b>\n"]
        for i, (xuid, score, unit) in enumerate(rows[:10]):
            m = medals[i] if i < len(medals) else f"{i+1}."
            bonus = ""
            if i < 3: bonus = f" (+{int(list([5,3,2])[i])}%)"
            lines.append(f"{m} UID {xuid}: <b>{score:,.0f}{unit}</b>{bonus}")
        if not rows: lines.append("Chưa có dữ liệu")
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("💸 BUMX",    callback_data="ks_lb_bumx"),
             InlineKeyboardButton("🔄 TDS+TTC", callback_data="ks_lb_tds_ttc")],
            [InlineKeyboardButton("🎮 XWorld BUILD", callback_data="ks_lb_xworld_build"),
             InlineKeyboardButton("🌍 XWorld WORLD", callback_data="ks_lb_xworld_world")],
            [InlineKeyboardButton("💵 XWorld USDT",  callback_data="ks_lb_xworld_usdt")],
            [InlineKeyboardButton("🔙 Quay lại", callback_data="ks_menu")],
        ])
        await query.edit_message_text("\n".join(lines), reply_markup=kb, parse_mode="HTML"); return True

    if data.startswith("ks_lb_"):
        tool = data.replace("ks_lb_","")
        rows = get_leaderboard(tool)
        medals = ["🥇","🥈","🥉","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"]
        title_map = {
            "bumx":"💸 BUMX","tds":"🔄 TDS","ttc":"🤝 TTC",
            "tds_ttc":"🔄 TDS + 🤝 TTC (chung)",
            "xworld_build":"🎮 XWorld BUILD","xworld_world":"🌍 XWorld WORLD",
            "xworld_usdt":"💵 XWorld USDT",
        }
        title = title_map.get(tool, tool.upper())
        lines = [f"🏆 <b>BẢNG XẾP HẠNG {title}</b>\n"]
        min_note = {
            "bumx": "Yêu cầu ≥ 100.000đ",
            "tds_ttc": "Yêu cầu ≥ 100,000,000,000 xu",
            "xworld_build": "Yêu cầu ≥ 100.000 BUILD",
            "xworld_world": "Yêu cầu ≥ 100 WORLD",
            "xworld_usdt": "Yêu cầu ≥ 50 USDT",
        }.get(tool, "")
        if min_note: lines.append(f"<i>({min_note})</i>\n")
        for i, (xuid, score, unit) in enumerate(rows[:10]):
            m = medals[i] if i < len(medals) else f"{i+1}."
            bonus = ""
            if i < 3: bonus = f" +{[5,3,2][i]}%"
            lines.append(f"{m} UID {xuid}: <b>{score:,.2f} {unit}</b>{bonus}")
        if not rows: lines.append("Chưa có dữ liệu hoặc chưa đủ điều kiện tối thiểu")
        await query.edit_message_text("\n".join(lines),
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại",callback_data="ks_leaderboard")]]),
            parse_mode="HTML"); return True

    # ── Nội quy ───────────────────────────────────────
    if data == "ks_rules":
        await query.edit_message_text(RULES_TEXT,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","ks_menu")]]),
            parse_mode="HTML"); return True

    # ── Giới thiệu ────────────────────────────────────
    if data == "ks_reflink":
        user = get_user(uid)
        ref_code = user.get("referral_code","")
        await query.edit_message_text(
            f"👥 <b>LINK GIỚI THIỆU</b>\n\n"
            f"Chia sẻ link này cho bạn bè:\n"
            f"<code>t.me/{ctx.bot.username}?start=ref_{ref_code}</code>\n\n"
            f"💰 Bạn nhận <b>10%</b> tiền nạp của mỗi người được giới thiệu!\n\n"
            f"Ref code của bạn: <code>{ref_code}</code>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","ks_menu")]]),
            parse_mode="HTML"); return True

    # ── Thống kê ──────────────────────────────────────
    if data == "ks_stats":
        user = get_user(uid)
        b = user.get("total_earned_bumx", 0)
        tds = user.get("total_earned_tds", 0)
        ttc = user.get("total_earned_ttc", 0)
        await query.edit_message_text(
            f"📊 <b>THỐNG KÊ CÁ NHÂN</b>\n\n"
            f"💸 BUMX tổng kiếm: <b>{b:,.0f}đ</b>\n"
            f"🔄 TDS tổng kiếm: <b>{tds:,.0f} xu</b>\n"
            f"🤝 TTC tổng kiếm: <b>{ttc:,.0f} xu</b>\n\n"
            f"━━━━━━━━━━\n"
            f"🌐 Thống kê chung tất cả users\n"
            f"Tổng user: <b>{len(get_all_users())}</b>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","ks_menu")]]),
            parse_mode="HTML"); return True

    return False

# ── Message handler ───────────────────────────────────
async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    uid = update.effective_user.id
    text = (update.message.text or "").strip()
    photo = update.message.photo

    # Nhập key VIP
    if ctx.user_data.get(ST_VIP_KEY_INPUT):
        ctx.user_data.pop(ST_VIP_KEY_INPUT)
        ok, msg = activate_vip_key(uid, text.upper())
        await update.message.reply_text(msg, parse_mode="HTML")
        if ok: await cmd_key_menu(update, ctx)
        return True

    # Nhập số tiền nạp vào ví chính
    if ctx.user_data.get(ST_TOPUP_AMOUNT):
        try:
            amount = int(text.replace(",","").replace(".",""))
            assert amount >= 1000
        except:
            await update.message.reply_text("❌ Số tiền tối thiểu 1.000đ. Nhập lại:"); return True
        ctx.user_data.pop(ST_TOPUP_AMOUNT)
        req_id = create_topup_request(uid, amount)
        ctx.user_data[ST_TOPUP_REQ_ID] = req_id
        ctx.user_data[ST_TOPUP_PHOTO] = True
        bank = get_bank()
        content = f"chuc may man song dai {uid}"
        qr_url = generate_qr_url(amount, content, uid)
        try:
            _qr1 = requests.get(qr_url, timeout=15); _qr1_b = io.BytesIO(_qr1.content); _qr1_b.name="qr.jpg"
        except: _qr1_b = qr_url
        try:
            await update.message.reply_photo(
                photo=_qr1_b,
                caption=(f"💳 <b>QR CHUYỂN KHOẢN</b>\n\n"
                         f"🏦 Ngân hàng: <b>{bank['bank_name']}</b>\n"
                         f"💳 Số TK: <code>{bank['account_no']}</code>\n"
                         f"👤 Chủ TK: <b>{bank['account_name']}</b>\n"
                         f"💰 Số tiền: <b>{amount:,}đ</b>\n"
                         f"📝 Nội dung: <code>{content}</code>\n\n"
                         f"⚠️ SAU KHI CHUYỂN gửi ảnh xác nhận vào đây!\n"
                         f"Admin duyệt trong 1-24h. Gõ /huy để hủy."),
                parse_mode="HTML"
            )
        except:
            await update.message.reply_text(
                f"💳 <b>THÔNG TIN CHUYỂN KHOẢN</b>\n\n"
                f"🏦 {bank['bank_name']} — <code>{bank['account_no']}</code>\n"
                f"👤 {bank['account_name']}\n"
                f"💰 {amount:,}đ\n"
                f"📝 Nội dung: <code>{content}</code>\n\n"
                f"Gửi ảnh xác nhận chuyển khoản.\n(Gõ /huy để hủy)",
                parse_mode="HTML")
        return True

    # Gửi ảnh xác nhận nạp tiền
    if ctx.user_data.get(ST_TOPUP_PHOTO):
        if not photo:
            await update.message.reply_text("⚠️ Vui lòng gửi ảnh chụp màn hình chuyển khoản!"); return True
        req_id = ctx.user_data.pop(ST_TOPUP_REQ_ID, None)
        ctx.user_data.pop(ST_TOPUP_PHOTO)
        reqs = _read("data/system/topup_requests.json", {})
        if req_id and req_id in reqs:
            reqs[req_id]["screenshot"] = photo[-1].file_id
            _write("data/system/topup_requests.json", reqs)
        # Thông báo admin
        r = reqs.get(req_id, {})
        try:
            await ctx.bot.send_photo(
                chat_id=MAIN_ADMIN_ID,
                photo=photo[-1].file_id,
                caption=(f"💳 <b>YÊU CẦU NẠP TIỀN MỚI</b>\n\n"
                         f"👤 UID: <code>{uid}</code>\n"
                         f"💰 Số tiền: <b>{r.get('amount',0):,}đ</b>\n"
                         f"🆔 Mã: <code>{req_id}</code>\n\n"
                         f"✅ Duyệt: /approve_{req_id}\n"
                         f"❌ Từ chối: /reject_{req_id}"),
                parse_mode="HTML"
            )
        except: pass
        await update.message.reply_text(
            "✅ <b>Đã gửi yêu cầu nạp tiền!</b>\nAdmin sẽ duyệt trong 1-24h.",
            parse_mode="HTML"); return True

    # Hủy yêu cầu nạp tiền (cần lý do + ảnh)
    if ctx.user_data.get(ST_CANCEL_REASON):
        req_id = ctx.user_data.get(ST_CANCEL_REQ_ID)
        if not photo:
            # Chờ ảnh
            ctx.user_data["ks_cancel_text"] = text
            await update.message.reply_text("📷 Gửi ảnh xác minh lý do hủy:"); return True
        reason = ctx.user_data.pop("ks_cancel_text", text)
        ctx.user_data.pop(ST_CANCEL_REASON); ctx.user_data.pop(ST_CANCEL_REQ_ID, None)
        ok, msg = reject_topup(req_id, f"User hủy: {reason}", uid)
        try:
            await ctx.bot.send_photo(
                chat_id=MAIN_ADMIN_ID, photo=photo[-1].file_id,
                caption=f"❌ User {uid} hủy nạp {req_id}\nLý do: {reason}", parse_mode="HTML")
        except: pass
        await update.message.reply_text("✅ Đã hủy yêu cầu nạp tiền."); return True

    # Nạp tiền vào ví API
    if ctx.user_data.get(ST_API_TOPUP_AMT):
        try:
            amount = int(text.replace(",","").replace(".",""))
            assert amount >= 1000
        except:
            await update.message.reply_text("❌ Tối thiểu 1.000đ:"); return True
        ctx.user_data.pop(ST_API_TOPUP_AMT)
        # Tạo yêu cầu nạp giống ví chính nhưng đánh dấu dành cho API
        req_id = create_topup_request(uid, amount)
        reqs = _read("data/system/topup_requests.json", {})
        reqs[req_id]["for_api"] = True
        _write("data/system/topup_requests.json", reqs)
        ctx.user_data[ST_TOPUP_REQ_ID] = req_id
        ctx.user_data[ST_TOPUP_PHOTO] = True
        bank = get_bank()
        content = f"chuc may man song dai {uid}"
        qr_url = generate_qr_url(amount, content, uid)
        try:
            _r = requests.get(qr_url, timeout=15)
            _qr = io.BytesIO(_r.content); _qr.name = "qr.jpg"
        except:
            _qr = qr_url
        try:
            await update.message.reply_photo(photo=_qr,
                    caption=(f"💳 <b>NẠP VÀO VÍ API</b>\n\n"
                             f"🏦 {bank['bank_name']} — <code>{bank['account_no']}</code>\n"
                             f"💰 {amount:,}đ\n📝 <code>{content}</code>\n\nGửi ảnh xác nhận!"),
                    parse_mode="HTML")
        except:
            await update.message.reply_text(
                f"💳 NẠP VÍ API: {amount:,}đ\n{bank['bank_name']} {bank['account_no']}\nNội dung: {content}\nGửi ảnh xác nhận!")
        return True

    return False

# ══════════════════════════════════════════════════════
#  ADMIN HANDLERS (lệnh /approve, /reject, v.v.)
# ══════════════════════════════════════════════════════
async def handle_admin_command(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    uid = update.effective_user.id
    if not is_admin(uid): return False
    text = update.message.text.strip()

    # /approve_TOPUP-xxx
    if text.startswith("/approve_"):
        req_id = text[9:]
        ok, msg = approve_topup(req_id, uid)
        await update.message.reply_text(msg if ok else f"❌ {msg}")
        if ok:
            reqs = _read("data/system/topup_requests.json", {})
            r = reqs.get(req_id, {})
            # Nếu nạp cho API thì cộng vào api_balance
            user_uid = r.get("uid")
            if r.get("for_api") and user_uid:
                u = get_user(user_uid)
                u["api_balance"] = u.get("api_balance", 0) + r.get("amount", 0)
                u["balance"] = max(0, u.get("balance", 0) - r.get("amount", 0))
                save_user(user_uid, u)
            try:
                await ctx.bot.send_message(chat_id=r.get("uid"),
                    text=f"✅ Yêu cầu nạp <b>{r.get('amount',0):,}đ</b> đã được duyệt!\n{fmt_balance(r.get('uid'))}",
                    parse_mode="HTML")
            except: pass
        return True

    # /reject_TOPUP-xxx
    if text.startswith("/reject_"):
        parts = text[8:].split(" ", 1)
        req_id = parts[0]
        reason = parts[1] if len(parts) > 1 else "Không hợp lệ"
        ok, msg = reject_topup(req_id, reason, uid)
        await update.message.reply_text(msg if ok else f"❌ {msg}")
        if ok:
            reqs = _read("data/system/topup_requests.json", {})
            r = reqs.get(req_id, {})
            try:
                await ctx.bot.send_message(chat_id=r.get("uid"),
                    text=f"❌ Yêu cầu nạp <b>{r.get('amount',0):,}đ</b> bị từ chối.\nLý do: {reason}",
                    parse_mode="HTML")
            except: pass
        return True

    # Chỉ main admin mới có quyền này:
    if not is_main_admin(uid): return False

    # /admin_panel
    if text == "/admin_panel":
        await show_admin_panel(update, ctx); return True

    return False

async def show_admin_panel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Thêm admin phụ",    callback_data="adm_add_sub"),
         InlineKeyboardButton("👥 Danh sách admin",   callback_data="adm_list_sub")],
        [InlineKeyboardButton("🔑 Tạo Key VIP",        callback_data="adm_create_key"),
         InlineKeyboardButton("🗑 Xóa Key VIP",        callback_data="adm_del_key")],
        [InlineKeyboardButton("🔍 Kiểm tra Key",       callback_data="adm_check_key"),
         InlineKeyboardButton("🔍 Kiểm tra API Key",   callback_data="adm_check_api")],
        [InlineKeyboardButton("🏦 Đổi tài khoản NH",  callback_data="adm_set_bank")],
        [InlineKeyboardButton("📢 Thông báo",          callback_data="adm_announce"),
         InlineKeyboardButton("📋 Duyệt thông báo",   callback_data="adm_approve_ann")],
        [InlineKeyboardButton("💳 Danh sách nạp tiền",callback_data="adm_topup_list")],
    ])
    pending = sum(1 for r in get_topup_requests().values() if r["status"]=="pending")
    await (update.message or update.callback_query.message).reply_text(
        f"🛡 <b>ADMIN PANEL</b>\n\n⏳ Nạp tiền chờ duyệt: <b>{pending}</b>",
        reply_markup=kb, parse_mode="HTML")

async def handle_admin_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    query = update.callback_query
    data  = query.data
    if not data.startswith("adm_"): return False
    uid = query.from_user.id
    if not is_main_admin(uid):
        await query.answer("⛔ Chỉ admin chính!"); return True
    await query.answer()

    if data == "adm_add_sub":
        ctx.user_data[ST_ADMIN_ADD_SUB] = True
        await query.edit_message_text("➕ Nhập Telegram ID admin phụ cần thêm:\n(Gõ /huy để hủy)"); return True

    if data == "adm_list_sub":
        subs = get_sub_admins()
        txt = "👥 <b>Danh sách admin phụ:</b>\n" + ("\n".join(f"• <code>{s}</code>" for s in subs) if subs else "Chưa có")
        await query.edit_message_text(txt,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","adm_back")]]),
            parse_mode="HTML"); return True

    if data == "adm_create_key":
        ctx.user_data[ST_ADMIN_KEY_NAME] = True
        await query.edit_message_text(
            "🔑 <b>Tạo Key VIP</b>\n\nBước 1/4: Nhập tên key (VD: <code>Key cho Nguyen Van A</code>):",
            parse_mode="HTML"); return True

    if data == "adm_del_key":
        keys = get_all_keys()
        if not keys:
            await query.edit_message_text("Không có key nào."); return True
        rows = []
        for k, v in list(keys.items())[:10]:
            exp = datetime.fromtimestamp(v["expires_at"]).strftime("%d/%m/%y")
            rows.append([InlineKeyboardButton(f"{k[:15]}… ({exp})", callback_data=f"adm_delk_{k}")])
        rows.append([InlineKeyboardButton("🔙 Quay lại","adm_back")])
        await query.edit_message_text("🗑 Chọn key để xóa:", reply_markup=InlineKeyboardMarkup(rows)); return True

    if data.startswith("adm_delk_"):
        key_str = data[9:]
        ok = delete_vip_key(key_str)
        await query.edit_message_text(f"{'✅ Đã xóa' if ok else '❌ Không tìm thấy'} key <code>{key_str}</code>",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","adm_del_key")]]),
            parse_mode="HTML"); return True

    if data == "adm_check_key":
        keys = get_all_keys()
        if not keys:
            await query.edit_message_text("Không có key nào."); return True
        lines = ["🔍 <b>DANH SÁCH KEY VIP</b>\n"]
        for k, v in list(keys.items())[:15]:
            exp = datetime.fromtimestamp(v["expires_at"]).strftime("%d/%m/%y %H:%M")
            used = "✅" if v.get("used") else "🆕"
            lines.append(f"{used} [{v.get('name','')}]\n   UID: {v.get('uid',0)} | Hết: {exp}\n   <code>{k}</code>")
        await query.edit_message_text("\n".join(lines),
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","adm_back")]]),
            parse_mode="HTML"); return True

    if data == "adm_check_api":
        users = get_all_users()
        lines = ["🔑 <b>DANH SÁCH API KEY</b>\n"]
        for uid_str, u in list(users.items())[:15]:
            if u.get("api_key"):
                act = "🟢" if u.get("api_key_active") else "🔴"
                bal = u.get("api_balance", 0)
                lines.append(f"{act} UID {uid_str}: <code>{u['api_key'][:20]}…</code> | {bal:,.1f}đ")
        if len(lines) == 1: lines.append("Chưa có ai dùng API key")
        await query.edit_message_text("\n".join(lines),
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","adm_back")]]),
            parse_mode="HTML"); return True

    if data == "adm_set_bank":
        ctx.user_data[ST_ADMIN_BANK] = "name"
        bank = get_bank()
        await query.edit_message_text(
            f"🏦 <b>Đổi thông tin ngân hàng</b>\n\nHiện tại:\n• NH: {bank['bank_name']}\n• STK: {bank['account_no']}\n• Tên: {bank['account_name']}\n\nNhập tên ngân hàng mới:",
            parse_mode="HTML"); return True

    if data == "adm_announce":
        ctx.user_data[ST_ADMIN_ANN] = True
        await query.edit_message_text("📢 Nhập nội dung thông báo gửi đến tất cả user:\n(Gõ /huy để hủy)"); return True

    if data == "adm_approve_ann":
        anns = [a for a in get_announcements() if a["status"] == "pending"]
        if not anns:
            await query.edit_message_text("Không có thông báo nào chờ duyệt."); return True
        rows = []
        for a in anns[-5:]:
            rows.append([InlineKeyboardButton(f"✅ Duyệt: {a['text'][:30]}…", callback_data=f"adm_appann_{a['id']}")])
        rows.append([InlineKeyboardButton("🔙 Quay lại","adm_back")])
        await query.edit_message_text("📋 Duyệt thông báo:", reply_markup=InlineKeyboardMarkup(rows)); return True

    if data.startswith("adm_appann_"):
        ann_id = data[11:]
        ok, text = approve_announcement(ann_id)
        if ok:
            users = get_all_users()
            sent = 0
            for uid_str in users:
                try:
                    await ctx.bot.send_message(chat_id=int(uid_str),
                        text=f"📢 <b>THÔNG BÁO</b>\n\n{text}", parse_mode="HTML")
                    sent += 1
                except: pass
            await query.edit_message_text(f"✅ Đã gửi thông báo đến {sent} user."); 
        else:
            await query.edit_message_text("❌ Không tìm thấy thông báo.")
        return True

    if data == "adm_topup_list":
        reqs = get_topup_requests()
        pending = [(rid, r) for rid, r in reqs.items() if r["status"]=="pending"]
        if not pending:
            await query.edit_message_text("Không có yêu cầu nạp tiền nào đang chờ.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","adm_back")]])); return True
        lines = [f"💳 <b>{len(pending)} yêu cầu đang chờ:</b>\n"]
        for rid, r in pending[-10:]:
            d = datetime.fromtimestamp(r["created_at"]).strftime("%d/%m %H:%M")
            lines.append(f"• UID {r['uid']} — <b>{r['amount']:,}đ</b> — {d}\n  /approve_{rid}")
        await query.edit_message_text("\n".join(lines),
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Quay lại","adm_back")]]),
            parse_mode="HTML"); return True

    if data == "adm_back":
        await show_admin_panel(update, ctx); return True

    return False

async def handle_admin_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    uid = update.effective_user.id
    if not is_main_admin(uid): return False
    text = (update.message.text or "").strip()

    if ctx.user_data.get(ST_ADMIN_ADD_SUB):
        ctx.user_data.pop(ST_ADMIN_ADD_SUB)
        try:
            sub_id = int(text)
            data = _read(ST_ADMIN_ADD_SUB.replace("ks_admin_add_sub","data/system/sub_admins.json"),{"admins":[]})
            data = _read("data/system/sub_admins.json",{"admins":[]})
            if sub_id not in data["admins"]: data["admins"].append(sub_id)
            _write("data/system/sub_admins.json", data)
            await update.message.reply_text(f"✅ Đã thêm admin phụ: <code>{sub_id}</code>", parse_mode="HTML")
        except:
            await update.message.reply_text("❌ ID không hợp lệ")
        return True

    # Tạo key VIP - bước theo bước
    if ctx.user_data.get(ST_ADMIN_KEY_NAME) is True:
        ctx.user_data[ST_ADMIN_KEY_NAME] = text
        ctx.user_data[ST_ADMIN_KEY_UID] = True
        await update.message.reply_text("Bước 2/4: Nhập Telegram ID người dùng (0 = bất kỳ ai):"); return True
    if ctx.user_data.get(ST_ADMIN_KEY_UID) is True:
        try: ctx.user_data[ST_ADMIN_KEY_UID] = int(text)
        except: await update.message.reply_text("❌ ID phải là số!"); return True
        ctx.user_data[ST_ADMIN_KEY_DAYS] = True
        await update.message.reply_text("Bước 3/4: Nhập số ngày hiệu lực (1/30/365):"); return True
    if ctx.user_data.get(ST_ADMIN_KEY_DAYS) is True:
        try:
            days = int(text); assert days > 0
            ctx.user_data[ST_ADMIN_KEY_DAYS] = days
            ctx.user_data[ST_ADMIN_KEY_RSN] = True
            await update.message.reply_text("Bước 4/4: Lý do tạo key (ghi chú):"); return True
        except:
            await update.message.reply_text("❌ Số ngày không hợp lệ!"); return True
    if ctx.user_data.get(ST_ADMIN_KEY_RSN) is True:
        name = ctx.user_data.pop(ST_ADMIN_KEY_NAME, "")
        target_uid = ctx.user_data.pop(ST_ADMIN_KEY_UID, 0)
        days = ctx.user_data.pop(ST_ADMIN_KEY_DAYS, 1)
        ctx.user_data.pop(ST_ADMIN_KEY_RSN)
        key_str = create_vip_key(name, target_uid, days, text, uid)
        exp = datetime.fromtimestamp(time.time() + days * 86400).strftime("%d/%m/%Y")
        await update.message.reply_text(
            f"✅ <b>Đã tạo Key VIP!</b>\n\n"
            f"🔑 Key: <code>{key_str}</code>\n"
            f"👤 Tên: {name}\n🪪 UID: {target_uid}\n"
            f"📅 {days} ngày (hết {exp})\n📝 {text}",
            parse_mode="HTML")
        if target_uid and target_uid != 0:
            try:
                await ctx.bot.send_message(chat_id=target_uid,
                    text=f"🎉 Bạn nhận được Key VIP!\n🔑 <code>{key_str}</code>\n"
                         f"📅 Hiệu lực {days} ngày\n\nNhập key: /key_menu → Key VIP → Nhập Key",
                    parse_mode="HTML")
            except: pass
        return True

    # Đổi ngân hàng
    if ctx.user_data.get(ST_ADMIN_BANK) == "name":
        ctx.user_data[ST_ADMIN_BANK] = {"bank_name": text}
        await update.message.reply_text("Nhập số tài khoản:"); return True
    if isinstance(ctx.user_data.get(ST_ADMIN_BANK), dict) and "bank_name" in ctx.user_data[ST_ADMIN_BANK] and "account_no" not in ctx.user_data[ST_ADMIN_BANK]:
        ctx.user_data[ST_ADMIN_BANK]["account_no"] = text
        await update.message.reply_text("Nhập tên chủ tài khoản:"); return True
    if isinstance(ctx.user_data.get(ST_ADMIN_BANK), dict) and "account_no" in ctx.user_data[ST_ADMIN_BANK] and "account_name" not in ctx.user_data[ST_ADMIN_BANK]:
        ctx.user_data[ST_ADMIN_BANK]["account_name"] = text
        await update.message.reply_text("Nhập mã BIN ngân hàng (VD: 970436 cho VCB):"); return True
    if isinstance(ctx.user_data.get(ST_ADMIN_BANK), dict) and "account_name" in ctx.user_data[ST_ADMIN_BANK] and "bin" not in ctx.user_data[ST_ADMIN_BANK]:
        ctx.user_data[ST_ADMIN_BANK]["bin"] = text
        bank_data = ctx.user_data.pop(ST_ADMIN_BANK)
        set_bank(bank_data)
        await update.message.reply_text(
            f"✅ Đã cập nhật ngân hàng:\n{bank_data['bank_name']} — {bank_data['account_no']} — {bank_data['account_name']}"); return True

    # Thông báo
    if ctx.user_data.get(ST_ADMIN_ANN):
        ctx.user_data.pop(ST_ADMIN_ANN)
        ann_id = submit_announcement(uid, text)
        # Main admin tự duyệt luôn
        ok, ann_text = approve_announcement(ann_id)
        if ok:
            users = get_all_users()
            sent = 0
            for uid_str in users:
                try:
                    await ctx.bot.send_message(chat_id=int(uid_str),
                        text=f"📢 <b>THÔNG BÁO</b>\n\n{ann_text}", parse_mode="HTML")
                    sent += 1; await asyncio.sleep(0.05)
                except: pass
            await update.message.reply_text(f"✅ Đã gửi thông báo đến {sent} user.")
        return True

    return False
