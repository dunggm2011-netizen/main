"""
Module: XWorld Multi-Game (SprintRun VTD + Vua Thoát Hiểm VTH)
Prefix callback: vtd_*, vth_coin_*, game_vtd, game_vth, main_menu, show_mycfg
"""

import asyncio
import io
import inspect
import json
import math
import os
import random
import secrets
import sys
import hashlib
import hmac
import threading
import time
import traceback
import logging
from collections import deque
from copy import deepcopy
from datetime import datetime
from urllib.parse import urlencode, urlparse, urlunparse, parse_qsl, parse_qs
from typing import Optional, Dict, Any, Tuple

import requests
import websocket
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes


logging.basicConfig(level=logging.WARNING, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

# ── Token (inject từ main.py) ──
BOT_TOKEN = ""

# ── Config dir ──
_MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
_BASE_DIR   = os.path.dirname(_MODULE_DIR)
CFG_DIR     = os.path.join(_BASE_DIR, "data", "xworld_configs")
os.makedirs(CFG_DIR, exist_ok=True)

# ── Bot reference (set bằng _bot_ref_setter) ──
_bot_ref = None

def _bot_ref_setter(app):
    global _bot_ref
    _bot_ref = app.bot


# ─────────────────────────────────────────────
#  LƯU / TẢI CẤU HÌNH
# ─────────────────────────────────────────────
def _cfg_path(uid: int) -> str:
    return os.path.join(CFG_DIR, f"user_{uid}.json")

def cfg_save(uid: int):
    try:
        sess = _all_sessions.get(uid)
        if not sess: return
        v = sess['vtd']; vh = sess['vth']
        data = {
            'game': sess.get('game'),
            'vtd': {
                'xw_uid': v['xw_uid'], 'xw_key': v['xw_key'],
                'Coin': v['Coin'], 'bet_amount0': v['bet_amount0'],
                'he_so': v['he_so'], 'type_bet': v['type_bet'], 'So_nv': v['So_nv'],
            },
            'vth': {k: vh['cfg'].get(k) for k in
                    ('user_id', 'user_secret_key', 'Coin', 'bet_amount0', 'heso', 'delay1', 'delay2')},
        }
        with open(_cfg_path(uid), 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[xworld cfg] Lỗi lưu {uid}: {e}")

def cfg_load(uid: int):
    path = _cfg_path(uid)
    if not os.path.exists(path): return False
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        sess = get_sess(uid)
        sess['game'] = data.get('game')
        vd = data.get('vtd', {}); v = sess['vtd']
        for k in ('xw_uid', 'xw_key', 'Coin', 'bet_amount0', 'he_so', 'type_bet', 'So_nv'):
            v[k] = vd.get(k)
        vh_data = data.get('vth', {})
        if any(vh_data.values()):
            sess['vth']['cfg'] = {k: v2 for k, v2 in vh_data.items() if v2 is not None}
        return True
    except Exception as e:
        print(f"[xworld cfg] Lỗi tải {uid}: {e}")
        return False

def cfg_load_all():
    loaded = 0
    for fname in os.listdir(CFG_DIR):
        if fname.startswith("user_") and fname.endswith(".json"):
            try:
                uid = int(fname[5:-5]); cfg_load(uid); loaded += 1
            except: pass
    print(f"[xworld] Đã tải {loaded} cấu hình user")


# ─────────────────────────────────────────────
#  HẰNG SỐ
# ─────────────────────────────────────────────
NV_VTD = {1: 'Bậc thầy tấn công', 2: 'Quyền sắt', 3: 'Thợ lặn sâu',
           4: 'Cơn lốc sân cỏ', 5: 'Hiếp sĩ phi nhanh', 6: 'Vua home run'}
ROOM_VTH = {1: 'Nhà kho', 2: 'Phòng họp', 3: 'Phòng Giám đốc',
            4: 'Phòng trò chuyện', 5: 'Phòng Giám sát', 6: 'Văn phòng',
            7: 'Phòng Tài Vụ', 8: 'Phòng Nhân sự'}


# ─────────────────────────────────────────────
#  HTTP ENGINE (SecureHTTP cho VTD)
# ─────────────────────────────────────────────
class DependencyManager:
    REQUIRED = {'pycurl': 'pycurl', 'certifi': 'certifi'}
    @staticmethod
    def check_and_install():
        import subprocess, importlib
        for mod, pkg in DependencyManager.REQUIRED.items():
            try:
                importlib.import_module(mod)
            except ImportError:
                try:
                    subprocess.check_call([sys.executable, "-m", "pip", "install", pkg, "--break-system-packages"],
                                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                except Exception as e:
                    print(f"[!] Lỗi cài {pkg}: {e}"); return False
        return True

class CryptoEngine:
    def __init__(self, key=None):
        self._key = key or secrets.token_bytes(32); self._nonce_cache = set()
    def generate_signature(self, *components):
        ts = int(time.time() * 1000); nonce = secrets.token_hex(16)
        msg = '|'.join(str(c) for c in components) + f'|{ts}|{nonce}'
        sig = hmac.new(self._key, msg.encode(), hashlib.sha256).hexdigest()
        return {'signature': sig, 'timestamp': ts, 'nonce': nonce}

class SecurityMonitor:
    def __init__(self):
        self._bad = ['hook', 'inject', 'monkey', 'patch', 'frida', 'mitmproxy',
                     'burp', 'intercept', 'debug', 'trace', 'mitm', 'charles', 'fiddler']
        self._base = set(sys.modules.keys()); self._cnt = 0
    def check_environment(self):
        for v in ['PYCHARM_HOSTED', 'VSCODE_CWD', 'DEBUGPY_PROCESS_ID']:
            if os.environ.get(v): return False, f'Env: {v}'
        self._cnt += 1
        if self._cnt % 10 == 0:
            for m in set(sys.modules.keys()) - self._base:
                if any(p in m.lower() for p in self._bad): return False, f'Module: {m}'
        return True, 'OK'
    def check_caller_stack(self, max_depth=10): return True, 'OK'

class SecureRequestEngine:
    def __init__(self):
        self._crypto = CryptoEngine(); self._monitor = SecurityMonitor()
        self._lock = threading.Lock(); self._initialized = False
    def initialize(self):
        with self._lock:
            if self._initialized: return True
            try:
                import pycurl, certifi
                self.pycurl = pycurl; self.certifi = certifi
                self._initialized = True; return True
            except Exception as e:
                print(f"[!] PyCURL lỗi: {e}"); return False
    def execute_request(self, config):
        ok, r = self._monitor.check_environment()
        if not ok: os._exit(1)
        if not self._initialized:
            if not self.initialize():
                return {"error": "PyCURL init fail", "status": 0, "body": b"", "headers": ""}
        url = config.get("url", ""); method = config.get("method", "GET").upper()
        headers = config.get("headers") or {}; cookies = config.get("cookies")
        params = config.get("params"); data = config.get("data")
        json_body = config.get("json"); proxy = config.get("proxy")
        timeout = config.get("timeout", 15); verify = config.get("verify", True)
        if params:
            p = urlparse(url); q = dict(parse_qsl(p.query)); q.update(params)
            url = urlunparse((p.scheme, p.netloc, p.path, p.params, urlencode(q, doseq=True), p.fragment))
        body_bytes = None
        if json_body is not None: body_bytes = json.dumps(json_body).encode()
        elif data:
            if isinstance(data, dict): body_bytes = urlencode(data, doseq=True).encode()
            elif isinstance(data, str): body_bytes = data.encode()
            elif isinstance(data, (bytes, bytearray)): body_bytes = bytes(data)
        hl = [f"{k}: {v}" for k, v in headers.items()]
        if cookies:
            cs = "; ".join(f"{k}={v}" for k, v in cookies.items()) if isinstance(cookies, dict) else str(cookies)
            hl.append(f"Cookie: {cs}")
        if body_bytes and not any(h.lower().startswith("content-type") for h in hl):
            hl.append("Content-Type: application/json" if json_body is not None else "Content-Type: application/x-www-form-urlencoded")
        buf = io.BytesIO(); hbuf = io.BytesIO(); c = self.pycurl.Curl()
        try:
            c.setopt(self.pycurl.URL, url); c.setopt(self.pycurl.WRITEFUNCTION, buf.write)
            c.setopt(self.pycurl.HEADERFUNCTION, hbuf.write); c.setopt(self.pycurl.TIMEOUT, int(timeout))
            c.setopt(self.pycurl.CONNECTTIMEOUT, int(timeout) // 2); c.setopt(self.pycurl.FOLLOWLOCATION, 1)
            c.setopt(self.pycurl.NOSIGNAL, 1)
            if verify: c.setopt(self.pycurl.CAINFO, self.certifi.where())
            else: c.setopt(self.pycurl.SSL_VERIFYPEER, 0); c.setopt(self.pycurl.SSL_VERIFYHOST, 0)
            if proxy: c.setopt(self.pycurl.PROXY, proxy)
            if method == "GET": c.setopt(self.pycurl.HTTPGET, 1)
            elif method == "POST":
                c.setopt(self.pycurl.POST, 1)
                if body_bytes: c.setopt(self.pycurl.POSTFIELDS, body_bytes)
            else:
                c.setopt(self.pycurl.CUSTOMREQUEST, method)
                if body_bytes: c.setopt(self.pycurl.POSTFIELDS, body_bytes)
            if hl: c.setopt(self.pycurl.HTTPHEADER, hl)
            c.perform()
            return {"status": c.getinfo(self.pycurl.RESPONSE_CODE), "body": buf.getvalue(),
                    "headers": hbuf.getvalue().decode("utf-8", "ignore"),
                    "url": c.getinfo(self.pycurl.EFFECTIVE_URL), "error": None}
        except Exception as e:
            return {"status": 0, "body": b"", "headers": "", "url": url, "error": str(e)}
        finally:
            for x in (c, buf, hbuf):
                try: x.close()
                except: pass

class SecureHTTP:
    _inst = None; _lock = threading.Lock()
    def __new__(cls):
        if cls._inst is None:
            with cls._lock:
                if cls._inst is None:
                    cls._inst = super().__new__(cls)
                    cls._inst._engine = SecureRequestEngine()
        return cls._inst
    def request(self, url, method='GET', **kw):
        return self._engine.execute_request({'url': url, 'method': method, **kw})
    def get(self, url, **kw): return self.request(url, 'GET', **kw)
    def post(self, url, **kw): return self.request(url, 'POST', **kw)

_http: Optional[SecureHTTP] = None
def get_http() -> SecureHTTP:
    global _http
    if _http is None: _http = SecureHTTP()
    return _http


# ─────────────────────────────────────────────
#  VTD - API FUNCTIONS
# ─────────────────────────────────────────────
def vtd_api_home(headers, Coin):
    r = get_http().get('https://api.sprintrun.win/sprint/home', params={'asset': Coin}, headers=headers)
    return json.loads(r['body'].decode('utf-8'))

def vtd_api_info(headers, ki, Coin):
    try:
        r = get_http().get('https://api.sprintrun.win/sprint/issue_result',
                           params={"issue": str(ki), "asset": Coin}, headers=headers)
        data = json.loads(r['body'].decode('utf-8'))
        if len(data["data"]["athlete_rank"]) > 0: return data
        return None
    except Exception as e:
        print(f"vtd_api_info lỗi: {e}"); time.sleep(2)
        return vtd_api_info(headers, ki, Coin)

def vtd_api_bet(headers, ki, kq, Coin, bet_amount, type_bet):
    try:
        get_http().post('https://api.sprintrun.win/sprint/bet', headers=headers,
                        json={"issue_id": int(ki), "bet_group": type_bet,
                              "asset_type": Coin, "athlete_id": kq, "bet_amount": bet_amount})
    except Exception as e:
        print(f"vtd_api_bet lỗi: {e}")

def vtd_api_asset(headers):
    try:
        r = get_http().post('https://wallet.3games.io/api/wallet/user_asset',
                            headers=headers, json={'user_id': int(headers['user-id']), 'source': 'home'})
        d = json.loads(r['body'].decode('utf-8'))
        return {k: d['data']['user_asset'][k] for k in ('USDT', 'WORLD', 'BUILD')}
    except Exception as e:
        print(f"vtd_api_asset lỗi: {e}"); time.sleep(2)
        return vtd_api_asset(headers)

def vtd_random_chon(so_nguoi):
    li = [1, 2, 3, 4, 5, 6]; kq = []
    for _ in range(int(so_nguoi)):
        x = random.choice(li); kq.append(x); li.remove(x)
    return kq

def vtd_make_headers(user_id_xw, secretkey):
    return {
        'accept': '*/*', 'accept-language': 'vi,en;q=0.9',
        'content-type': 'application/json', 'origin': 'https://sprintrun.win',
        'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',
        'user-id': str(user_id_xw), 'user-login': 'login_v2',
        'user-secret-key': secretkey
    }


# ─────────────────────────────────────────────
#  VTH - AI PREDICTOR
# ─────────────────────────────────────────────
class AIRoomPredictor:
    def __init__(self, memory_size=100, learning_rate=0.2, decay_rate=0.01):
        self.memory_size = memory_size; self.learning_rate = learning_rate; self.decay_rate = decay_rate
        self.q_table = {'bet_amount': [0.3]*8, 'user_count': [0.2]*8, 'history_safe': [0.25]*8,
                        'recent_killed': [0.25]*8, 'room_score': [0.0]*8}
        self.ai_history = deque(maxlen=memory_size)
        self.room_stats = {i: {'safe': 0, 'killed': 0, 'total': 0, 'last_safe': 0,
                               'consecutive_safe': 0, 'consecutive_killed': 0} for i in range(1, 9)}
        self.recent_choices = deque(maxlen=20)
        self.epsilon = 0.15; self.epsilon_decay = 0.995; self.epsilon_min = 0.05; self.gamma = 0.9

    def _normalize_minmax(self, values):
        if not values or all(v == values[0] for v in values): return [0.5]*len(values)
        mn, mx = min(values), max(values)
        return [0.5] if mx == mn else [(v - mn)/(mx - mn) for v in values]

    def _normalize_log(self, values):
        return self._normalize_minmax([math.log(1 + max(0, v)) for v in values])

    def _softmax_with_temperature(self, x, temperature=1.0):
        if not x or all(v == x[0] for v in x): return [0.125]*8
        temp = temperature*(1 + self.epsilon); max_x = max(x)
        e_x = [math.exp((v - max_x)/temp) for v in x]; s = sum(e_x)
        return [v/s for v in e_x] if s else [0.125]*8

    def extract_features(self, data, history_list):
        bet_amounts = [0.0]*8; user_counts = [0]*8
        for room in data.get('rooms', []):
            rid = room.get('room_id')
            if rid and 1 <= rid <= 8:
                bet_amounts[rid-1] = room.get('total_bet_amount', 0.0)
                user_counts[rid-1] = room.get('user_cnt', 0)
        features = {k: [0.0]*8 for k in ['bet_amount', 'user_count', 'history_safe', 'recent_killed', 'room_score']}
        features['bet_amount'] = [1-v for v in self._normalize_log(bet_amounts)]
        features['user_count'] = [1-v for v in self._normalize_log(user_counts)]
        if history_list:
            recent = list(history_list)[:min(20, len(history_list))]
            safe_counts = [0]*8; killed_counts = [0]*8; weighted_safe = [0.0]*8
            for i, entry in enumerate(recent):
                weight = 1.0/(i+1)
                if 'killed_room' in entry and 'my_room' in entry:
                    mr = entry.get('my_room', 0)-1; kir = entry['killed_room']-1
                    if 0 <= mr < 8 and not entry.get('thua', True):
                        safe_counts[mr] += 1; weighted_safe[mr] += weight
                    if 0 <= kir < 8: killed_counts[kir] += 1
            features['history_safe'] = (self._normalize_minmax(weighted_safe) if max(weighted_safe) > 0 else [0.5]*8)
            features['recent_killed'] = ([1-v for v in self._normalize_minmax(killed_counts)] if max(killed_counts) > 0 else [0.5]*8)
        for rid in range(1, 9):
            idx = rid-1; stat = self.room_stats[rid]
            if stat['total'] > 0:
                wr = stat['safe']/stat['total']
                sb = min(stat['consecutive_safe']*0.1, 0.3); sp = min(stat['consecutive_killed']*0.15, 0.4)
                tb = min(stat['last_safe']*0.02, 0.2)
                features['room_score'][idx] = max(0, min(1, wr+sb-sp+tb))
            else:
                features['room_score'][idx] = 0.5
        return features

    def _diversity_bonus(self, room_id):
        if not self.recent_choices: return 0.2
        cnt5 = list(self.recent_choices)[:5].count(room_id)
        if cnt5 >= 3: return -0.5
        if cnt5 >= 2: return -0.3
        cnt = self.recent_choices.count(room_id)
        if cnt >= 5: return -0.2
        if cnt >= 3: return -0.1
        return 0.1

    def predict_room(self, data, history_list):
        features = self.extract_features(data, history_list)
        q_values = [0.0]*8
        for fname, fvals in features.items():
            for i in range(8): q_values[i] += fvals[i]*self.q_table[fname][i]
        for i in range(8): q_values[i] += self._diversity_bonus(i+1)
        if random.random() < self.epsilon:
            ucnts = [r.get('user_cnt', 0) for r in data.get('rooms', [])]
            if ucnts:
                inv = [1.0/(c+1) for c in ucnts]; total = sum(inv); probs = [c/total for c in inv]
                chosen = random.choices(range(len(probs)), weights=probs)[0]+1
            else: chosen = random.randint(1, 8)
        else:
            noise = [random.uniform(-0.02, 0.02) for _ in range(8)]
            qn = [q_values[i]+noise[i] for i in range(8)]
            probs = self._softmax_with_temperature(qn, temperature=1.0)
            chosen = random.choices(range(8), weights=probs)[0]+1
        self.recent_choices.append(chosen)
        self.epsilon = max(self.epsilon_min, self.epsilon*self.epsilon_decay)
        return chosen

    def update_weights(self, data, history_list, chosen_room, result, killed_room):
        self.ai_history.append({'chosen_room': chosen_room, 'result': result, 'killed_room': killed_room})
        chosen_idx = chosen_room-1; killed_idx = killed_room-1
        stat = self.room_stats[chosen_room]; stat['total'] += 1
        if result:
            stat['safe'] += 1; stat['consecutive_safe'] += 1; stat['consecutive_killed'] = 0; stat['last_safe'] = 0
        else:
            stat['killed'] += 1; stat['consecutive_killed'] += 1; stat['consecutive_safe'] = 0
        for rid in range(1, 9):
            if rid != chosen_room: self.room_stats[rid]['last_safe'] += 1
        if killed_room in self.room_stats:
            self.room_stats[killed_room]['killed'] += 1; self.room_stats[killed_room]['last_safe'] = 0
        features = self.extract_features(data, history_list)
        reward = 1.0 if result else -1.0
        if result: reward += max(0, self._diversity_bonus(chosen_room))*0.5
        for fname in features:
            cq = self.q_table[fname][chosen_idx]; fv = features[fname][chosen_idx]
            mqf = max(self.q_table[fname]); td = reward+self.gamma*mqf-cq
            self.q_table[fname][chosen_idx] += self.learning_rate*td*fv
            for i in range(8):
                if i == chosen_idx: continue
                fv2 = features[fname][i]
                if i == killed_idx: self.q_table[fname][i] -= self.learning_rate*0.3*fv2
                elif result: self.q_table[fname][i] += self.learning_rate*0.1*fv2
            self.q_table[fname] = [max(-2.0, min(2.0, w)) for w in self.q_table[fname]]

    def get_stats(self):
        total = len(self.ai_history); wins = sum(1 for e in self.ai_history if e['result'])
        return {'win_rate': wins/total*100 if total > 0 else 0, 'learned': total, 'epsilon': self.epsilon}


# ─────────────────────────────────────────────
#  SESSION
# ─────────────────────────────────────────────
_sessions_lock = threading.Lock()
_all_sessions: Dict[int, Dict] = {}

def get_sess(uid: int) -> Dict:
    with _sessions_lock:
        if uid not in _all_sessions:
            _all_sessions[uid] = {
                'game': None,
                'vtd': {
                    'state': 'idle',
                    'xw_uid': None, 'xw_key': None, 'Coin': None,
                    'bet_amount0': None, 'he_so': None, 'type_bet': None, 'So_nv': None,
                    'running': False, 'thread': None,
                    'stats': {'win': 0, 'lose': 0, 'win_streak': 0, 'max_win_streak': 0,
                              'lose_streak': 0, 'max_lose_streak': 0, 'earn': 0.0},
                    'history': [],
                },
                'vth': {
                    'state': 'idle',
                    'cfg': {}, 'running': False, 'stop_event': threading.Event(),
                    '_notify_count': 0, '_notify_max': 7,
                    '_current_round': {},
                    '_observe_mode': True,   # Ván 1 = quan sát
                    '_last_killed_room': None,  # Phòng bị sát thủ ván trước
                    '_forced_room': None,  # Phòng bắt buộc đặt ván tiếp,
                    '_last_issue_id': -1,
                    'threads': [], 'lock': threading.Lock(), '_loop': None,
                    'ai_predictor': AIRoomPredictor(),
                    'history': deque(maxlen=50),
                    'last_game': {'data': None, 'my_room': 0},
                    'logs': deque(maxlen=30),
                    'asset': {'BUILD': 0.0, 'USDT': 0.0, 'WORLD': 0.0},
                    'lich_su': [],
                    'data_socket': {
                        'out_socket': True, 'asset_type': '', 'issue_id': 0,
                        'rooms': [], 'count_down': 9999, 'my_room': 0,
                        'my_bet_amount': -1, 'user_id': 0,
                        'tong_loi': 0.0, 'so_ki_win': 0, 'so_ki_thua': 0,
                        'streak': 0, 'max_streak': 0, 'lose_streak': 0,
                        'max_lose_streak': 0, 'start_issue_id': -1, 'tongsovan': 0
                    },
                },
            }
        return _all_sessions[uid]


# ─────────────────────────────────────────────
#  TELEGRAM HELPER
# ─────────────────────────────────────────────
# ── Rate limiter toàn cục cho tg_send ───────────────
_TG_SEND_LOCK   = {}   # {chat_id: last_send_time}
_TG_MIN_INTERVAL = 1.5  # Tối thiểu 1.5s giữa 2 tin cùng chat_id

def tg_send(chat_id: int, text: str, mk=None, md=None):
    """Gửi tin nhắn với rate limit tự động — tránh Flood control"""
    import time as _t
    global _TG_SEND_LOCK

    # ── Rate limit: chờ nếu gửi quá nhanh ──
    last = _TG_SEND_LOCK.get(chat_id, 0)
    wait = _TG_MIN_INTERVAL - (_t.time() - last)
    if wait > 0:
        _t.sleep(wait)
    _TG_SEND_LOCK[chat_id] = _t.time()

    payload = {"chat_id": chat_id, "text": text}
    if md: payload["parse_mode"] = md
    if mk: payload["reply_markup"] = json.dumps(mk)

    for attempt in range(3):  # Thử tối đa 3 lần
        try:
            r = requests.post(
                f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                json=payload, timeout=15)
            data = r.json()
            if not data.get("ok"):
                # Flood control → chờ đúng số giây rồi retry
                retry_after = data.get("parameters", {}).get("retry_after", 30)
                if "retry_after" in str(data):
                    print(f"[tg_send] Flood control — chờ {retry_after}s")
                    _t.sleep(retry_after)
                    continue
            _TG_SEND_LOCK[chat_id] = _t.time()
            return
        except Exception as e:
            print(f"[tg send] lỗi: {e}")
            if attempt < 2: _t.sleep(3)


# ─────────────────────────────────────────────
#  KEYBOARDS
# ─────────────────────────────────────────────
def vtd_kb():
    return {"inline_keyboard": [
        [{"text": "⚙️ Cấu hình link XWorld", "callback_data": "vtd_cfg_link"}],
        [{"text": "🎮 Cấu hình game", "callback_data": "vtd_cfg_game"},
         {"text": "📊 Thống kê", "callback_data": "vtd_stats"}],
        [{"text": "▶️ Chạy", "callback_data": "vtd_start"},
         {"text": "⏹ Dừng", "callback_data": "vtd_stop"}],
        [{"text": "🔄 Reset thống kê", "callback_data": "vtd_reset"},
         {"text": "🔙 Menu chính", "callback_data": "main_menu"}],
    ]}

def vtd_coin_kb():
    return {"inline_keyboard": [[
        {"text": "💵 USDT", "callback_data": "vtd_coin_USDT"},
        {"text": "🏗 BUILD", "callback_data": "vtd_coin_BUILD"},
        {"text": "🌍 WORLD", "callback_data": "vtd_coin_WORLD"},
    ]]}

def vtd_type_kb():
    return {"inline_keyboard": [
        [{"text": "🏆 Ai là quán quân (winner)", "callback_data": "vtd_type_winner"}],
        [{"text": "❌ Ai KHÔNG là quán quân", "callback_data": "vtd_type_not_winner"}],
    ]}


# ─────────────────────────────────────────────
#  VTD - BOT LOOP & HANDLERS
# ─────────────────────────────────────────────
def vtd_cfg_ok(v) -> list:
    miss = []
    if not v['xw_uid']: miss.append("Link XWorld")
    if not v['Coin']: miss.append("Loại coin")
    if not v['bet_amount0']: miss.append("Số tiền đặt")
    if not v['he_so']: miss.append("Hệ số nhân")
    if not v['type_bet']: miss.append("Loại cược")
    if not v['So_nv']: miss.append("Số người đặt")
    return miss

def vtd_bot_loop(uid: int, chat_id: int):
    """
    VTD SprintRun — Logic quan sát ván 1, đặt từ ván 2.
    Logic: Đặt vào người về CUỐI ván trước (người không WIN).
    Dừng ngay lập tức khi stop_event được set.
    """
    sess = get_sess(uid); v = sess['vtd']
    import threading as _thr

    # Reset stop_event khi bắt đầu (tạo event MỚI, sạch)
    new_ev = _thr.Event()
    v['stop_event'] = new_ev
    stop_ev = new_ev   # Giữ ref cục bộ — không bị thay thế

    hdrs   = vtd_make_headers(v['xw_uid'], v['xw_key'])
    Coin   = v['Coin']
    he_so  = float(v['he_so'] or 1)
    bet0   = float(v['bet_amount0'] or 0)
    stats  = v['stats']
    history = v['history']

    # Reset stats mỗi phiên
    for k in stats: stats[k] = 0 if isinstance(stats[k], int) else 0.0

    _van_count   = 0
    _bet_now     = bet0
    _last_bottom = None   # Người về CUỐI ván trước → đặt ván này
    _observing   = True   # Ván 1: quan sát
    _init_bal    = 0.0    # Số dư ban đầu để tính lời/lỗ tổng

    try:
        home = vtd_api_home(hdrs, Coin)
        if not home:
            tg_send(chat_id, "[VTD] ❌ Không kết nối được XWorld!")
            v['running'] = False; return
        _init_bal = home['data'].get('balance', 0)
    except Exception as e:
        tg_send(chat_id, f"[VTD] ❌ Lỗi kết nối: {e}")
        v['running'] = False; return

    tg_send(chat_id,
        f"[VTD] 🚀 *SprintRun Bot đã khởi động!*\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"🪙 Coin: `{Coin}`\n"
        f"💵 Mức cược ban đầu: `{bet0} {Coin}`\n"
        f"📈 Hệ số khi thua: `{he_so}x`\n"
        f"💼 Số dư ban đầu: `{_init_bal} {Coin}`\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"⚠️ *Lưu ý vốn:*\n"
        f"Bot có thể thua 3 ván liên tiếp!\n"
        f"Hệ số {he_so}x: Ván1=`{bet0}` → Ván2=`{bet0*he_so:.4f}` → Ván3=`{bet0*he_so*he_so:.4f}`\n"
        f"Cần vốn tối thiểu: `{bet0+bet0*he_so+bet0*he_so*he_so:.4f} {Coin}`\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"👁 *Ván 1: Quan sát — chưa đặt cược*",
        mk=vtd_kb(), md="Markdown")

    while v['running'] and not stop_ev.is_set():
        try:
            res = vtd_api_home(hdrs, Coin)
            if not res: stop_ev.wait(timeout=5); continue
            if not v['running'] or stop_ev.is_set(): break

            ki    = res['data']['issue_id']
            bal   = res['data'].get('balance', 0)
            left  = int(res['data'].get('expire_seconds', 0))
            total_earn = float(bal) - float(_init_bal)
            earn_ico   = "📈" if total_earn >= 0 else "📉"

            # ── VÁN 1: QUAN SÁT ──────────────────────────
            if _observing:
                tg_send(chat_id,
                    f"[VTD] 👁 *Ván quan sát — Kỳ #{ki}*\n"
                    f"💼 Số dư: `{bal} {Coin}`\n"
                    f"Đang theo dõi... Chưa đặt cược.",
                    md="Markdown")

                # Chờ kỳ kết thúc
                while v['running'] and not stop_ev.is_set():
                    r2   = vtd_api_home(hdrs, Coin)
                    if not r2: break
                    left = int(r2['data'].get('expire_seconds', 0))
                    if left <= 1: break
                    stop_ev.wait(timeout=min(max(left-1,1), 3))
                if not v['running'] or stop_ev.is_set(): break

                stop_ev.wait(timeout=8)
                if stop_ev.is_set(): break

                # Lấy kết quả ván quan sát
                re_end = vtd_api_info(hdrs, ki, Coin)
                if re_end:
                    ranks        = re_end['data'].get('athlete_rank', [])
                    if not ranks: continue
                    _last_bottom = ranks[-1]
                    tg_send(chat_id,
                        f"[VTD] 👁 *Kết quả quan sát — Kỳ #{ki}*\n"
                        f"🏆 Về nhất: `{ranks[0]}`\n"
                        f"💀 Về cuối (không WIN): `{_last_bottom}`\n"
                        f"➡️ *Ván tiếp: đặt `{_last_bottom}`*",
                        md="Markdown")
                    _observing = False
                continue

            # ── VÁN 2+: ĐẶT CƯỢC ────────────────────────
            if not _last_bottom or not v['running'] or stop_ev.is_set(): break

            _van_count += 1

            # Thông báo đặt cược
            tg_send(chat_id,
                f"[VTD] 🎯 *Kỳ #{ki} — Đặt cược ván {_van_count}*\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"🎯 Đặt vào: *Người {_last_bottom}* (về cuối ván trước)\n"
                f"💰 Cược: `{_bet_now:.6f} {Coin}`\n"
                f"💼 Số dư: `{bal} {Coin}`\n"
                f"{earn_ico} Tổng lời/lỗ: `{total_earn:+.6f} {Coin}`\n"
                f"📈 Hệ số cược: `{he_so}x`\n"
                f"🏅 W/L: `{stats['win']}/{stats['win']+stats['lose']}`\n"
                f"🔥 Chuỗi thắng: `{stats['win_streak']}` │ ❄️ Chuỗi thua: `{stats['lose_streak']}`\n"
                f"⏳ Đang chờ kết quả...",
                md="Markdown")

            # Đặt cược
            vtd_api_bet(hdrs, ki, _last_bottom, Coin, _bet_now, 'not_winner')

            # Chờ kỳ kết thúc
            while v['running'] and not stop_ev.is_set():
                r2   = vtd_api_home(hdrs, Coin)
                if not r2: break
                left = int(r2['data'].get('expire_seconds', 0))
                if left <= 1: break
                stop_ev.wait(timeout=min(left-1, 3))
            if not v['running'] or stop_ev.is_set(): break

            stop_ev.wait(timeout=5)
            if not v['running'] or stop_ev.is_set(): break

            # Lấy kết quả
            re_end = vtd_api_info(hdrs, ki, Coin)
            if not re_end: continue

            ranks    = re_end['data'].get('athlete_rank', [])
            if not ranks: continue
            top1     = ranks[0]
            bottom1  = ranks[-1]
            my_bet   = float(re_end['data'].get('my_total_bet', _bet_now))
            my_award = float(re_end['data'].get('my_total_award', 0))

            # Thắng = người đặt KHÔNG về nhất (đúng dự đoán)
            thang = (top1 != _last_bottom)

            if thang:
                stats['win'] += 1
                stats['win_streak'] += 1
                stats['max_win_streak'] = max(stats['max_win_streak'], stats['win_streak'])
                stats['lose_streak'] = 0
                _bet_now = bet0   # Reset về bet gốc
            else:
                stats['lose'] += 1
                stats['lose_streak'] += 1
                stats['max_lose_streak'] = max(stats['max_lose_streak'], stats['lose_streak'])
                stats['win_streak'] = 0
                _bet_now = round(_bet_now * he_so, 8)   # Tăng cược

            stats['earn'] += my_award - my_bet
            history.insert(0, {'kq': thang, 'my_total_bet': my_bet, 'my_total_award': my_award})
            if len(history) > 30: history.pop()

            # Người về cuối ván này → đặt ván tiếp
            _last_bottom = bottom1

            # Số dư mới
            new_home = vtd_api_home(hdrs, Coin)
            new_bal  = new_home['data'].get('balance', bal) if new_home else bal
            total_earn2 = float(new_bal) - float(_init_bal)
            earn2_ico   = "📈" if total_earn2 >= 0 else "📉"
            thu_nhap    = my_award - my_bet
            thu_ico     = "✅ +" if thu_nhap >= 0 else "❌ "
            total2 = stats['win'] + stats['lose']

            # Thông báo kết quả
            tg_send(chat_id,
                f"[VTD] {'✅ THẮNG' if thang else '❌ THUA'} — Kỳ #{ki}\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"🏆 Về nhất: `{top1}`\n"
                f"💀 Về cuối: `{bottom1}`\n"
                f"{thu_ico}{abs(thu_nhap):.6f} {Coin}\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"💼 Số dư: `{new_bal} {Coin}`\n"
                f"{earn2_ico} Tổng lời/lỗ: `{total_earn2:+.6f} {Coin}`\n"
                f"🏅 W/L: `{stats['win']}/{total2}` ({stats['win']/total2*100:.1f}%)\n"
                f"🔥 Chuỗi thắng: `{stats['win_streak']}` (Max: `{stats['max_win_streak']}`)\n"
                f"❄️ Chuỗi thua: `{stats['lose_streak']}` (Max: `{stats['max_lose_streak']}`)\n"
                f"{'💵 Bet tiếp: `' + f'{_bet_now:.6f} {Coin}` (×' + str(he_so) + ')' if not thang else '💵 Bet tiếp: `' + f'{_bet_now:.6f} {Coin}` (reset)'}\n"
                f"➡️ Ván tiếp: đặt `{_last_bottom}`",
                md="Markdown")

        except Exception as e:
            if v['running'] and not stop_ev.is_set():
                tg_send(chat_id, f"[VTD] ⚠️ Lỗi: {str(e)[:80]}, thử lại...")
            stop_ev.wait(timeout=10)

    # ── Tổng kết khi dừng ──
    v['running'] = False
    total = stats['win'] + stats['lose']
    wr    = stats['win']/total*100 if total > 0 else 0
    try:
        final_home = vtd_api_home(hdrs, Coin)
        final_bal  = final_home['data'].get('balance', 0) if final_home else 0
        final_earn = float(final_bal) - float(_init_bal)
    except:
        final_bal  = 0; final_earn = stats['earn']
    earn_ico = "📈" if final_earn >= 0 else "📉"
    tg_send(chat_id,
        f"[VTD] ⏹ *Đã dừng — {_van_count} ván*\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"🏅 W/L: `{stats['win']}/{total}` ({wr:.1f}%)\n"
        f"🔥 Chuỗi thắng max: `{stats['max_win_streak']}`\n"
        f"❄️ Chuỗi thua max: `{stats['max_lose_streak']}`\n"
        f"💼 Số dư ban đầu: `{_init_bal} {Coin}`\n"
        f"💼 Số dư cuối: `{final_bal} {Coin}`\n"
        f"{earn_ico} Tổng lời/lỗ: `{final_earn:+.6f} {Coin}`",
        mk=vtd_kb(), md="Markdown")


def vtd_handle_input(uid: int, chat_id: int, text: str):
    v = get_sess(uid)['vtd']; st = v['state']
    if st == 'wait_link':
        try:
            xw_uid = text.split('&')[0].split('?userId=')[1]
            xw_key = text.split('&')[1].split('secretKey=')[1]
            v['xw_uid'] = xw_uid; v['xw_key'] = xw_key; v['state'] = 'idle'; cfg_save(uid)
            tg_send(chat_id, f"[VTD] ✅ Đã lưu!\n👤 User ID: `{xw_uid}`\n🔑 Key: `{xw_key[:12]}...`", mk=vtd_kb(), md="Markdown")
        except:
            tg_send(chat_id, f"[VTD] ❌ Link sai định dạng! Cần: `...?userId=X&secretKey=Y`\nDán lại:", md="Markdown")
    elif st == 'wait_bet':
        try:
            bet_val = float(text); assert bet_val > 0
            v['bet_amount0'] = bet_val; v['state'] = 'wait_heso'
            tg_send(chat_id,
                f"[VTD] ✅ Tiền đặt: `{bet_val} {v['Coin']}`\n\n"
                f"📈 Nhập *hệ số nhân* sau thua (VD: `2`):\n\n"
                f"⚠️ *LƯU Ý QUAN TRỌNG VỀ VỐN:*\n"
                f"Bot theo logic *thua liên tiếp* nên ae chú ý:\n"
                f"• Chia vốn để chịu được ít nhất *3 ván thua liên tiếp*\n"
                f"• Hệ số `2x`: Ván 1→`{bet_val}`, Ván 2→`{bet_val*2}`, Ván 3→`{bet_val*4}` = tổng `{bet_val+bet_val*2+bet_val*4:.4f}`\n"
                f"• Hệ số `1.5x`: Ván 1→`{bet_val}`, Ván 2→`{bet_val*1.5:.4f}`, Ván 3→`{bet_val*2.25:.4f}` = tổng `{bet_val+bet_val*1.5+bet_val*2.25:.4f}`\n"
                f"✅ *80% không lỗ nếu vốn đủ 3 ván thua liên tiếp!*",
                md="Markdown")
        except: tg_send(chat_id, f"[VTD] ❌ Số không hợp lệ, nhập lại (VD: `1.5`):", md="Markdown")
    elif st == 'wait_heso':
        try:
            assert float(text) >= 1; v['he_so'] = float(text); v['state'] = 'wait_type'
            tg_send(chat_id, f"[VTD] ✅ Hệ số: `{float(text)}x`\n🎯 Chọn loại cược:", mk=vtd_type_kb(), md="Markdown")
        except: tg_send(chat_id, f"[VTD] ❌ Phải >= 1, nhập lại:", md="Markdown")
    elif st == 'wait_sonv':
        try:
            v2 = int(text); assert 1 <= v2 <= 6
            v['So_nv'] = v2; v['state'] = 'idle'; cfg_save(uid)
            tg_send(chat_id, f"[VTD] ✅ *Cấu hình VTD xong!*\n"
                    f"🪙 `{v['Coin']}` │ 💵 `{v['bet_amount0']}` │ 📈 `{v['he_so']}x`\n"
                    f"🎯 `{v['type_bet']}` │ 👥 `{v2}` người\n\nNhấn ▶️ Chạy!", mk=vtd_kb(), md="Markdown")
        except: tg_send(chat_id, f"[VTD] ❌ Nhập số từ 1-6:", md="Markdown")
    else:
        tg_send(chat_id, f"[VTD] Chọn menu:", mk=vtd_kb())

def vtd_handle_callback(uid: int, chat_id: int, data: str):
    v = get_sess(uid)['vtd']
    if data == 'vtd_cfg_link':
        v['state'] = 'wait_link'
        tg_send(chat_id, f"[VTD] 🔗 *Lấy link XWorld (SprintRun):*\n\n1. Vào `xworld.io` → Đăng nhập\n"
                "2. Nhấn *Chạy đua tốc độ*\n3. Nhấn *Lập tức truy cập*\n4. Copy link → Dán vào đây:",
                md="Markdown")
    elif data == 'vtd_cfg_game':
        if not v['xw_uid']:
            tg_send(chat_id, f"[VTD] ⚠️ Cấu hình link XWorld trước!", mk=vtd_kb()); return
        v['state'] = 'wait_coin'
        tg_send(chat_id, f"[VTD] 🪙 Chọn loại coin:", mk=vtd_coin_kb())
    elif data.startswith('vtd_coin_'):
        coin = data[9:]; v['Coin'] = coin; v['state'] = 'wait_bet'; cfg_save(uid)
        tg_send(chat_id, f"[VTD] ✅ Coin: `{coin}`\n💵 Nhập số đặt mỗi ván (VD: `1.5`):", md="Markdown")
    elif data.startswith('vtd_type_'):
        tbet = data[9:]; v['type_bet'] = tbet; v['state'] = 'wait_sonv'; cfg_save(uid)
        tg_send(chat_id, f"[VTD] ✅ Loại: `{tbet}`\n👥 Đặt vào bao nhiêu người? (1-6):", md="Markdown")
    elif data == 'vtd_start':
        if v['running']:
            tg_send(chat_id, f"[VTD] ⚠️ Đang chạy rồi!", mk=vtd_kb()); return
        miss = vtd_cfg_ok(v)
        if miss:
            tg_send(chat_id, f"[VTD] ⚠️ Thiếu:\n" + "\n".join(f"• {m}" for m in miss), mk=vtd_kb()); return
        v['running'] = True
        t = threading.Thread(target=vtd_bot_loop, args=(uid, chat_id), daemon=True)
        v['thread'] = t; t.start()
    elif data == 'vtd_stop':
        if v['running']:
            # 1. Set flag running = False
            v['running'] = False
            # 2. Set stop_event để thoát vòng while ngay
            ev = v.get('stop_event')
            if ev: ev.set()
            # 3. Tạo event mới cho lần chạy sau
            import threading as _thr2
            v['stop_event'] = _thr2.Event()
            tg_send(chat_id, "[VTD] ⏹ *Đã dừng VTD!*", mk=vtd_kb(), md="Markdown")
        else:
            tg_send(chat_id, "[VTD] ℹ️ VTD chưa chạy.", mk=vtd_kb())
    elif data == 'vtd_stats':
        s = v['stats']; total = s['win']+s['lose']; wr = s['win']/total*100 if total else 0
        earn_ico = "📈" if s['earn'] >= 0 else "📉"
        tg_send(chat_id, f"[VTD] 📊 *Thống kê SprintRun*\n────────────────────\n"
                f"🔄 {'▶️ Đang chạy' if v['running'] else '⏹ Dừng'} │ 🪙 `{v['Coin'] or '—'}`\n"
                f"🏅 Thắng: `{s['win']}/{total}` ({wr:.1f}%)\n"
                f"🔥 Chuỗi thắng: `{s['win_streak']}` (max `{s['max_win_streak']}`)\n"
                f"💔 Chuỗi thua: `{s['lose_streak']}` (max `{s['max_lose_streak']}`)\n"
                f"{earn_ico} Lời/Lỗ: `{s['earn']:+.8f} {v['Coin'] or ''}`",
                mk=vtd_kb(), md="Markdown")
    elif data == 'vtd_reset':
        v['stats'] = {'win': 0, 'lose': 0, 'win_streak': 0, 'max_win_streak': 0,
                      'lose_streak': 0, 'max_lose_streak': 0, 'earn': 0.0}
        v['history'] = []
        tg_send(chat_id, f"[VTD] ✅ Đã reset thống kê VTD!", mk=vtd_kb())


# ─────────────────────────────────────────────
#  VTH - BOT LOOP & HANDLERS
# ─────────────────────────────────────────────
def vth_notify(uid: int, text: str, force: bool = False):
    """
    Gửi thông báo VTH.
    force=True: luôn gửi (dùng cho thống kê tổng hợp và tin start/stop)
    force=False: chỉ gửi nếu chưa đạt giới hạn _notify_max
    """
    v = get_sess(uid)['vth']
    n_max = v.get('_notify_max', 7)
    n_cur = v.get('_notify_count', 0)
    if not force and n_cur >= n_max:
        return  # Đã đủ thông báo, im lặng
    if not force:
        v['_notify_count'] = n_cur + 1
    try:
        loop = v['_loop']
        if loop and loop.is_running():
            import time as _t

            async def _safe_send(uid=uid, text=text):
                """Gửi có xử lý RetryAfter"""
                from telegram.error import RetryAfter, TimedOut, NetworkError
                for _attempt in range(3):
                    try:
                        await _bot_ref.send_message(
                            chat_id=uid, text=text, parse_mode='Markdown')
                        return
                    except RetryAfter as e:
                        wait = e.retry_after + 1
                        vth_add_log(uid, f"Flood {wait}s — chờ rồi gửi lại")
                        import asyncio as _aio
                        await _aio.sleep(wait)
                    except (TimedOut, NetworkError):
                        import asyncio as _aio
                        await _aio.sleep(3)
                    except Exception:
                        return  # Lỗi khác → bỏ qua

            asyncio.run_coroutine_threadsafe(_safe_send(), loop)
    except Exception as e:
        print(f"[vth notify] {e}")

def vth_add_log(uid: int, msg: str):
    v = get_sess(uid)['vth']; ts = time.strftime('%H:%M:%S')
    with v['lock']: v['logs'].appendleft(f"[{ts}] {msg}")

def vth_headers(cfg: dict) -> dict:
    return {
        'accept': '*/*', 'accept-language': 'vi,en;q=0.9',
        'cache-control': 'no-cache', 'country-code': 'vn',
        'origin': 'https://xworld.info', 'referer': 'https://xworld.info/',
        'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36',
        'user-id': str(cfg.get('user_id', 0)), 'user-login': 'login_v2',
        'user-secret-key': cfg.get('user_secret_key', ''), 'xb-language': 'vi-VN',
    }

def vth_user_asset(uid: int):
    v = get_sess(uid)['vth']
    try:
        res = requests.post('https://wallet.3games.io/api/wallet/user_asset',
                            headers=vth_headers(v['cfg']),
                            json={'user_id': int(v['cfg']['user_id']), 'source': 'home'}).json()
        v['asset'] = {k: res['data']['user_asset'][k] for k in ('USDT', 'WORLD', 'BUILD')}
    except Exception as e:
        vth_add_log(uid, f'Lỗi lấy số dư: {e}')

def vth_enter_room(uid: int, room_id: int) -> bool:
    v = get_sess(uid)['vth']
    try:
        res = requests.post('https://api.escapemaster.net/escape_game/enter_room',
                            headers=vth_headers(v['cfg']),
                            json={'asset_type': v['cfg']['Coin'], 'user_id': int(v['cfg']['user_id']),
                                  'room_id': int(room_id)}).json()
        return res.get('code') == 0 and res.get('msg') == 'ok'
    except: return False

def vth_bet(uid: int, room_id: int, amount: float) -> bool:
    v = get_sess(uid)['vth']
    try:
        res = requests.post('https://api.escapemaster.net/escape_game/bet',
                            headers=vth_headers(v['cfg']),
                            json={'asset_type': v['cfg']['Coin'], 'user_id': int(v['cfg']['user_id']),
                                  'room_id': int(room_id), 'bet_amount': float(amount)}).json()
        ok = res.get('code') == 0 and res.get('msg') == 'ok'
        vth_add_log(uid, f"{'✓' if ok else '✗'} Đặt {amount} vào phòng {room_id}"); return ok
    except Exception as e:
        vth_add_log(uid, f'✗ Lỗi đặt cược: {e}'); return False

def vth_tinh_bet(uid: int) -> float:
    v = get_sess(uid)['vth']
    try:
        ls = sorted(v['lich_su'], key=lambda x: x['issue_id'], reverse=True)
        if ls and ls[0].get('enter_room_id') == ls[0].get('killed_room_id'):
            return v['cfg'].get('heso', 2)*ls[0]['bet_amount']
    except: pass
    return v['cfg'].get('bet_amount0', 1.0)

def vth_kiem_tra_delay(uid: int) -> bool:
    v = get_sess(uid)['vth']
    d1 = v['cfg'].get('delay1', 9999); d2 = v['cfg'].get('delay2', 0)
    if d1 >= 9999: return False
    total = v['data_socket']['tongsovan']
    return total > 0 and total % (d1+d2) >= d1

def vth_handle_result(uid: int, data: dict):
    """
    Xử lý kết quả mỗi ván VTH.
    Logic: Phòng bị sát thủ ván này → đặt vào phòng đó ván tiếp.
    """
    v    = get_sess(uid)['vth']
    ds   = v['data_socket']
    coin = v['cfg'].get('Coin', '?')
    init_bal = float(v['cfg'].get('_init_balance', 0))

    with v['lock']:
        ds['tongsovan'] += 1
        ds['my_bet_amount'] = 0   # Reset để đặt ván tiếp

    issue_id   = data.get('issue_id', 0)
    is_killed  = data.get('is_killed', True)   # True = phòng bạn bị sát thủ → THUA
    killed_room = data.get('killed_room', 0)
    rooms_data  = data.get('rooms', [])

    # Lấy tên phòng bị sát thủ
    killed_name = ROOM_VTH.get(killed_room, f'Phòng {killed_room}')
    my_room     = v['last_game'].get('my_room', 0)
    my_room_name = ROOM_VTH.get(my_room, f'Phòng {my_room}')

    # Số tiền thắng/thua — thử nhiều field API
    ud_result = data.get('user_data', {})
    my_bet   = float(data.get('my_bet_amount', 0)
                     or ud_result.get('bet_amount', 0) or 0)
    my_award = float(data.get('my_award_amount', 0)
                     or data.get('award_amount', 0)
                     or ud_result.get('award_amount', 0)
                     or ud_result.get('award', 0) or 0)
    # Nếu thắng mà award=0 → tính theo bet (thường award ≈ bet*0.95 ở VTH)
    if not data.get('is_killed', True) and my_award == 0 and my_bet > 0:
        my_award = round(my_bet * 0.95, 8)
    thu_nhap = my_award - my_bet

    # Cập nhật thống kê
    with v['lock']:
        if not is_killed:   # Thắng
            ds['so_ki_win'] += 1
            ds['streak'] = ds.get('streak', 0) + 1
            ds['lose_streak'] = 0
            ds['max_streak'] = max(ds.get('max_streak', 0), ds['streak'])
            # Reset bet về ban đầu
            v['cfg']['current_bet'] = float(v['cfg'].get('bet_amount0', 0))
        else:   # Thua
            ds['so_ki_thua'] += 1
            ds['lose_streak'] = ds.get('lose_streak', 0) + 1
            ds['streak'] = 0
            ds['max_lose_streak'] = max(ds.get('max_lose_streak', 0), ds['lose_streak'])
            # Tăng bet theo hệ số
            he_so = float(v['cfg'].get('heso', 1))
            cur   = float(v['cfg'].get('current_bet', v['cfg'].get('bet_amount0', 0)))
            v['cfg']['current_bet'] = round(cur * he_so, 8)

        ds['tong_loi'] = ds.get('tong_loi', 0.0) + thu_nhap

    # Cập nhật asset
    asset_data = data.get('user_data', {})
    if asset_data:
        v['asset'][coin] = float(asset_data.get('balance', v['asset'].get(coin, 0)))

    bal        = v['asset'].get(coin, 0)
    tong_loi   = ds.get('tong_loi', 0.0)
    loi_ico    = "📈" if tong_loi >= 0 else "📉"
    thu_ico    = "✅ +" if thu_nhap >= 0 else "❌ "
    win        = ds['so_ki_win']
    lose       = ds['so_ki_thua']
    total      = win + lose
    wr         = f'{win/total*100:.1f}%' if total > 0 else 'N/A'
    streak_txt = (f"🔥 Chuỗi thắng: `{ds['streak']}`"
                  if not is_killed else
                  f"❄️ Chuỗi thua: `{ds['lose_streak']}`")

    # ── Ghi log AI history ──
    v['history'].append({'killed_room': killed_room, 'is_killed': is_killed})
    # Lưu phòng bị sát thủ để ván tiếp đặt vào đó
    v['_forced_room']  = killed_room
    v['_observe_mode'] = False  # ← Quan trọng: tắt observe từ ván 2

    # ── Thông báo kết quả ──
    next_bet = float(v['cfg'].get('current_bet', v['cfg'].get('bet_amount0', 0)))
    he_so    = float(v['cfg'].get('heso', 1))

    vth_notify(uid,
        f"{'✅ THẮNG' if not is_killed else '❌ THUA'} — Kì #{issue_id}\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"🏠 Phòng bạn: *{my_room_name}* ({my_room})\n"
        f"💀 Phòng bị sát thủ: *{killed_name}* ({killed_room})\n"
        f"{thu_ico}{abs(thu_nhap):.4f} {coin}\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"💼 Số dư: `{bal:.4f} {coin}`\n"
        f"{loi_ico} Tổng lời/lỗ: `{tong_loi:+.4f} {coin}`\n"
        f"🏅 W/L: {win}W/{lose}L ({wr})\n"
        f"{streak_txt} (Max W:`{ds.get('max_streak',0)}` / Max L:`{ds.get('max_lose_streak',0)}`)\n"
        f"➡️ Ván tiếp: đặt *{killed_name}* | Bet: `{next_bet:.4f}`"
        + (f" (×{he_so})" if is_killed else " (reset)"),
        force=True)

    vth_add_log(uid,
        f"Kì #{issue_id}: {'WIN' if not is_killed else 'LOSE'} | "
        f"Sát thủ={killed_name} | Lời/lỗ={thu_nhap:+.4f} {coin}")


def vth_connect_socket(uid: int):
    """
    WebSocket kết nối VTH với các cải tiến:
    - Timeout 45s (đủ lớn cho server phản hồi)
    - Header đầy đủ gồm user-id + user-secret-key
    - Ping keepalive mỗi 20s
    - Reconnect tự động với backoff
    - Phân biệt lỗi có thể retry vs lỗi auth
    """
    v = get_sess(uid)['vth']
    url = "wss://api.escapemaster.net/escape_master/ws"
    _retry_count  = 0
    _MAX_RETRY    = 999   # Retry mãi khi còn running
    _last_err     = ""

    def _make_headers():
        cfg = v['cfg']
        return [
            f"user-id: {cfg.get('user_id', 0)}",
            f"user-secret-key: {cfg.get('user_secret_key', '')}",
            "Origin: https://xworld.info",
            "Referer: https://xworld.info/",
            "Accept-Language: vi,en-US;q=0.9,en;q=0.8",
            "user-login: login_v2",
            "country-code: vn",
            "xb-language: vi-VN",
            "User-Agent: Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36",
        ]

    def _send_enter(ws):
        payload = {
            'msg_type': 'handle_enter_game',
            'asset_type': v['cfg']['Coin'],
            'user_id': int(v['cfg']['user_id']),
            'user_secret_key': v['cfg']['user_secret_key'],
        }
        ws.send(json.dumps(payload))

    while not v['stop_event'].is_set():
        ws = None
        err_str = ""   # Reset mỗi vòng lặp
        try:
            # Dùng create_connection — tương thích mọi phiên bản websocket-client
            ws = websocket.create_connection(
                url,
                timeout=45,
                header=_make_headers(),
            )
            _send_enter(ws)
            vth_add_log(uid, '✅ WebSocket kết nối thành công!')
            with v['lock']:
                v['data_socket']['out_socket'] = False

            # Thông báo reconnect nếu trước đó bị lỗi
            if _retry_count > 0 and v.get('_ws_error_sent', False):
                v['_ws_error_sent'] = False
                vth_notify(uid,
                    f"✅ *VTH kết nối lại thành công!* (sau {_retry_count} lần thử)\n"
                    f"🪙 {v['cfg'].get('Coin','?')} │ Bot tiếp tục chạy.",
                    force=True)
            _retry_count = 0   # Reset counter sau khi kết nối thành công
            _last_err = ""
            err_str = ""       # Đảm bảo không trigger reconnect sau vòng thành công

            # ── Vòng nhận message chính ──────────────────
            _ping_ts = time.time()
            while not v['stop_event'].is_set():
                # Ping keepalive mỗi 20s
                if time.time() - _ping_ts > 20:
                    try:
                        ws.ping()
                        _ping_ts = time.time()
                    except Exception:
                        vth_add_log(uid, "Ping thất bại — reconnect")
                        break  # Mất kết nối → reconnect

                try:
                    ws.settimeout(5)
                    msg = ws.recv()
                except websocket.WebSocketTimeoutException:
                    # Không có message trong 5s → bình thường, tiếp tục
                    continue
                except Exception:
                    break  # Lỗi thật sự → reconnect

                if not msg: continue
                try:
                    data = json.loads(msg)
                except Exception:
                    continue
                if 'msg_type' not in data: continue

                if v['data_socket']['start_issue_id'] == -1:
                    v['data_socket']['start_issue_id'] = data.get('issue_id', -1)

                mt = data['msg_type']
                if mt == 'notify_issue_stat':
                    issue_id = data.get('issue_id', 0)
                    # Dedup: chỉ xử lý 1 lần mỗi kì
                    if issue_id == v.get('_last_issue_id', -1):
                        continue
                    v['_last_issue_id'] = issue_id

                    v['last_game']['data'] = data
                    coin    = v['cfg'].get('Coin', '?')
                    bet_amt = vth_tinh_bet(uid)
                    ud      = data.get('user_data', {})

                    # ── VÁN 1: QUAN SÁT — KHÔNG ĐẶT CƯỢC ──
                    if v.get('_observe_mode', True):
                        bal_obs = v['asset'].get(coin, 0)
                        bet0_obs = float(v['cfg'].get('bet_amount0', 0))
                        he_so_obs = float(v['cfg'].get('heso', 1))
                        vth_add_log(uid, f"Kì #{issue_id}: [QUAN SÁT] Ván 1 — chờ phòng bị sát thủ")
                        vth_notify(uid,
                            f"👁 *Kì #{issue_id} — Ván quan sát*\n"
                            f"━━━━━━━━━━━━━━━━━━━\n"
                            f"Chưa đặt cược — đang theo dõi\n"
                            f"━━━━━━━━━━━━━━━━━━━\n"
                            f"💼 Số dư: `{bal_obs:.4f} {coin}`\n"
                            f"💵 Mức cược ban đầu: `{bet0_obs} {coin}`\n"
                            f"📈 Hệ số khi thua: `{he_so_obs}x`\n"
                            f"⚠️ *Vốn tối thiểu (chịu 3 ván thua):*\n"
                            f"Ván1=`{bet0_obs}` → Ván2=`{bet0_obs*he_so_obs:.4f}` → Ván3=`{bet0_obs*he_so_obs**2:.4f}`\n"
                            f"Cần: `{bet0_obs+bet0_obs*he_so_obs+bet0_obs*he_so_obs**2:.4f} {coin}`",
                            force=True)
                        # Vẫn cần enter room để nhận notify_result
                        chosen = v['ai_predictor'].predict_room(data, v['history'])
                        v['last_game']['my_room'] = chosen
                        vth_enter_room(uid, chosen)
                        with v['lock']:
                            v['data_socket'].update({
                                'my_room': ud.get('room_id', chosen),
                                'my_bet_amount': -1,   # -1 = quan sát, không đặt
                                'issue_id': issue_id,
                                'asset_type': data.get('asset_type', ''),
                                'rooms': data.get('rooms', []),
                                'out_socket': False,
                            })
                        continue

                    # ── VÁN 2+: ĐẶT NGAY TRONG notify_issue_stat ──
                    forced = v.get('_forced_room')
                    if forced:
                        chosen = forced
                    else:
                        chosen = v['ai_predictor'].predict_room(data, v['history'])

                    rname  = ROOM_VTH.get(chosen, f'Phòng {chosen}')
                    v['last_game']['my_room'] = chosen
                    with v['lock']:
                        v['data_socket'].update({
                            'my_room': chosen,
                            'issue_id': issue_id,
                            'asset_type': data.get('asset_type', ''),
                            'rooms': data.get('rooms', []),
                            'out_socket': False,
                            'my_bet_amount': 1,  # Đánh dấu đang xử lý
                        })

                    ds   = v['data_socket']
                    win  = ds['so_ki_win']; lose = ds['so_ki_thua']
                    wr   = f'{win/(win+lose)*100:.1f}%' if (win+lose) > 0 else 'N/A'
                    bal  = v['asset'].get(coin, 0)
                    coin = v['cfg'].get('Coin', '?')
                    init_bal = float(v['cfg'].get('_init_balance', 0))
                    tong_loi = ds.get('tong_loi', 0.0)
                    earn_ico = "📈" if tong_loi >= 0 else "📉"
                    he_so    = float(v['cfg'].get('heso', 1))

                    # Bước 1: Enter room
                    vth_enter_room(uid, chosen)
                    # Bước 2: Đặt cược ngay (không qua thread riêng)
                    ok = vth_bet(uid, chosen, bet_amt)

                    if ok:
                        with v['lock']:
                            v['data_socket']['my_bet_amount'] = float(bet_amt)
                        vth_add_log(uid, f"Kì #{issue_id}: ✓ Đặt {rname} | {bet_amt} {coin}")
                        vth_notify(uid,
                            f"🎯 *Kì #{issue_id} — Đặt cược*\n"
                            f"━━━━━━━━━━━━━━━━━━━\n"
                            f"🏠 Đặt: *{rname}* (phòng sát thủ ván trước)\n"
                            f"💰 Cược: `{bet_amt} {coin}`\n"
                            f"💼 Số dư: `{bal:.4f} {coin}`\n"
                            f"{earn_ico} Tổng lời/lỗ: `{tong_loi:+.4f} {coin}`\n"
                            f"📈 Hệ số: `{he_so}x` │ W/L: {win}W/{lose}L ({wr})\n"
                            f"⏳ Đang chờ kết quả...",
                            force=True)
                    else:
                        with v['lock']:
                            v['data_socket']['my_bet_amount'] = 0
                        vth_add_log(uid, f"Kì #{issue_id}: ✗ Đặt thất bại")

                elif mt == 'notify_count_down':
                    with v['lock']:
                        v['data_socket']['count_down'] = data.get('count_down', 9999)
                        v['data_socket']['asset_type'] = data.get('asset_type', '')

                elif mt == 'notify_result':
                    vth_handle_result(uid, data)

        except Exception as e:
            err_str = str(e)
        finally:
            try:
                if ws: ws.close()
            except Exception: pass
            ws = None
            with v['lock']:
                v['data_socket']['out_socket'] = True
                # KHÔNG reset my_bet_amount ở đây
                # handle_result sẽ reset về 0 khi ván xong
                # Nếu đang giữa ván mà WS ngắt → timeout 180s sẽ reset

        if v['stop_event'].is_set():
            break

        # Nếu thoát vì stop_event (không phải lỗi) → không reconnect
        if not err_str:
            # Thoát bình thường (stop_event hoặc logic kết thúc)
            break

        # ── Có lỗi thật → Tính thời gian chờ rồi reconnect ────
        _retry_count += 1
        wait = min(3 * _retry_count, 30)  # 3s → 6s → 9s... tối đa 30s

        # Chỉ gửi TB lỗi nếu khác lỗi trước (tránh spam)
        if err_str != _last_err:
            _last_err = err_str
            v['_ws_error_sent'] = True
            vth_add_log(uid, f'❌ WS lỗi: {err_str[:80]} — thử lại sau {wait}s (lần {_retry_count})')
            if _retry_count <= 3:
                vth_notify(uid,
                    f"⚠️ *VTH mất kết nối* (lần {_retry_count})\n"
                    f"Lỗi: `{err_str[:60]}`\n"
                    f"Đang thử lại sau {wait}s...",
                    force=True)

        time.sleep(wait)

def vth_check_and_bet(uid: int):
    """
    Thread đặt cược VTH.
    Logic trạng thái my_bet_amount:
      -1  = chưa có ván mới (init / WS vừa reset)
       0  = ván mới đã đến, cần đặt cược
      >0  = đã đặt, đang chờ kết quả
     999  = STOP
    """
    v = get_sess(uid)['vth']
    _wait_start = 0
    _last_bet_issue = -1   # issue_id của ván vừa đặt → tránh đặt 2 lần

    while not v['stop_event'].is_set():
        try:
            ds = v['data_socket']
            amt = ds['my_bet_amount']

            # STOP
            if amt == 999:
                break

            # WS mất kết nối → chờ
            if ds['out_socket']:
                _wait_start = 0
                time.sleep(1); continue

            # ── Trạng thái: sẵn sàng đặt cược ──
            if amt == 0:
                cur_issue = ds.get('issue_id', 0)
                # Tránh đặt lại cùng 1 kì
                if cur_issue == _last_bet_issue:
                    time.sleep(1); continue

                if vth_kiem_tra_delay(uid):
                    vth_add_log(uid, '⏸ Tạm nghỉ (delay mode)')
                    time.sleep(5); continue

                amount  = vth_tinh_bet(uid)
                room_id = ds.get('my_room', random.randint(1, 8))
                ok = vth_bet(uid, room_id, amount)
                if ok:
                    _last_bet_issue = cur_issue
                    _wait_start = time.time()
                    vth_add_log(uid, f"✓ Kì #{cur_issue}: Đặt {amount} phòng {room_id}")
                    # Đánh dấu đã đặt (>0) để không đặt lại
                    with v['lock']:
                        v['data_socket']['my_bet_amount'] = amount
                    time.sleep(2)
                else:
                    # Bet lỗi → thử lại sau 3s
                    vth_add_log(uid, f"✗ Kì #{cur_issue}: Đặt thất bại, thử lại...")
                    time.sleep(3)

            # ── Trạng thái: đang chờ kết quả ──
            elif amt > 0:
                if _wait_start == 0:
                    _wait_start = time.time()
                elif time.time() - _wait_start > 180:
                    vth_add_log(uid, f"⚠️ Timeout 180s kì #{ds.get('issue_id',0)} → reset")
                    with v['lock']:
                        v['data_socket']['my_bet_amount'] = 0
                    _wait_start = 0
                time.sleep(1)

            # ── Trạng thái: -1 (chưa có ván mới) ──
            else:
                _wait_start = 0
                time.sleep(1)

        except Exception as e:
            vth_add_log(uid, f'Lỗi check_and_bet: {e}'); time.sleep(5)

def vth_update_stats(uid: int):
    v = get_sess(uid)['vth']
    while not v['stop_event'].is_set():
        try:
            vth_user_asset(uid)
            if v['data_socket']['start_issue_id'] == -1: time.sleep(30); continue
            res = requests.get('https://api.escapemaster.net/escape_game/my_joined',
                               params={'asset': v['cfg'].get('Coin', 'BUILD'), 'page': '1', 'page_size': '50'},
                               headers=vth_headers(v['cfg'])).json()
            for item in res.get('data', {}).get('items', []):
                if int(item['issue_id']) >= int(v['data_socket']['start_issue_id']):
                    v['lich_su'].append(item)
            time.sleep(30)
        except Exception as e:
            vth_add_log(uid, f'Lỗi update_stats: {e}'); time.sleep(10)

def vth_start(uid: int, chat_id: int, loop):
    v = get_sess(uid)['vth']
    if v['running']: return
    # Reset bộ đếm thông báo khi bắt đầu phiên mới
    v['_notify_count']    = 0
    v['_notify_max']      = 999
    v['_last_issue_id']   = -1
    v['_observe_mode']    = True    # Luôn quan sát ván đầu
    v['_last_killed_room'] = None   # Chưa có phòng bị sát thủ
    v['_forced_room']     = None    # Chưa có phòng bắt buộc
    v['running'] = True; v['stop_event'].clear(); v['_loop'] = loop; v['threads'] = []
    # Gửi thông báo start (force=True)
    # Lưu số dư ban đầu để tính lời/lỗ tổng
    try:
        _init_asset = vtd_api_asset(vtd_make_headers(
            v['cfg'].get('user_id',''), v['cfg'].get('user_secret_key','')))
        v['cfg']['_init_balance'] = _init_asset.get(v['cfg'].get('Coin','BUILD'), 0)
    except: v['cfg']['_init_balance'] = 0
    # Reset current_bet
    v['cfg']['current_bet'] = float(v['cfg'].get('bet_amount0', 0))

    _bet0 = float(v['cfg'].get('bet_amount0', 0))
    _heso = float(v['cfg'].get('heso', 1))
    _coin = v['cfg'].get('Coin','?')
    _bal0 = v['cfg'].get('_init_balance', 0)
    vth_notify(uid,
        f"🚀 *VTH Bot đã khởi động!*\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"🪙 Coin: `{_coin}`\n"
        f"💵 Mức cược ban đầu: `{_bet0} {_coin}`\n"
        f"📈 Hệ số khi thua: `{_heso}x`\n"
        f"💼 Số dư: `{_bal0} {_coin}`\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"⚠️ *Lưu ý vốn (chịu 3 ván thua):*\n"
        f"Ván1=`{_bet0}` → Ván2=`{_bet0*_heso:.4f}` → Ván3=`{_bet0*_heso**2:.4f}`\n"
        f"Cần tối thiểu: `{_bet0+_bet0*_heso+_bet0*_heso**2:.4f} {_coin}`\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"👁 *Ván 1: Quan sát — chưa đặt cược*\n"
        f"Dùng /vthstatus để xem trạng thái.",
        force=True)
    # Chỉ cần WS thread và Stats thread
    # Bet được thực hiện trực tiếp trong notify_issue_stat
    for target, name in [(lambda: vth_connect_socket(uid), 'WS'),
                         (lambda: vth_update_stats(uid), 'Stats')]:
        t = threading.Thread(target=target, name=f'{uid}-VTH-{name}', daemon=True)
        t.start(); v['threads'].append(t)

def vth_stop(uid: int):
    """Dừng VTH ngay lập tức"""
    v = get_sess(uid)['vth']
    v['stop_event'].set()      # Thoát tất cả while stop_event
    v['running']  = False
    v['_current_round'] = {}
    v['_observe_mode']  = True   # Reset để ván tiếp khi start lại quan sát đầu
    with v['lock']:
        v['data_socket']['out_socket']    = True
        v['data_socket']['my_bet_amount'] = 999   # Signal STOP
    for t in list(v.get('threads', [])):
        t.join(timeout=3)
    v['threads'] = []
    # Gửi thống kê cuối khi dừng
    try:
        ds = v['data_socket']; coin = v['cfg'].get('Coin','?')
        bal = v['asset'].get(coin, 0)
        win = ds['so_ki_win']; lose = ds['so_ki_thua']; total = win+lose
        wr = f'{win/total*100:.1f}%' if total > 0 else 'N/A'
        loi = ds['tong_loi']; loi_txt = f'+{loi:.4f}' if loi>=0 else f'{loi:.4f}'
        vth_notify(uid,
            f"⏹ *VTH Bot đã dừng*\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"📊 Tổng: {total} ván │ W/L: {win}W/{lose}L ({wr})\n"
            f"💹 Lời/lỗ: {loi_txt} {coin}\n"
            f"💼 Số dư: {bal:.4f} {coin}\n"
            f"🔥 Max chuỗi thắng: {ds['max_streak']}\n"
            f"❄️ Max chuỗi thua: {ds['max_lose_streak']}",
            force=True)
    except Exception as e:
        print(f"[vth_stop notify] {e}")

def vth_format_status(uid: int) -> str:
    v = get_sess(uid)['vth']; ds = v['data_socket']; coin = v['cfg'].get('Coin', '?')
    bal = v['asset'].get(coin, 0); conn = '🟢 Kết nối' if not ds['out_socket'] else '🔴 Mất kết nối'
    rname = ROOM_VTH.get(ds.get('my_room', 0), '?')
    win = ds['so_ki_win']; lose = ds['so_ki_thua']; total = win+lose
    wr = f'{win/total*100:.1f}%' if total > 0 else 'N/A'
    return (f'📊 *TRẠNG THÁI VUA THOÁT HIỂM*\n━━━━━━━━━━━━━━━━━━━━\n'
            f'🔌 {conn} │ 💰 {coin}\n💼 Số dư: {bal:.4f} {coin}\n'
            f'🏠 Phòng: {rname} ({ds.get("my_room", 0)})\n━━━━━━━━━━━━━━━━━━━━\n'
            f'✅ {win}W ❌ {lose}L │ {wr}\n💹 Lời/lỗ: {ds["tong_loi"]:.4f}\n'
            f'🔥 Chuỗi thắng: {ds["streak"]} (Max: {ds["max_streak"]})\n'
            f'❄️ Chuỗi thua: {ds["lose_streak"]} (Max: {ds["max_lose_streak"]})')

def vth_handle_input(uid: int, chat_id: int, text: str):
    vh = get_sess(uid)['vth']; st = vh['state']
    if st == 'wait_link':
        try:
            parsed = urlparse(text); params = parse_qs(parsed.query)
            user_id = params.get('userId', [None])[0]; sec_key = params.get('secretKey', [None])[0]
            if not user_id or not sec_key: raise ValueError('Thiếu userId hoặc secretKey')
            vh['cfg']['user_id'] = user_id; vh['cfg']['user_secret_key'] = sec_key; vh['state'] = 'wait_coin'
            tg_send(chat_id, f'[VTH] ✅ Link hợp lệ!\n👤 User ID: `{user_id}`\n\n💰 *Bước 2/5: Chọn loại coin*',
                    mk={'inline_keyboard': [[{'text': '💵 USDT', 'callback_data': 'vth_coin_USDT'},
                                             {'text': '🏗 BUILD', 'callback_data': 'vth_coin_BUILD'},
                                             {'text': '🌍 WORLD', 'callback_data': 'vth_coin_WORLD'}]]}, md='Markdown')
        except Exception as e:
            tg_send(chat_id, f'[VTH] ❌ Link không hợp lệ! ({e})\nDán lại link:', md='Markdown')
    elif st == 'wait_bet':
        try:
            v2 = float(text); assert v2 > 0
            vh['cfg']['bet_amount0'] = v2; vh['state'] = 'wait_heso'
            coin_now = vh['cfg'].get('Coin','?')
            tg_send(chat_id,
                f'[VTH] ✅ Tiền đặt: `{v2} {coin_now}`\n\n'
                f'✖️ *Bước 4/5: Nhập hệ số Martingale* (VD: `2`):\n\n'
                f'⚠️ *LƯU Ý VỀ VỐN — ĐỌC KỸ:*\n'
                f'Bot theo logic thua liên tiếp, ae chú ý chia vốn:\n'
                f'• Hệ số `2x`: ván 1→`{v2}`, ván 2→`{v2*2}`, ván 3→`{v2*4}` = tổng `{v2+v2*2+v2*4:.2f} {coin_now}`\n'
                f'• Hệ số `1.5x`: ván 1→`{v2}`, ván 2→`{v2*1.5:.2f}`, ván 3→`{v2*2.25:.2f}` = tổng `{v2+v2*1.5+v2*2.25:.2f} {coin_now}`\n'
                f'✅ *Chia vốn chịu 3 ván thua liên tiếp = 80% không lỗ!*',
                md='Markdown')
        except:
            tg_send(chat_id, f'[VTH] ❌ Số không hợp lệ, nhập lại (VD: `1.5`):', md='Markdown')
    elif st == 'wait_heso':
        try:
            v2 = float(text); assert v2 >= 1
            vh['cfg']['heso'] = v2; vh['state'] = 'wait_delay1'
            tg_send(chat_id, f'[VTH] ✅ Hệ số: `{v2}x`\n\n⏸ *Bước 5/5: Sau bao nhiêu ván thì tạm nghỉ?*\n_Nhập `9999` nếu không muốn nghỉ_', md='Markdown')
        except:
            tg_send(chat_id, f'[VTH] ❌ Hệ số phải >= 1, nhập lại (VD: `2`):', md='Markdown')
    elif st == 'wait_delay1':
        try:
            d1 = int(text); assert d1 >= 1
            vh['cfg']['delay1'] = d1
            if d1 >= 9999:
                vh['cfg']['delay2'] = 0; vh['state'] = 'idle'; _vth_finish(uid, chat_id)
            else:
                vh['state'] = 'wait_delay2'
                tg_send(chat_id, f'[VTH] ✅ Sau `{d1}` ván sẽ nghỉ.\n\n⏸ *Nghỉ bao nhiêu ván?*\n_VD: 5_', md='Markdown')
        except:
            tg_send(chat_id, f'[VTH] ❌ Nhập số nguyên >= 1 (hoặc `9999` để không nghỉ):', md='Markdown')
    elif st == 'wait_delay2':
        try:
            d2 = int(text); assert d2 >= 1
            vh['cfg']['delay2'] = d2; vh['state'] = 'idle'; _vth_finish(uid, chat_id)
        except:
            tg_send(chat_id, f'[VTH] ❌ Nhập số nguyên >= 1:', md='Markdown')
    else:
        tg_send(chat_id, f'[VTH] Dùng /vthsetup để cấu hình VTH.')

def _vth_finish(uid: int, chat_id: int):
    vh = get_sess(uid)['vth']; cfg_save(uid)
    tg_send(chat_id, f'[VTH] ✅ *Cấu hình VTH đã lưu!*\n\n'
            f'  🪙 Coin: `{vh["cfg"].get("Coin","?")}`\n'
            f'  💵 Tiền đặt: `{vh["cfg"].get("bet_amount0","?")}`\n'
            f'  📈 Hệ số: `{vh["cfg"].get("heso","?")}x`\n'
            f'  ⏸ Delay: `{vh["cfg"].get("delay1","?")}` ván → nghỉ `{vh["cfg"].get("delay2",0)}` ván\n\n'
            '▶️ Dùng /vthstart để bắt đầu!', md='Markdown')

def _format_mycfg(uid: int) -> str:
    path = _cfg_path(uid)
    if not os.path.exists(path): return "📂 *Cấu hình đã lưu*\n\nChưa có cấu hình nào được lưu."
    sess = get_sess(uid); v = sess['vtd']; vh = sess['vth']['cfg']
    lines = ["📂 *Cấu hình đã lưu của bạn*\n", "🏃 *SprintRun (VTD)*"]
    if v['xw_uid']:
        lines.append(f"  👤 User ID: `{v['xw_uid']}`")
        lines.append(f"  🔑 Key: `{str(v['xw_key'])[:12]}...`")
    else:
        lines.append("  _(Chưa cấu hình link)_")
    if v['Coin']:
        lines += [f"  🪙 Coin: `{v['Coin']}`", f"  💵 Tiền đặt: `{v['bet_amount0']}`",
                  f"  📈 Hệ số thua: `{v['he_so']}x`", f"  🎯 Loại cược: `{v['type_bet']}`",
                  f"  👥 Số người: `{v['So_nv']}`"]
    else:
        lines.append("  _(Chưa cấu hình game)_")
    lines.append("\n🏠 *Vua Thoát Hiểm (VTH)*")
    if vh.get('user_id'):
        lines += [f"  👤 User ID: `{vh['user_id']}`", f"  🪙 Coin: `{vh.get('Coin','?')}`",
                  f"  💵 Tiền đặt: `{vh.get('bet_amount0','?')}`", f"  📈 Hệ số: `{vh.get('heso','?')}x`"]
        d1 = vh.get('delay1', 9999)
        if d1 < 9999: lines.append(f"  ⏸ Delay: `{d1}` ván → nghỉ `{vh.get('delay2',0)}` ván")
        else: lines.append("  ⏸ Delay: Không nghỉ")
    else:
        lines.append("  _(Chưa cấu hình)_")
    lines.append(f"\n💾 File: `{path}`")
    return "\n".join(lines)


# ─────────────────────────────────────────────
#  ENTRY POINT & HANDLERS
# ─────────────────────────────────────────────
async def cmd_entry(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Gọi từ main khi user chọn XWorld từ menu chính"""
    uid = update.effective_user.id; name = update.effective_user.first_name
    restored = False
    if uid not in _all_sessions:
        get_sess(uid); restored = cfg_load(uid)
    extra = ""
    if restored:
        sess = get_sess(uid); v = sess['vtd']; vh = sess['vth']
        lines = []
        if v['xw_uid'] and v['Coin'] and v['bet_amount0']:
            lines.append(f"  🏃 VTD: `{v['Coin']}` | bet `{v['bet_amount0']}` | hệ số `{v['he_so']}x`")
        if vh['cfg'].get('user_id') and vh['cfg'].get('Coin'):
            lines.append(f"  🏠 VTH: `{vh['cfg']['Coin']}` | bet `{vh['cfg']['bet_amount0']}`")
        if lines: extra = "\n\n📂 *Đã tải cấu hình cũ:*\n" + "\n".join(lines)
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🏃 Chạy Đua Tốc Độ (SprintRun)", callback_data="game_vtd")],
        [InlineKeyboardButton("🏠 Vua Thoát Hiểm", callback_data="game_vth")],
        [InlineKeyboardButton("📂 Xem cấu hình đã lưu", callback_data="show_mycfg")],
        [InlineKeyboardButton("🔙 Menu chính", callback_data="back_home")],
    ])
    text = f'🤖 *XWorld Multi Game*{extra}\n\nChọn game:'
    if update.callback_query:
        await update.callback_query.message.reply_text(text, parse_mode='Markdown', reply_markup=kb)
    else:
        await update.message.reply_text(text, parse_mode='Markdown', reply_markup=kb)

# VTH command handlers
async def vth_cmd_setup(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id; sess = get_sess(uid)
    sess['game'] = 'vth'; vh = sess['vth']; vh['state'] = 'wait_link'; vh['cfg'] = {}
    await update.message.reply_text(
        '🔗 *Bước 1/5: Nhập link tài khoản VTH*\n\n'
        '1. Mở Chrome → vào xworld.io\n2. Đăng nhập → vào *Vua Thoát Hiểm*\n'
        '3. Nhấn "Lập tức truy cập"\n4. Copy URL và gửi vào đây\n\n_Gõ /vthcancel để huỷ_',
        parse_mode='Markdown')

async def vth_cmd_cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    get_sess(uid)['vth']['state'] = 'idle'
    await update.message.reply_text('❌ Đã huỷ cài đặt VTH. Gõ /vthsetup để bắt đầu lại.')

async def vth_cmd_start_bot(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id; chat = update.effective_chat.id
    v = get_sess(uid)['vth']
    if not v['cfg'].get('user_id'):
        await update.message.reply_text('⚠️ Chưa cài đặt! Dùng /vthsetup trước.'); return
    if v['running']:
        await update.message.reply_text('⚠️ Bot VTH đang chạy rồi!'); return
    v['data_socket'].update({'out_socket': True, 'issue_id': 0, 'rooms': [], 'count_down': 9999,
                              'my_room': 0, 'my_bet_amount': -1, 'tong_loi': 0.0, 'so_ki_win': 0,
                              'so_ki_thua': 0, 'streak': 0, 'max_streak': 0, 'lose_streak': 0,
                              'max_lose_streak': 0, 'start_issue_id': -1, 'tongsovan': 0})
    v['history'].clear(); v['lich_su'].clear(); v['logs'].clear()
    v['ai_predictor'] = AIRoomPredictor()
    vth_start(uid, chat, asyncio.get_event_loop())
    await update.message.reply_text('🚀 *VTH Bot đã khởi động!*\nDùng /vthstatus để theo dõi.', parse_mode='Markdown')

async def vth_cmd_stop_bot(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id; v = get_sess(uid)['vth']
    if not v['running']:
        await update.message.reply_text('⚠️ Bot VTH chưa chạy.'); return
    vth_stop(uid); await update.message.reply_text('🛑 *Bot VTH đã dừng!*', parse_mode='Markdown')

async def vth_cmd_status(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id; v = get_sess(uid)['vth']
    if not v['cfg'].get('user_id'):
        await update.message.reply_text('⚠️ Chưa cài đặt. Dùng /vthsetup'); return
    await update.message.reply_text(vth_format_status(uid), parse_mode='Markdown')

async def vth_cmd_logs(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id; v = get_sess(uid)['vth']
    with v['lock']: ls = list(v['logs'])[:10]
    msg = '📋 *LOG VTH GẦN NHẤT*\n' + '\n'.join(ls) if ls else '📋 Chưa có log'
    await update.message.reply_text(msg, parse_mode='Markdown')

async def vth_cmd_reset(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    vth_stop(uid)
    _all_sessions[uid]['vth'] = {
        'state': 'idle', 'cfg': {}, 'running': False, 'stop_event': threading.Event(),
        'threads': [], 'lock': threading.Lock(), '_loop': None,
        'ai_predictor': AIRoomPredictor(), 'history': deque(maxlen=50),
        'last_game': {'data': None, 'my_room': 0}, 'logs': deque(maxlen=30),
        'asset': {'BUILD': 0.0, 'USDT': 0.0, 'WORLD': 0.0}, 'lich_su': [],
        'data_socket': {'out_socket': True, 'asset_type': '', 'issue_id': 0, 'rooms': [],
                        'count_down': 9999, 'my_room': 0, 'my_bet_amount': -1, 'user_id': 0,
                        'tong_loi': 0.0, 'so_ki_win': 0, 'so_ki_thua': 0, 'streak': 0,
                        'max_streak': 0, 'lose_streak': 0, 'max_lose_streak': 0,
                        'start_issue_id': -1, 'tongsovan': 0},
    }
    await update.message.reply_text('🔄 Đã reset VTH! Dùng /vthsetup để cài lại.')

async def cmd_mycfg(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id; get_sess(uid)
    await update.message.reply_text(
        _format_mycfg(uid), parse_mode='Markdown',
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🏃 Vào VTD", callback_data="game_vtd"),
             InlineKeyboardButton("🏠 Vào VTH", callback_data="game_vth")],
            [InlineKeyboardButton("🔙 Menu chính", callback_data="back_home")],
        ])
    )


# ─────────────────────────────────────────────
#  CALLBACK HANDLER
# ─────────────────────────────────────────────
async def handle_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    query = update.callback_query
    data = query.data
    uid = query.from_user.id
    chat = query.message.chat_id

    _xworld_prefixes = ('vtd_', 'vth_coin_', 'game_vtd', 'game_vth', 'main_menu', 'show_mycfg')
    if not any(data == p or data.startswith(p) for p in _xworld_prefixes):
        return False

    await query.answer()

    if data == 'show_mycfg':
        await query.message.reply_text(
            _format_mycfg(uid), parse_mode='Markdown',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏃 Vào VTD", callback_data="game_vtd"),
                 InlineKeyboardButton("🏠 Vào VTH", callback_data="game_vth")],
                [InlineKeyboardButton("🔙 Menu chính", callback_data="back_home")],
            ])
        )

    elif data == 'main_menu':
        await query.message.reply_text(
            "🎮 *Chọn game:*", parse_mode='Markdown',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🏃 Chạy Đua Tốc Độ (SprintRun)", callback_data="game_vtd")],
                [InlineKeyboardButton("🏠 Vua Thoát Hiểm", callback_data="game_vth")],
                [InlineKeyboardButton("📂 Xem cấu hình đã lưu", callback_data="show_mycfg")],
                [InlineKeyboardButton("🔙 Menu chính", callback_data="back_home")],
            ])
        )

    elif data == 'game_vtd':
        get_sess(uid)['game'] = 'vtd'
        await query.message.reply_text(
            "🏃 *SprintRun — Chạy Đua Tốc Độ*\n\nChọn thao tác:",
            parse_mode='Markdown',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("⚙️ Cấu hình link XWorld", callback_data="vtd_cfg_link")],
                [InlineKeyboardButton("🎮 Cấu hình game", callback_data="vtd_cfg_game"),
                 InlineKeyboardButton("📊 Thống kê", callback_data="vtd_stats")],
                [InlineKeyboardButton("▶️ Chạy", callback_data="vtd_start"),
                 InlineKeyboardButton("⏹ Dừng", callback_data="vtd_stop")],
                [InlineKeyboardButton("🔄 Reset", callback_data="vtd_reset"),
                 InlineKeyboardButton("🔙 Menu chính", callback_data="back_home")],
            ])
        )

    elif data == 'game_vth':
        get_sess(uid)['game'] = 'vth'
        await query.message.reply_text(
            "🏠 *Vua Thoát Hiểm*\n\nLệnh:\n"
            "  /vthsetup — Cài đặt\n  /vthstart — Bắt đầu\n  /vthstop — Dừng\n"
            "  /vthstatus — Trạng thái\n  /vthlogs — Log gần nhất\n"
            "  /vthreset — Reset\n  /vthcancel — Huỷ đang cài đặt",
            parse_mode='Markdown'
        )

    elif data.startswith('vtd_') or data.startswith('vtd_coin_') or data.startswith('vtd_type_'):
        vtd_handle_callback(uid, chat, data)

    elif data.startswith('vth_coin_'):
        coin = data[9:]; vh = get_sess(uid)['vth']
        if vh['state'] == 'wait_coin':
            vh['cfg']['Coin'] = coin; vh['state'] = 'wait_bet'
            tg_send(chat, f'✅ Coin: `{coin}`\n\n💵 *Bước 3/5: Nhập số `{coin}` đặt cược mỗi ván*\n_VD: 1.5_', md='Markdown')

    return True


# ─────────────────────────────────────────────
#  MESSAGE HANDLER
# ─────────────────────────────────────────────
async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    uid = update.effective_user.id; chat = update.effective_chat.id; text = update.message.text.strip()
    sess = get_sess(uid); game = sess.get('game')
    if game == 'vtd':
        v = sess['vtd']
        if v['state'] != 'idle':
            vtd_handle_input(uid, chat, text); return True
    if game == 'vth':
        vh = sess['vth']
        if vh['state'] != 'idle':
            vth_handle_input(uid, chat, text); return True
    return False
