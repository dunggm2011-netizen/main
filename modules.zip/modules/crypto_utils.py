"""
crypto_utils.py — Mã hóa dữ liệu người dùng AES-256
Dùng cryptography.fernet (nếu có) hoặc XOR fallback
"""
import os, base64, json, hashlib

# ── Thử import cryptography ──────────────────────────
try:
    from cryptography.fernet import Fernet
    _HAS_FERNET = True
except ImportError:
    _HAS_FERNET = False

KEY_FILE = "data/.secret.key"

def _get_or_create_key() -> bytes:
    os.makedirs("data", exist_ok=True)
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, "rb") as f:
            return f.read()
    if _HAS_FERNET:
        key = Fernet.generate_key()
    else:
        key = base64.urlsafe_b64encode(os.urandom(32))
    with open(KEY_FILE, "wb") as f:
        f.write(key)
    return key

_KEY = None

def _key():
    global _KEY
    if _KEY is None:
        _KEY = _get_or_create_key()
    return _KEY

# ── Fernet encrypt/decrypt ───────────────────────────
def _fernet_enc(data: str) -> str:
    f = Fernet(_key())
    return f.encrypt(data.encode()).decode()

def _fernet_dec(data: str) -> str:
    f = Fernet(_key())
    return f.decrypt(data.encode()).decode()

# ── XOR fallback encrypt/decrypt ─────────────────────
def _xor_enc(data: str) -> str:
    key = _key()[:32]
    raw = data.encode()
    xored = bytes([raw[i] ^ key[i % len(key)] for i in range(len(raw))])
    return "XOR:" + base64.b64encode(xored).decode()

def _xor_dec(data: str) -> str:
    if not data.startswith("XOR:"):
        return data
    raw = base64.b64decode(data[4:])
    key = _key()[:32]
    return bytes([raw[i] ^ key[i % len(key)] for i in range(len(raw))]).decode()

# ── Public API ────────────────────────────────────────
def encrypt_str(data: str) -> str:
    """Mã hóa chuỗi"""
    try:
        if _HAS_FERNET:
            return _fernet_enc(data)
        return _xor_enc(data)
    except Exception:
        return data  # fallback: không mã hóa

def decrypt_str(data: str) -> str:
    """Giải mã chuỗi"""
    try:
        if data.startswith("XOR:"):
            return _xor_dec(data)
        if _HAS_FERNET:
            return _fernet_dec(data)
        return data
    except Exception:
        return data

def save_encrypted(path: str, obj: dict):
    """Lưu dict dưới dạng JSON đã mã hóa"""
    os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
    raw = json.dumps(obj, ensure_ascii=False, indent=2)
    enc = encrypt_str(raw)
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"_enc": enc}, f)

def load_encrypted(path: str, default=None):
    """Đọc dict từ file JSON đã mã hóa"""
    if default is None:
        default = {}
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            wrapper = json.load(f)
        if "_enc" in wrapper:
            raw = decrypt_str(wrapper["_enc"])
            return json.loads(raw)
        return wrapper  # file cũ chưa mã hóa
    except Exception:
        return default
